// src/pages/Home.js
import React,{useState,useEffect,useRef} from 'react';
import { getCountries,getStatesdata } from '../services';
import { useNavigate,useLocation } from 'react-router-dom'
import BookingBanner from './sections/BookingBanner.js';
import BookingDetails from './sections/BookingDetails.js';
import { getAllcountries } from '../countries';


const Paymentdetails = () => {
    const navigate = useNavigate();
    const { state } = useLocation();
    const [error, setError] = useState("");
    const [selectedOption, setSelectedOption] = useState('visa');
    const [cname, setCardname] = useState('');
    const [cnumber, setCardnumber] = useState('');
    const [cexpdate, setExpdate] = useState('');
    const [cexpyear, setExpyear] = useState('');
    const [ccvv, setCcvv] = useState('');
    const [address, setAddress] = useState('');
    const [country, setCountry] = useState('');
    const [statename, setStatename] = useState('');
    const [city, setCity] = useState('');
    const [zip, setZip] = useState('');
    const [countries, SetCountries] = useState();
    const [states, setStates] = useState();
    const [cnameerr, setCnameerr] = useState('');
    const [cnumbererr, setCnumbererr] = useState('');
    const [cexpdateerr, setExpdateerr] = useState('');
    const [cexpyerr, setCexpyerr] = useState('');
    const [ccvverr, setCvverr] = useState('');
    const [addresserr, setAddresserr] = useState('');
    const [countryerr, setCountryerr] = useState('');
    const [stateerr, setStateerr] = useState('');
    const [cityerr, setCityerr] = useState('');
    const [ziperr, setZiperr] = useState('');
    const [isChecked, setIsChecked] = useState(false);
    const [submitted, setSubmitted] = useState(false);

    const dealsRec = state?.dealdata;
   useEffect(() => {
        getCountries().then(res => {
             console.log(res.data);
            if(res.data.IsSuccess == true){

                SetCountries(res.data.Model)
            }else{
                console.error("Error fetching data:", res.data.Message);
            }
            
          }).catch(err => {
            console.error("Error fetching data:", err);
          });
    }, []);

  

   const getStates = (country) => {

    setCountry(country)
        getStatesdata(country).then(res => {
             console.log(res.data);
            if(res.data.IsSuccess == true){
                setStates(res.data.Model)
            }
            
          }).catch(err => {
            console.error("Error fetching data:", err);
          });
   }

   const validateEmail = (email) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    };

  
    const handleRadioChange = (event) => {
        setSelectedOption(event.target.value);
    };

    const nextStep = () => {
        navigate('/confirmation',{
                state: {'dealdata':dealsRec}
              });
    }

     const handleSubmit = (e) => {
        e.preventDefault();
        setCnameerr('');
        setCnumbererr('');
        setExpdateerr('');
        setCexpyerr('');
        setCvverr('');
        setAddresserr('');
        setCountryerr('');
        setStateerr('');
        setCityerr('');
        setZiperr('');
        
        
        if('' == cname){
            setCnameerr('Please enter your name');
        }
        if('' == cnumber){
            setCnumbererr('Please enter card number');
        }
        if('' == cexpdate){
            setExpdateerr('Please enter expiry date');
        }
        if('' == cexpyear){
            setCexpyerr('Please enter expiry year');
        }
        if('' == ccvv){
            setCvverr('Please enter card cvv number');
        }
        if('' == address){
            setAddresserr('Please enter your address');
        }
        if('' == country){
            setCountryerr('Please enter your country');
        }
         if('' == statename){
            setStateerr('Please enter your state');
        }
         if('' == city){
            setCityerr('Please enter your city');
        }
         if('' == zip){
            setZiperr('Please enter your zipcode');
        }else{
             navigate('/confirmation',{
                state: {'dealdata':dealsRec}
              });
        }
        
        
        


    };


    return <React.Fragment> <BookingBanner selectedcls="payment"/>
        <div class="mainContent py-5">
            <div class="container pb-5 pb-lg-0 position-relative">
                <div class="row">
                    <div class="col-lg-9 pe-lg-4">
                        <div class="mainInfoDtlSec">
                        <form className="" onSubmit={handleSubmit}>
                            <div class="bg-white mb-4 paymentInfoSec rounded border-bottom pb-3">

                                <h5 class="mb-1 poppins-semibold">Payment Information</h5>

                                <div class="align-items-center bg-gray carSec m-0 mb-4 mt-2 p-3 row">
                                    <div class="col-lg-2">
                                        <p class="text-black-65 fs-6 poppins-semibold mb-0">Card Type:</p>
                                    </div>
                                    <div class="col-lg-10">
                                        <div class="row">
                                            <div class="form-check col d-flex align-items-center justify-content-center">
                                                <input class={cexpyerr ? "erricls form-check-input" : "form-check-input"} type="radio" name="flexRadioDefault" id="flexRadioDefault1" onChange={handleRadioChange} checked={selectedOption === 'visa'} value="visa"/>
                                                <label class="form-check-label" for="flexRadioDefault1">
                                                    <img src={`${process.env.PUBLIC_URL}/assets/images/visa.png`} alt="card" class="img-fluid" />
                                                </label>
                                            </div>
                                            <div class="form-check col d-flex align-items-center justify-content-center">
                                                <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" onChange={handleRadioChange} checked={selectedOption === 'master'} value="master"/>
                                                <label class="form-check-label" for="flexRadioDefault1">
                                                    <img src={`${process.env.PUBLIC_URL}/assets/images/mastercard.png`} alt="card" class="img-fluid" />
                                                </label>
                                            </div>
                                            <div class="form-check col d-flex align-items-center justify-content-center">
                                                <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" onChange={handleRadioChange} checked={selectedOption === 'paypal'} value="paypal"/>
                                                <label class="form-check-label" for="flexRadioDefault1">
                                                    <img src={`${process.env.PUBLIC_URL}/assets/images/paypal.png`} alt="card" class="img-fluid" />
                                                </label>
                                            </div>
                                            <div class="form-check col d-flex align-items-center justify-content-center">
                                                <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" onChange={handleRadioChange} checked={selectedOption === 'directdebit'} value="directdebit"/>
                                                <label class="form-check-label" for="flexRadioDefault1">
                                                    <img src={`${process.env.PUBLIC_URL}/assets/images/directdebit.png`} alt="card" class="img-fluid" />
                                                </label>
                                            </div>
                                            <div class="form-check col d-flex align-items-center justify-content-center">
                                                <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" onChange={handleRadioChange} checked={selectedOption === 'ameexpress'} value="ameexpress"/>
                                                <label class="form-check-label" for="flexRadioDefault1">
                                                    <img src={`${process.env.PUBLIC_URL}/assets/images/ameexpress.png`} alt="card" class="img-fluid" />
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="name" class="form-label poppins-medium fs-6 mb-1">Card Holder's Name<span class="text-red">*</span></label>
                                            <input type="text" class={cnameerr ? "erricls bg-gray form-control" : "bg-gray form-control"} id="name" placeholder="Enter Name" value={cname} onChange={(e) => setCardname(e.target.value)}  />
                                            {cnameerr && <p style={{ color: 'red', marginBottom: '10px' }}>{cnameerr}</p>}
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="name" class="form-label poppins-medium fs-6 mb-1">Credit/Debit Card No<span class="text-red">*</span></label>
                                            <input class={cnumbererr ? "erricls bg-gray form-control" : "bg-gray form-control"} id="name" placeholder="Card Number" value={cnumber} onChange={(e) => setCardnumber(e.target.value)} type="number" pattern="[0-9]*" inputmode="numeric"/>
                                             {cnumbererr && <p style={{ color: 'red', marginBottom: '10px' }}>{cnumbererr}</p>}
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="mb-1">
                                            <label for="name" class="form-label poppins-medium fs-6 mb-1">Expiration Date<span class="text-red">*</span></label>
                                        </div>
                                        <div class="row">
                                            <div class="col-6">
                                                <select class={cexpdateerr ? "erricls bg-gray form-control form-select" : "bg-gray form-control form-select"}  id="expirationMonth" onChange={(e) => setExpdate(e.target.value)}>
                                                    <option selected="" disabled="">Select Month</option>
                                                    <option value="01">January</option>
                                                    <option value="02">February</option>
                                                    <option value="03">March</option>
                                                    <option value="04">April</option>
                                                    <option value="05">May</option>
                                                    <option value="06">June</option>
                                                    <option value="07">July</option>
                                                    <option value="08">August</option>
                                                    <option value="09">September</option>
                                                    <option value="10">October</option>
                                                    <option value="11">November</option>
                                                    <option value="12">December</option>
                                                </select>
                                                {cexpdateerr && <p style={{ color: 'red', marginBottom: '10px' }}>{cexpdateerr}</p>}
                                            </div>
                                            <div class="col-md-6">
                                                <select class={cexpyerr ? "erricls bg-gray form-control form-select mb-3" : "bg-gray form-control form-select mb-3"}  id="expirationYear" onChange={(e) => setExpyear(e.target.value)}>
                                                    <option selected="" disabled="">Select Year</option>
                                                    <option value="2025">2025</option>
                                                    <option value="2026">2026</option>
                                                    <option value="2027">2027</option>
                                                    <option value="2028">2028</option>

                                                </select>
                                                {cexpyerr && <p style={{ color: 'red', marginBottom: '10px' }}>{cexpyerr}</p>}
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="mb-1">
                                            <label for="name" class="form-label poppins-medium fs-6 mb-1">CVV<span class="text-red">*</span></label>
                                        </div>
                                        <div class="row">
                                            <div class="col-6">
                                                <input type="text" class={ccvverr ? "erricls bg-gray form-control" : "bg-gray form-control"} id="name" placeholder="CVV" value={ccvv} onChange={(e) => setCcvv(e.target.value)} type="number" pattern="[0-9]*" />
                                                {ccvverr && <p style={{ color: 'red', marginBottom: '10px' }}>{ccvverr}</p>}
                                            </div>
                                            <div class="col-md-6 d-flex align-items-center">
                                                <div class="d-flex align-items-start infoPay">
                                                    <img src={`${process.env.PUBLIC_URL}/assets/images/system-uicons_info-circle.svg`} alt="info icon" class="img-fluid" />
                                                    <span class="ps-2 fs-6">3-4 Digit Number on your card</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="billingInfoSec rounded bg-white mb-4 border-bottom pb-3">
                               <h5 class="mb-1 poppins-semibold">Billing and Contact Information</h5>
                                <p class="text-black-65 fs-6 poppins-regular">As per bank records or credit card company</p>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="mb-3">
                                            <label for="name" class="form-label poppins-medium fs-6 mb-1">Address<span class="text-red">*</span></label>
                                            <input type="text" class={addresserr ? "erricls bg-gray form-control" : "bg-gray form-control"} id="name" placeholder="Type address..." onChange={(e) => setAddress(e.target.value)}/>
                                            {addresserr && <p style={{ color: 'red', marginBottom: '10px' }}>{addresserr}</p>}
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="name" class="form-label poppins-medium fs-6 mb-1">Country<span class="text-red">*</span></label>
                                            <select class={countryerr ? "erricls bg-gray form-select form-control" : "bg-gray form-select form-control"} id="countrySelect" onChange={(e) => getStates(e.target.value)}>
                                                <option value="" disabled="" >Select Country</option>
                                                 { countries?.map((field, index) => (
                                                    <option value={field.CountryCode}>{field.CountryName}</option>
                                                ))}
                                                
                                            </select>
                                            {countryerr && <p style={{ color: 'red', marginBottom: '10px' }}>{countryerr}</p>}
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="name" class="form-label poppins-medium fs-6 mb-1">State<span class="text-red">*</span></label>
                                            <select class={stateerr ? "erricls bg-gray form-select form-control" : "bg-gray form-select form-control"}   id="countrySelect" onChange={(e) => setStatename(e.target.value)}>
                                            <option value="" disabled="" >Select State</option>
                                                { states?.map((field, index) => (
                                                    <option value={field.StateCode}>{field.StateName}</option>
                                                ))}
                                                
                                            </select>
                                            {stateerr && <p style={{ color: 'red', marginBottom: '10px' }}>{stateerr}</p>}
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="name" class="form-label poppins-medium fs-6 mb-1">City/Town<span class="text-red">*</span></label>
                                            <input type="text" class={cityerr ? "erricls bg-gray form-control" : "bg-gray form-control"} id="city" placeholder="Type here..." onChange={(e) => setCity(e.target.value)}/>
                                            {cityerr && <p style={{ color: 'red', marginBottom: '10px' }}>{cityerr}</p>}
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="name" class="form-label poppins-medium fs-6 mb-1">Postal/Zip code<span class="text-red">*</span></label>
                                            <input type="text" class={ziperr ? "erricls bg-gray form-control" : "bg-gray form-control"} id="zipCodeInput" placeholder="Type here..." onChange={(e) => setZip(e.target.value)}/>
                                            {ziperr && <p style={{ color: 'red', marginBottom: '10px' }}>{ziperr}</p>}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="contBtnSec nextBtn nextBtnFF text-end mt-4">
                                <button type="submit" class="border-0 btn btn-primary nextBtnLink pe-2 ps-3 rounded-pill text-white"  role="button">Confirm &amp; Book<i class="la-angle-right las ms-2 p-1 rounded-circle"></i></button>
                            </div>
                        </form>
                        </div>
                    </div>
                    <BookingDetails />
                </div>
            </div>
        </div></React.Fragment>;
};

export default Paymentdetails;
