// src/sections/BookinBanner.js
import {React,useState} from 'react';
import { useNavigate,useLocation } from 'react-router-dom'
const BookingBanner = ({selectedcls}) => {
    const navigate = useNavigate();
    const handelBack = () => {
        navigate(-1);
    }
    return <div class="ipHeroSetion bg-gray">
            <div class="container position-relative py-4">
                <div class="align-items-center row">
                    <div class="align-items-center col-md-3 d-flex"> <a onClick={handelBack} role="button" class="text-black text-decoration-none align-items-center d-flex"><i class="fs-4 la-long-arrow-alt-left las me-2"></i><span>Back to Results</span></a></div>
                    <div class="col-md-9">
                        <div class="stepper-wrapper">
                            <div class={selectedcls == 'contact' ? "active completed stepper-item" : "stepper-item"}>
                                <div class="step-counter">1</div>
                                <div class="step-name">Contact Info</div>
                            </div>
                            <div class={selectedcls == 'options' ? "active completed stepper-item" : "stepper-item"}>
                                <div class="step-counter">2</div>
                                <div class="step-name">Optionals</div>
                            </div>
                            <div class={selectedcls == 'payment' ? "active completed stepper-item" : "stepper-item"}>
                                <div class="step-counter">3</div>
                                <div class="step-name">Payment</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>;
};

export default BookingBanner;
