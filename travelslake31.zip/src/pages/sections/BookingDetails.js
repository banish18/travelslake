// src/pages/Home.js
import React,{useEffect,useState} from 'react';
import FlightDetails from './FlightDetails.js';
import { formatFlightTime,formatFlightDate } from '../../services';
let pre = '';
const BookingDetails = ({suggestion,searchdata}) => {
    
    const [predate,setPredate] = useState('');

    useEffect(() => {
         console.log('hello');
         console.log(searchdata);
    }, []);

    const totolTraver = () => {
        console.log('hello');
        console.log(searchdata);
        return searchdata?.AdultCount+searchdata?.ChildCount+searchdata?.InfantCount;
    }

    const renderItems = (innerflights) => {
       
        if(pre !== innerflights?.DepartureDate){
             console.log('hello');
        console.log(pre);
        console.log(innerflights?.DepartureDate);
            return <tr>
                    <td class="border-0 px-0">{innerflights?.OriginCityName}</td>
                    <th class="border-0 px-0" scope="row">{formatFlightDate(innerflights?.DepartureDate,1)}</th>
                    <th class="border-0 px-0" scope="row">{formatFlightTime(innerflights?.ArrivalTime,1)}</th>
                </tr>;
        }

        
        pre  = innerflights?.DepartureDate;
      return null
    }




    return <div class="col-lg-3">
                        <div class="shadow border-0 rounded-4 tripFareSmry">
                            <div class="border border-light card tripSmry w-auto mb-3">
                                <div class="bg-light-orange card-header position-relative py-4 text-center">
                                    <div class="align-items-center d-flex iteTitle justify-content-center mb-2">
                                        <h2 class="poppins-bold mb-0 text-black text-uppercase">{searchdata?.OriginAirportCode}</h2>
                                        <span class="iconIte px-2"><button type="button" class="align-items-center bg-gray-light bg-white border-0 btn btn-primary d-flex itenerary-btn justify-content-center p-1 rounded-pill"><img src={`${process.env.PUBLIC_URL}/assets/images/itesectinicon.png`} alt="icon" class="img-fluid" /></button></span>
                                        <h2 class="poppins-bold mb-0 text-black text-uppercase">{searchdata?.DestinationAirportCode}</h2>
                                    </div>
                                    <ul class="alrghtDtl barlow-regular d-inline-flex fs-6 gap-0 list-unstyled mb-0 text-black-65">
                                        <li>1 stop</li>
                                        <li>{formatFlightTime(suggestion?.Outbound?.TripDuration,1)}</li>
                                        <li> {totolTraver()} Traveler</li>
                                    </ul>
                                    <button class="bg-transparent border-0 infoBtn text-secondary" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight"><i class="fa-solid fa-circle-info text-orange" aria-hidden="true"></i></button>
                                                <FlightDetails suggestion={suggestion} searchdata={searchdata}/>
                                </div>
                                <div class="card-body">
                                    <div class="departSec">
                                        <h6 class="poppins-semibold"><img src={`${process.env.PUBLIC_URL}/assets/images/take-off.png`} alt="img" class="img-fluid me-2" />{searchdata?.OriginAirportCode} - {searchdata?.DestinationAirportCode}</h6>
                                        <table class="table mb-0">
                                            <tbody>
                                                 {suggestion?.Outbound?.ListOfFlights?.map((innerflights, index) => renderItems(innerflights, index))}
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                    {suggestion?.Inbound != null && <div class="returnSec border-top pt-3">
                                       <h6 class="poppins-semibold"><img src={`${process.env.PUBLIC_URL}/assets/images/landing.png`} alt="img" class="img-fluid me-2" /> {searchdata?.DestinationAirportCode} - {searchdata?.OriginAirportCode}</h6>
                                        <table class="table mb-0">
                                            <tbody>
                                                {suggestion?.Inbound?.ListOfFlights?.map((innerflights, index) => renderItems(innerflights, index))}
                                            </tbody>
                                        </table>
                                    </div>}
                                    <div class="border-light fareSmry w-auto">
                                        <div class="bg-light-orange mb-2 mt-3 position-relative py-2 rounded-0 text-center">
                                            <h6 class="fs-6 mb-0 poppins-bold text-uppercase">Summary of Charges</h6>
                                        </div>
                                        <div class="chargesSumry">
                                            <table class="table mb-0">
                                                <tbody>
                                                    <tr>
                                                        <td class="border-0 px-0">Adult (1 X $512.96)</td>
                                                        <th class="border-0 px-0" scope="row">$512.<sup>96</sup></th>
                                                    </tr>
                                                    <tr>
                                                        <td class="border-0 px-0">Lap Infant</td>
                                                        <th class="border-0 px-0" scope="row">$59<sup>96</sup></th>
                                                    </tr>
                                                    <tr>
                                                        <td class="border-0 px-0">Child</td>
                                                        <th class="border-0 px-0" scope="row">$12<sup>96</sup></th>
                                                    </tr>
                                                    <tr>
                                                        <td class="border-0 border-top poppins-bold pt-2 px-0 text-black">Total Price (USD)</td>
                                                        <th class="border-0 border-top poppins-extrabold pt-2 px-0 text-secondary" scope="row">$522<sup>96</sup></th>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>;
};

export default BookingDetails;
