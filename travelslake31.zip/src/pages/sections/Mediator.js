// src/pages/Home.js
import {React,useState} from 'react';
import Search from '../Search.js';
const contactNumber = process.env.REACT_APP_DefaultContactNumber;

const Mediator = () => {
    const [isLoading, setIsLoading] = useState(true);

    return <div className="home">
            
            <div class="mainContent py-5">
            <div class="container">
            <div class="row text-center">
                <div class="col-12">
                    <img src={`${process.env.PUBLIC_URL}/assets/images/loadingPlane.gif`} alt="img" class="img-fluid loadingGif my-3" width="64" height="64" />
                    <h5 class="poppins-semibold mb-2 text-blue">Hold on, we’re fetching flights for you</h5>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-8 col-md-10 m-auto">
                    <div class=" bg-gray border cardDtlSec mt-3 pt-3 rounded-4">
                        <div class="row">
                            <div class="col text-center">
                                <h5 class="poppins-bold text-black">Speak to our travel experts now!</h5>
                                <h6 class="mb-3 fs-6">CALL US <strong>Toll-Free</strong> To Get the Best <span class="fs-5 text-orange poppins-bold">Unpublished Fares</span></h6>
                                <a href="tel:{contactNumber}" class="bg-white py-2 d-block fs-2 poppins-bold text-blue text-decoration-none"><img src={`${process.env.PUBLIC_URL}/assets/images/tel-icon.png`} alt="icon" class="img-fluid pe-3" width="56" height="56" />{contactNumber}</a>
                                <p class="text-orange mt-2 poppins-bold">(Available 24/7)</p>
                                <h6 class="mb-3">Advantages of booking through our travel experts:</h6>
                                <ul class="list-unstyled">
                                    <li class="mb-1"><img src={`${process.env.PUBLIC_URL}/assets/images/tick_orange.png`} alt="icon" class="pe-2" />Personalised Travel Recommendations.</li>
                                    <li class="mb-1"><img src={`${process.env.PUBLIC_URL}/assets/images/tick_orange.png`} alt="icon" class="pe-2" />24/7 connectivity with Customer Care
                                        Representatives</li>
                                    <li class="mb-1"><img src={`${process.env.PUBLIC_URL}/assets/images/tick_orange.png`} alt="icon" class="pe-2" />Secure and Reliable Payments</li>
                                    <li class="mb-3"><img src="assets/images/tick_orange.png" alt="icon" class="pe-2" />Exclusive Airfare Contracts and Deals</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
            </div>
            </div>;
};

export default Mediator;
