// src/pages/Home.js
import {React,useState} from 'react';

const Filters = () => {
    

    return <div class="col-lg-3">
                        <button class="btn btn-secondary bg-green-100 text-uppercase text-white d-lg-none w-100 mb-3" type="button" data-bs-toggle="collapse" data-bs-target="#collapsefilterSec" aria-expanded="false" aria-controls="collapsefilterSec">
                            Filter
                        </button>
                        <aside class="bg-white collapse d-lg-block filterSec mb-3 mb-lg-0 p-3 rounded-3 shadow" id="collapsefilterSec">

                            <div class="border-bottom filterBox mb-4">
                                <h6 class="mb-2 poppins-semibold">Stop</h6>
                                <div class="filterCheckboxSec">
                                    <ul class="d-inline-flex gap-2 list-unstyled mb-0 w-100">
                                        <li class="mb-1">
                                            <div class="fcBox form-check mb-0 overflow-hidden rounded-2 text-center">
                                                <label class="form-check-label w-100" for="flexCheckDefault1">
                                                    <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault1" checked="" />
                                                    <span>Non Stop</span>
                                                </label>
                                            </div>
                                        </li>
                                        <li class="mb-1">
                                            <div class="fcBox form-check mb-0 overflow-hidden rounded-2 text-center">
                                                <label class="form-check-label w-100" for="flexCheckDefault2">
                                                    <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault2" />
                                                    <span>One Stop
                                                    </span>
                                                </label>
                                            </div>
                                        </li>
                                        <li class="mb-1">
                                            <div class="fcBox form-check mb-0 overflow-hidden rounded-2 text-center">
                                                <label class="form-check-label w-100" for="flexCheckDefault3">
                                                    <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault3" />
                                                    <span>2+ Stop
                                                    </span>
                                                </label>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="border-bottom filterBox mb-4">
                                <h6 class="mb-2 poppins-semibold">Departure from</h6>
                                <div class="filterCheckboxSec">
                                    <ul class="list-unstyled mb-0 d-inline-flex flex-wrap w-100">
                                        <li class="w-50 p-1 mb-1">
                                            <div class="fcBox form-check mb-0 overflow-hidden rounded-pill text-center">
                                                <label class="form-check-label w-100" for="flexCheckDefault4">
                                                    <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault4" checked="" />
                                                    <span>Before 6AM</span>
                                                </label>
                                            </div>
                                        </li>
                                        <li class="w-50 p-1 mb-1">
                                            <div class="fcBox form-check mb-0 overflow-hidden rounded-pill text-center">
                                                <label class="form-check-label w-100" for="flexCheckDefault5">
                                                    <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault5" />
                                                    <span>6AM - 12PM
                                                    </span>
                                                </label>
                                            </div>
                                        </li>
                                        <li class="w-50 p-1 mb-1">
                                            <div class="fcBox form-check mb-0 overflow-hidden rounded-pill text-center">
                                                <label class="form-check-label w-100" for="flexCheckDefault6">
                                                    <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault6" />
                                                    <span>12PM - 6PM
                                                    </span>
                                                </label>
                                            </div>
                                        </li>
                                        <li class="w-50 p-1 mb-1">
                                            <div class="fcBox form-check mb-0 overflow-hidden rounded-pill text-center">
                                                <label class="form-check-label w-100" for="flexCheckDefault7">
                                                    <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault7" />
                                                    <span>After 6PM
                                                    </span>
                                                </label>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="border-bottom filterBox mb-4">
                                <h6 class="mb-3 poppins-semibold">Flight Price</h6>
                                <div class="filterCheckboxSec">
                                    <div class="rangeSlider">
                                        {/*} Range Silder */}
                                        <input type="range" class="form-range" id="priceRange" min="36" max="672" value="100" />
                                        <div class="minMaxLabel d-flex justify-content-between">
                                            <span id="minPrice">$36</span>
                                            <span id="maxPrice">$672</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="filterBox">
                                <h6 class="mb-3 poppins-semibold">Airlines</h6>
                                <div class="filterCheckboxSec">
                                    <ul class="list-unstyled mb-0" id="airlinesList">
                                        <li class="align-items-center d-flex justify-content-between">
                                            <div class="form-check mb-0">
                                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault1" checked="" />
                                                <label class="form-check-label" for="flexCheckDefault1">
                                                    Vistara
                                                </label>
                                            </div>
                                            <span class="filterCount">
                                                44
                                            </span>
                                        </li>
                                        <li class="align-items-center d-flex justify-content-between">
                                            <div class="form-check mb-0">
                                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault2" />
                                                <label class="form-check-label" for="flexCheckDefault2">
                                                    Air India
                                                </label>
                                            </div>
                                            <span class="filterCount">
                                                148
                                            </span>
                                        </li>
                                        <li class="align-items-center d-flex justify-content-between">
                                            <div class="form-check mb-0">
                                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault3" />
                                                <label class="form-check-label" for="flexCheckDefault3">
                                                    Air Asia
                                                </label>
                                            </div>
                                            <span class="filterCount">
                                                69
                                            </span>
                                        </li>
                                        <li class="align-items-center d-flex justify-content-between">
                                            <div class="form-check mb-0">
                                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault4" />
                                                <label class="form-check-label" for="flexCheckDefault4">
                                                    Vistara
                                                </label>
                                            </div>
                                            <span class="filterCount">
                                                44
                                            </span>
                                        </li>
                                        <li class="align-items-center d-flex justify-content-between">
                                            <div class="form-check mb-0">
                                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault5" />
                                                <label class="form-check-label" for="flexCheckDefault5">
                                                    Air India
                                                </label>
                                            </div>
                                            <span class="filterCount">
                                                44
                                            </span>
                                        </li>
                                        <li class="align-items-center d-flex justify-content-between">
                                            <div class="form-check mb-0">
                                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault6" />
                                                <label class="form-check-label" for="flexCheckDefault6">
                                                    Vistara
                                                </label>
                                            </div>
                                            <span class="filterCount">
                                                44
                                            </span>
                                        </li>
                                        <li class="align-items-center d-flex justify-content-between hidden">
                                            <div class="form-check mb-0">
                                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault7" />
                                                <label class="form-check-label" for="flexCheckDefault7">
                                                    Air India
                                                </label>
                                            </div>
                                            <span class="filterCount">
                                                104
                                            </span>
                                        </li>
                                        <li class="align-items-center d-flex justify-content-between hidden">
                                            <div class="form-check mb-0">
                                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault8" />
                                                <label class="form-check-label" for="flexCheckDefault8">
                                                    Air Asia
                                                </label>
                                            </div>
                                            <span class="filterCount">
                                                44
                                            </span>
                                        </li>
                                        <li class="align-items-center d-flex justify-content-between hidden">
                                            <div class="form-check mb-0">
                                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault5" />
                                                <label class="form-check-label" for="flexCheckDefault5">
                                                    Air India
                                                </label>
                                            </div>
                                            <span class="filterCount">
                                                44
                                            </span>
                                        </li>
                                        <li class="align-items-center d-flex justify-content-between hidden">
                                            <div class="form-check mb-0">
                                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault6" />
                                                <label class="form-check-label" for="flexCheckDefault6">
                                                    Vistara
                                                </label>
                                            </div>
                                            <span class="filterCount">
                                                44
                                            </span>
                                        </li>
                                    </ul>
                                    <div>
                                        <span class="fs-6 more-button" id="showMoreBtn">More <span class="icon">+</span></span>
                                        <span class="more-button hidden" id="showLessBtn">Less <span class="icon">-</span></span>
                                    </div>
                                    <button class="bg-gray border btn mt-4 px-2 py-1 reset-btn rounded-pill w-100" type="reset" value="Clear All">Clear All Filters</button>
                                </div>
                            </div>
                        </aside>
                    </div>;
};

export default Filters;
