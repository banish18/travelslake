// src/pages/Home.js
import React,{useState,useEffect} from 'react';
import { getFlightRecords,formatFlightTime,formatFlightDate } from '../../services';
import { useLocation,useNavigate } from 'react-router-dom'
const currSign = process.env.REACT_APP_Currsign;
const FlightDetails = ({suggestion,searchdata}) => {
    const navigate = useNavigate();


     useEffect(() => {
       
     },[]);
     const totolTraver = () => {

        return searchdata.AdultCount+searchdata.ChildCount+searchdata.InfantCount;
    }
    const getAfterdec = (n) => {
        console.log();
         const nn = Math.abs(n); // Change to positive
         const fd = nn - Math.floor(n);
         const finalval = fd.toFixed(2).split('.')
         return '.'+finalval[1];
    }
    const nextStep = (suggestion) => {
        
        navigate('/contact-info',{
                state: {'dealdata':suggestion,'searchdata':searchdata,'selectedsec':'contact'}
              });
    }
    return <div className="offcanvas offcanvas-end" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel" aria-modal="true" role="dialog">
                                                    <div className="border-bottom offcanvas-header">
                                                        <h5 className="offcanvas-title poppins-bold" id="offcanvasRightLabel">Review Flight Details</h5>
                                                        <button type="button" className="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                                                    </div>
                                                    <div className="offcanvas-body">
                                                        {suggestion?.Inbound != null && <ul className="border-0 gap-2 ittr-sec-tab mb-3 nav nav-tabs" id="myTab" role="tablist">
                                                        
                                                            <li className="nav-item" role="presentation">
                                                                <button className="nav-link active" id="departure-sec-tab" data-bs-toggle="tab" data-bs-target="#departure-sec" type="button" role="tab" aria-controls="departure-sec" aria-selected="true">Departure Flight</button>
                                                            </li>
                                                            <li className="nav-item" role="presentation">
                                                                <button className="nav-link" id="return-sec-tab" data-bs-toggle="tab" data-bs-target="#return-sec" type="button" role="tab" aria-controls="return-sec" aria-selected="false" tabindex="-1">Return Flight</button>
                                                            </li>
                                                        </ul> }
                                                        {suggestion?.Inbound == null && <ul className="border-0 gap-2 ittr-sec-tab mb-3 nav nav-tabs" id="myTab" role="tablist">
                                                        
                                                            <li className="nav-item" role="presentation">
                                                                <button className="nav-link active" id="departure-sec-tab" data-bs-toggle="tab" data-bs-target="#departure-sec" type="button" role="tab" aria-controls="departure-sec" aria-selected="true">Departure Flight</button>
                                                            </li>
                                                            
                                                        </ul> }
                                                        <div className="tab-content" id="myTabContent">
                                                            <div className="tab-pane fade active show" id="departure-sec" role="tabpanel" aria-labelledby="departure-sec-tab">
                                                                <div className="flightDtlContent">
                                                                    <div className="border-bottom d-flex justify-content-between pb-2">
                                                                        <div className="dstiTxt">
                                                                            <h6 className="poppins-bold mb-0 text-start">{searchdata?.OriginCityName} - {searchdata?.DestinationCityName}<span className="orange-text"></span></h6>
                                                                        </div>
                                                                        <div className="bggeTxt">
                                                                            <ul className="alrghtDtl barlow-regular d-inline-flex fs-6 gap-3 list-unstyled mb-0 text-black-65">
                                                                                <li>{suggestion?.Outbound?.Stops} stop</li>
                                                                                <li>{formatFlightTime(suggestion?.Outbound?.TripDuration,1)}</li>
                                                                                <li> {totolTraver()} Traveler</li>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                    {suggestion?.Outbound?.ListOfFlights?.map((innerflights, index) => (<div className="bg-white flight-box-mainwrq my-2 border-bottom pb-2">
                                                                        <div className="airlineBaggageDtl align-items-center d-flex justify-content-between mb-2">
                                                                            <div className="airCompany align-items-center d-flex pe-4">
                                                                                <img src={`${process.env.PUBLIC_URL}/assets/images/air01.png`} alt="air" className="rounded-circle" width="30" height="30" />
                                                                                <p className="airlineName poppins-semibold mb-0 ps-2 text-start">
                                                                                     {innerflights?.AirlineName}<br />
                                                                                    <span className="fs-6 poppins-regular text-black-50">{innerflights?.AirlineCode}</span>
                                                                                </p>
                                                                            </div>
                                                                            <div className="ite-date">
                                                                                <span className="mb-0 text-black-65 fs-6 poppins-regular">{formatFlightDate(innerflights?.ArrivalDate)}</span>
                                                                            </div>
                                                                        </div>
                                                                        <div className="row airbox-details align-items-center">
                                                                            <div className="col-3 col-sm-3 col-md-3 col-lg-3 col-xl-3 col-xxl-3 text-start pe-0">
                                                                                <h5 className="poppins-bold mb-0">{formatFlightTime(innerflights?.DepartureTime,2)}</h5>
                                                                                <p className="mb-0">{innerflights?.OriginCityName} - {innerflights?.DestinationCityName}</p>
                                                                            </div>
                                                                            <div className="col-6 col-sm-6 col-md-6 col-lg-6 col-xl-6 col-xxl-6">
                                                                                <div className="align-items-center border-left d-flex routeDtlSec w-100">
                                                                                    <div className="pe-3 routeOrigin text-end">
                                                                                        <h5 className="mb-0 pe-3 poppins-semibold timeLoc">
                                                                                            {formatFlightTime(innerflights?.DepartureTime,3)}
                                                                                            <span className="routeloc d-block fs-6 text-black-65">
                                                                                                {innerflights?.OriginAirport}
                                                                                            </span>
                                                                                        </h5>
                                                                                    </div>
                                                                                    <div className="routPath w-50">
                                                                                        <span className="text-black-65">{formatFlightTime(innerflights?.FlightDuration,1)}</span>
                                                                                        <div className="routPathLine position-relative">
                                                                                        </div>
                                                                                        <ul className="alrghtDtl barlow-regular d-inline-flex fs-6 gap-3 list-unstyled mb-0 text-black-65">
                                                                                            <li className="px-0">Flight | {innerflights?.FlightNumber}</li>
                                                                                            
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div className="ps-3 routeDest">
                                                                                        <h5 className="mb-0 poppins-semibold ps-3 timeLoc">
                                                                                            {formatFlightTime(innerflights?.ArrivalTime,3)}
                                                                                            <span className="routeloc d-block fs-6 text-black-65">
                                                                                                {innerflights?.DestinationAirport}
                                                                                            </span>
                                                                                        </h5>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div className="col-3 col-lg-3 col-md-3 col-sm-3 col-xl-3 col-xxl-3 ps-0 text-start">
                                                                                <h5 className="poppins-bold mb-0">{formatFlightTime(innerflights.ArrivalTime,2)}</h5>
                                                                                <p className="mb-0">{innerflights?.OriginCityName} - {innerflights?.DestinationCityName}</p>
                                                                            </div>
                                                                        </div>
                                                                    </div> ))}
                                                                    {/* <div className="bg-light-orange cabiOtherDtl my-4 position-relative py-2 text-center">
                                                                        <ul className="baggageDtl d-inline-flex justify-content-around list-unstyled mb-0 w-100">
                                                                            <li>Baggage: <span className="text-black-50">Adult</span></li>
                                                                            <li>Check In: <span className="text-black-50">0 Kg</span></li>
                                                                            <li>Cabin: <span className="text-black-50">7 Kgs</span></li>
                                                                        </ul>
                                                                    </div> */}
                                                                </div>
                                                            </div>
                                                            {suggestion?.Inbound != null && <div className="tab-pane fade" id="return-sec" role="tabpanel" aria-labelledby="return-sec-tab">
                                                                <div className="flightDtlContent">
                                                                    <div className="border-bottom d-flex justify-content-between pb-2">
                                                                        <div className="dstiTxt">
                                                                            <h6 className="poppins-bold mb-0 text-start">{searchdata?.OriginCityName} - {searchdata?.DestinationCityName}<span className="orange-text"></span></h6>
                                                                        </div>
                                                                        <div className="bggeTxt">
                                                                            <ul className="alrghtDtl barlow-regular d-inline-flex fs-6 gap-3 list-unstyled mb-0 text-black-65">
                                                                                <li>{suggestion?.Inbound?.Stops} stop</li>
                                                                                <li>{formatFlightTime(suggestion?.Inbound?.TripDuration,1)}</li>
                                                                                <li> {totolTraver()} Traveler</li>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                    {suggestion?.Inbound?.ListOfFlights?.map((innerflights, index) => (<div className="bg-white flight-box-mainwrq my-2 border-bottom pb-2">
                                                                        <div className="airlineBaggageDtl align-items-center d-flex justify-content-between mb-2">
                                                                            <div className="airCompany align-items-center d-flex pe-4">
                                                                                <img src={`${process.env.PUBLIC_URL}/assets/images/air01.png`} alt="air" className="rounded-circle" width="30" height="30" />
                                                                                <p className="airlineName poppins-semibold mb-0 ps-2 text-start">
                                                                                     {innerflights?.AirlineName}<br />
                                                                                    <span className="fs-6 poppins-regular text-black-50">{innerflights?.AirlineCode}</span>
                                                                                </p>
                                                                            </div>
                                                                            <div className="ite-date">
                                                                                <span className="mb-0 text-black-65 fs-6 poppins-regular">{formatFlightDate(innerflights?.ArrivalDate)}</span>
                                                                            </div>
                                                                        </div>
                                                                        <div className="row airbox-details align-items-center">
                                                                            <div className="col-3 col-sm-3 col-md-3 col-lg-3 col-xl-3 col-xxl-3 text-start pe-0">
                                                                                <h5 className="poppins-bold mb-0">{formatFlightTime(innerflights?.DepartureTime,2)}</h5>
                                                                                <p className="mb-0">{innerflights?.OriginCityName} - {innerflights?.DestinationCityName}</p>
                                                                            </div>
                                                                            <div className="col-6 col-sm-6 col-md-6 col-lg-6 col-xl-6 col-xxl-6">
                                                                                <div className="align-items-center border-left d-flex routeDtlSec w-100">
                                                                                    <div className="pe-3 routeOrigin text-end">
                                                                                        <h5 className="mb-0 pe-3 poppins-semibold timeLoc">
                                                                                            {formatFlightTime(innerflights?.DepartureTime,3)}
                                                                                            <span className="routeloc d-block fs-6 text-black-65">
                                                                                                {innerflights?.OriginAirport}
                                                                                            </span>
                                                                                        </h5>
                                                                                    </div>
                                                                                    <div className="routPath w-50">
                                                                                        <span className="text-black-65">{formatFlightTime(innerflights?.FlightDuration,1)}</span>
                                                                                        <div className="routPathLine position-relative">
                                                                                        </div>
                                                                                        <ul className="alrghtDtl barlow-regular d-inline-flex fs-6 gap-3 list-unstyled mb-0 text-black-65">
                                                                                            <li className="px-0">Flight </li>
                                                                                            <li className="px-0">{innerflights?.FlightNumber}</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div className="ps-3 routeDest">
                                                                                        <h5 className="mb-0 poppins-semibold ps-3 timeLoc">
                                                                                            {formatFlightTime(innerflights?.ArrivalTime,3)}
                                                                                            <span className="routeloc d-block fs-6 text-black-65">
                                                                                                {innerflights?.DestinationAirport}
                                                                                            </span>
                                                                                        </h5>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div className="col-3 col-lg-3 col-md-3 col-sm-3 col-xl-3 col-xxl-3 ps-0 text-start">
                                                                                <h5 className="poppins-bold mb-0">{formatFlightTime(innerflights.ArrivalTime,2)}</h5>
                                                                                <p className="mb-0">{innerflights?.OriginCityName} - {innerflights?.DestinationCityName}</p>
                                                                            </div>
                                                                        </div>
                                                                    </div> ))}
                                                                    {/* <div className="bg-light-orange cabiOtherDtl my-4 position-relative py-2 text-center">
                                                                        <ul className="baggageDtl d-inline-flex justify-content-around list-unstyled mb-0 w-100">
                                                                            <li>Baggage: <span className="text-black-50">Adult</span></li>
                                                                            <li>Check In: <span className="text-black-50">0 Kg</span></li>
                                                                            <li>Cabin: <span className="text-black-50">7 Kgs</span></li>
                                                                        </ul>
                                                                    </div> */}
                                                                </div>
                                                            </div> }
                                                        </div>
                                                        <h5 className="poppins-bold text-start mt-4">This itinerary includes a self-transfer</h5>
                                                        <p className="text-start">Our self-transfer hack helps you reach any destination by connecting separate flights. Since these flights are officially independent from one another, you might need to leave the transit zone:</p>
                                                        <ul className="fs-6 list-group-item-info pe-3 py-4 rounded-1 text-start">
                                                            <li className="mb-2">If you have&nbsp;<b>checked baggage</b>, you’ll need to collect it and recheck it</li>
                                                            <li className="mb-2">If you don’t have a <b>boarding pass for your next flight</b>, you’ll need to check in for that flight.</li>
                                                            <li className="mb-2">In some cases, you’ll need to go through <b>passport control</b> again as if you’d be entering the country, so you might need a&nbsp;visa.</li>
                                                            <li>Check the&nbsp;<b>airport terminal</b> for your next flight, as it might be different from the one you landed at.</li>
                                                        </ul>
                                                    </div>
                                                    <div className="bg-gray flightPriceDtl px-3 py-3">
                                                        <div className="align-items-center me-0 ms-0 row">
                                                            <div className="col-6 col-sm-6 col-md-6 col-lg-6 col-xl-6 col-xxl-6 ps-0 text-start">
                                                                <h3 className="mb-0 poppins-bold">{currSign}${Math.floor(suggestion?.TotalFare)}<sup>{getAfterdec(suggestion?.TotalFare)}</sup><span className="fs-6 poppins-regular-italic ps-2 text-black-50">Fare / person</span></h3>
                                                            </div>
                                                            <div className="col-6 col-sm-6 col-md-6 col-lg-6 col-xl-6 col-xxl-6 text-end pe-0"><a type="button" className="border-0 btn btn-primary flsBookingNowBtn px-4 py-2 rounded-pill text-uppercase text-white" onClick={() => nextStep(suggestion)}>Book Now</a></div>
                                                        </div>
                                                    </div>
                                                </div>;
};

export default FlightDetails;
