import React,{useState} from "react";

const SearchModal = ({ isOpen, onClose, title, children }) => {
    const [email, setEmail] = useState('');
    const [error, setError] = useState('');
    const [submitted, setSubmitted] = useState(false);
    if (!isOpen) return null;
    

    const validateEmail = (email) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        if (!validateEmail(email)) {
            setError('Please enter a valid email address.');
            setSubmitted(false);
        } else {
            setError('');
            
            setSubmitted(true);
            console.log('Form submitted successfully:', email);
        }
        


    };

    return (
        <div class="modal" id="fareAlertModal" tabindex="-1" style={{display : "block"}} aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="border-0 modal-header p-0">
                            <div class="bg-blue-200 modalHdrSec pt-4 px-3 rounded-top text-center w-100">
                                <div class="mb-2 mhsTxt">
                                    <h3 class="mb-1 poppins-bold text-primary">Do you want to book more!</h3>
                                </div>
                                <img src={`${process.env.PUBLIC_URL}/assets/images/price-alert.gif`} alt="icon" class="img-fluid timerGif" width="100" />
                            </div><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" onClick={onClose}></button>
                        </div>
                        <div class="modal-body p-0 p-4 rounded text-center">
                            
                            <div class="input-group my-3">
                            <form onSubmit={handleSubmit} className="form-control mt-3">
                                <input type="email" class="bg-light border form-control rounded w-100" id="email" placeholder="Enter email" value={email} onChange={(e) => setEmail(e.target.value)}  />
                                {error && <p style={{ color: 'red', marginBottom: '10px' }}>{error}</p>}
                                <button class="border-0 btn btn-primary fareAlertBtn mt-3 p-2 poppins-bold rounded text-white w-100" type="submit">Get More Tickets!</button>
                                {submitted && <p style={{ color: 'green', marginBottom: '10px' }}>Email submitted successfully!</p>}  
                                </form>
                            </div>
                           
                            <p class="mb-0 text-start">By entering your email address you agree to TravelSlake's <a href="#" class="text-red">Terms and Conditions</a>, <a href="#" class="text-red">Privacy Policy</a> and to receive email marketing.</p>

                        </div>
                    </div>
                </div>
            </div>
    );
};

export default SearchModal;