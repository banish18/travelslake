import React,{useState} from "react";
const contactNumber = process.env.REACT_APP_DefaultContactNumber;
const ExpireModal = ({ isOpen, onClose, launchSearch, title }) => {
    const [email, setEmail] = useState('');
    const [error, setError] = useState('');
    const [submitted, setSubmitted] = useState(false);
    if (!isOpen) return null;
    

    const validateEmail = (email) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        if (!validateEmail(email)) {
            setError('Please enter a valid email address.');
            setSubmitted(false);
        } else {
            setError('');
            
            setSubmitted(true);
            console.log('Form submitted successfully:', email);
        }
        


    };

    return (
        <div className="modal  mt-4" id="fareAlertModal" tabindex="-1" style={{display : "block"}} aria-hidden="true">
<div className="modal-dialog modal-lg">
   <div className="modal-content">
      
      <div className="modal-body  rounded ">
         <div className="row ">
            <div className="col-7">
               <div className="px-4">
                  <div className="mb-2 mhsTxt">
                     <h3 className="mb-1 poppins-bold">Your result has been expired!!</h3>
                     <span>Please go to the home page and initiate a new search.</span>
                  </div>
                  <div className="contactNo mb-3">
                     <a href="/" className="border-0 fw-normal btn btn-primary  fs-6 px-4 text-white">Go to Homepage</a>
                     <button type="button" id="timeoutmodal-relanch-btn" className="border-0 fw-normal btn btn-success fs-6 px-4 text-white ms-3" onClick={launchSearch}>Relaunch Search</button>
                  </div>
               </div>
               <div className="p-4 pt-0">
                  <h4 className="text-center text-md-start">
                     Speak to our travel experts now
                  </h4>
                  <p className="text-center text-md-start fs-6">
                     CALL US Toll-Free To Get the Best <span className="font-500"> Unpublished Fares</span>
                  </p>
                  <a href="tel:{contactNumber}" className="bg-white py-2 d-block fs-2 poppins-bold text-blue text-decoration-none"><img src={`${process.env.PUBLIC_URL}/assets/images/tel-icon.png`} alt="icon" className="img-fluid pe-3" width="56" height="56" />{contactNumber}</a>
                  <div className="input-group my-3">
                     <form onSubmit={handleSubmit} className="form-control mt-3">
                        <input type="email" className="bg-light border form-control rounded w-100" id="email" placeholder="Enter email" value={email} onChange={(e) => setEmail(e.target.value)}  />
                        {error && <p style={{ color: 'red', marginBottom: '10px' }}>{error}</p>}
                        <button className="border-0 btn btn-primary fareAlertBtn mt-3 p-2 poppins-bold rounded text-white w-100" type="submit">Get More Tickets!</button>
                        {submitted && <p style={{ color: 'green', marginBottom: '10px' }}>Email submitted successfully!</p>}  
                     </form>
                  </div>
                </div> 
                </div> 
                <div className="col-5">
                 <div className="searchFoundGraphics text-center mb-2 mb-md-0">
                    <img src={`${process.env.PUBLIC_URL}/assets/images/callcentric-img.png`} alt="img" className="img-fluid" />
                 </div>
                </div>
               
               <p className="mb-0 text-start">By entering your email address you agree to TravelSlake's <a href="#" className="text-red">Terms and Conditions</a>, <a href="#" className="text-red">Privacy Policy</a> and to receive email marketing.</p>
            
         </div>
      </div>
   </div>
</div>
</div>
    );
};

export default ExpireModal;