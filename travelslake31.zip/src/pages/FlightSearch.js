// src/pages/Home.js
import {React,useState,useEffect} from 'react';
import Mediator from './sections/Mediator.js';
import { useLocation,useNavigate } from 'react-router-dom';
import { getFlighttoken } from '../services';
import Search from './Search.js';
const FlightSearch = ({route}) => {
    const { search,state } = useLocation();
    const navigate = useNavigate();
    const [isLoading, setIsLoading] = useState(true);
    const [searchdata, setSearchdata] = useState([]);
    const [isshowSearch, setIsshowSearch] = useState(true);

    useEffect(() => {
        getFlightToken();
        
    },[]);

    const getFlightToken = () => {

        const query = new URLSearchParams(search);
        getFlighttoken(query).then(res => {
            console.log(res)
            if(res.data.IsSuccess){
                navigate('/flights?sid='+res.data.Model,{
                    state: {'dealdata':{}}
                });
            }else{
                setIsLoading(false);
                navigate('/no-records');
            }
        }).catch(err => {
        console.error("Error fetching data:", err);
        });
    }
   
    return <div className="home">
            
            {isLoading && <Mediator /> }
            
            </div>;
};

export default FlightSearch;
