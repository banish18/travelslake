// src/pages/Home.js
import React,{useState,useEffect,useRef} from 'react';
import { getSeatchrecords } from '../services';
import { useNavigate,useLocation } from 'react-router-dom'
const contactNumber = process.env.REACT_APP_DefaultContactNumber;

const BookingConfirmation = () => {
    const navigate = useNavigate();
    const { state } = useLocation();
    const [error, setError] = useState("");
    const [selectedOption, setSelectedOption] = useState('roundtrip');

    const dealsRec = state?.dealdata;
   useEffect(() => {
        console.log('helo');
    }, []);

  
    const handleRadioChange = (event) => {
        setSelectedOption(event.target.value);
    };

    const nextStep = () => {
        navigate('/confirmation',{
                state: {'dealdata':dealsRec}
              });
    }
    return <React.Fragment><div class="ipHeroSetion bg-gray">
            <div class="container position-relative py-5">
                <div class="mx-auto">
                    <div class="doneIco"><i class="las la-check"></i></div>
                    <div class="confirmTxtDtl ps-4">
                        <h3 class="text-center mb-1 poppins-extrabold">Booking Successful!</h3>
                        <p class="conSubTitle text-secondary poppins-medium mb-0 text-center">Your Trip has been booked successfully! Your Booking Reference number is <span class="text-primary poppins-semibold">45706</span></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="mainContent py-5">
<div class="container">
                <div class="row">
                    <div class="col-12">
                        <h3 class="mb-2 poppins-extrabold text-black">Dear John Doe,</h3>
                        <p>Thank You For Booking With Us. Your Payment Has Been Submitted. Your E-Ticket Will Be Emailed Shortly After Your Corangeit Card Verification Has Been Completed. You Will Soon Receive An Email Confirmation With Your E-Ticket.</p>
                        <p class="mb-4"><span class="text-primary poppins-semibold">Note:</span> We Are Processing Your Reservation And Will Send You Confirmation Once This Has Been Completed And A Ticket Has Been Issued.</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-9 pe-lg-4">
                        <div class="bg-white cardDtlSec mb-4 rounded">
                            <h5 class="poppins-semibold">Customer Details</h5>
                            <div class="row">
                                <div class="col-md-6">
                                    <p>Customer name: <span class="poppins-semibold">Demo Customer 01</span></p>
                                </div>
                                <div class="col-md-6">
                                    <p>Mobile No: <span class="poppins-semibold">0123-456-789</span></p>
                                </div>
                                <div class="col-md-6">
                                    <p>Email: <span class="poppins-semibold">param@firstatom.org</span></p>
                                </div>
                                <div class="col-md-6">
                                    <p>Booked On: <span class="poppins-semibold">26 Feb 2024</span></p>
                                </div>
                                <div class="col-md-6">
                                    <p>Address: <span class="poppins-semibold">48 Al Majarrah Street</span></p>
                                </div>
                            </div>
                        </div>
                        <div class="bg-white cardDtlSec mb-4 rounded">
                            <div class="rounded travelersSecDtl">
                                <h5 class="poppins-semibold">Traveler #1</h5>
                                <div class="bg-gray mb-3 p-3 rounded traInfo">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <p>Customer name: <span class="poppins-semibold">Demo Customer 01</span></p>
                                        </div>
                                        <div class="col-md-6">
                                            <p>DOB: <span class="poppins-semibold">01 Feb, 1998</span></p>
                                        </div>
                                        <div class="col-md-6">
                                            <p>Type: <span class="poppins-semibold">ADULT</span></p>
                                        </div>
                                        <div class="col-md-6">
                                            <p>Gender: <span class="poppins-semibold">MALE</span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="rounded travelersSecDtl">
                                <h5 class="poppins-semibold">Traveler #2</h5>
                                <div class="bg-gray p-3 rounded traInfo">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <p>Customer name: <span class="poppins-semibold">Demo Customer 01</span></p>
                                        </div>
                                        <div class="col-md-6">
                                            <p>DOB: <span class="poppins-semibold">01 Feb, 1998</span></p>
                                        </div>
                                        <div class="col-md-6">
                                            <p>Type: <span class="poppins-semibold">ADULT</span></p>
                                        </div>
                                        <div class="col-md-6">
                                            <p>Gender: <span class="poppins-semibold">MALE</span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="border-bottom cardDtlSec mb-4 pb-2 rounded">
                            <h5 class="poppins-semibold">Flight Details</h5>
                            <h6 class="text-uppercase fs-6 text-black-65">Departing Wed, February 28 </h6>
                            <div class="row">
                                <div class="col-md-6">
                                    <p class="text-black-65">Airlines: <span class="poppins-semibold text-black">Air India</span> (6E-5045)</p>
                                </div>
                                <div class="col-md-6">
                                    <p class="text-black-65">Duration: <span class="poppins-semibold text-black">07:10pm - 11:15pm</span>(04h 50m)</p>
                                </div>
                                <div class="col-md-6">
                                    <p class="text-black-65">Departing Airport: <span class="poppins-semibold text-black">HKG</span>Hong Kong International AirportT1</p>
                                </div>
                                <div class="col-md-6">
                                    <p class="text-black-65">Arriving Airport: <span class="poppins-semibold text-black">TPE</span>Taipei Taiwan Taoyuan International AirportT1</p>
                                </div>
                            </div>
                        </div>
                        <div class="bg-white border-bottom cardDtlSec mb-4 pb-2 rounded">
                            <h5 class="poppins-semibold">Ticket Policies, Rules And Restrictions</h5>
                            <p>Once purchased, all tickets are consideorange non-refundable and non-transferable. All service fees are non-refundable. Name changes are not permitted. Prices do not include Baggage and Carry-On Fees or other fees charged directly by the airline. Fares are not guaranteed until ticketed. All changes are subject to availability, additional fees, as per the airline's rules and regulations.</p>
                            <p>All travelers must confirm that their travel documents requiorange are current and valid for Travel (Destination Specific).</p>
                        </div>
                        <div class="bg-white border-bottom cardDtlSec mb-4 pb-2 rounded">
                            <h5 class="poppins-semibold">Changes</h5>
                            <p>Call us Toll Free at <a href="tel:{contactNumber}" class="text-orange poppins-medium">{contactNumber}</a>. If you are outside the US/Canada please call 1-800-301-4346 to make any kind of changes in the itinerary. Fees will apply due to airline's penalty, fare difference and other factors in order to change the itinerary. Please read important information regarding airlines liability limitations (airlines specific). For fare pricing, view our terms and conditions and airline Fare Rule. Your corangeit card may be billed in multiple charges totaling the above amount.
                                For more information kindly refer to our Terms and Conditions.</p>
                            <p>For more information kindly refer to our Terms and Conditions.</p>
                        </div>
                        <div class="bg-white border-bottom cardDtlSec mb-4 pb-2 rounded">
                            <h5 class="poppins-semibold">Customer Support</h5>
                            <p>If you have any query regarding your reservation, please use our customer support form OR email us at </p>
                            <p>For immediate assistance please call: <a href="tel:{contactNumber}" class="text-orange poppins-medium">{contactNumber}</a>.</p>
                            <p>Thank you for using Travelslake.</p>
                        </div>
                        <div class="bg-white cardDtlSec mb-4 rounded">
                            <h5 class="poppins-semibold">Charge Authorization, Your Electronic Signature Copy</h5>
                            <ul>
                                <li>I, Testing Testing agree to pay a total amount of 74.745 VI ****1111 for the above confirmed itinerary.
                                </li>
                                <li>I have confirmed the dates, times of the flight departures and names of travelers are accurate.
                                </li>
                            </ul>
                            <p class="poppins-semibold mb-0 mt-3">
                                I have read the Terms and Conditions and I understand that:
                            </p>
                            <ul>
                                <li>Most fares and taxes, are non-refundable and service fee is non-refundable, the tickets are non-transferable and name changes on the tickets are not permitted.
                                </li>
                                <li>All government taxes and Travelslake service fees are included in the total amount charged.
                                </li>
                                <li>Date and routing changes will be subject to the airline's penalty, fare difference and our service fees.
                                </li>
                                <li>I understand this is to serve as my legal signature.
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="shadow-none tripFareSmry">
                            <div class="border border-light card fareSmry w-auto mb-3">
                                <div class="bg-light-orange card-header position-relative py-2 text-center">
                                    <h6 class="text-uppercase poppins-semibold mb-0"> Trip Fare Summary</h6>
                                </div>
                                <div class="card-body">
                                    <table class="table mb-0">
                                        <tbody>
                                            <tr>
                                                <td class="border-0 px-0">Adult (1 X $512.96)</td>
                                                <th class="border-0 px-0" scope="row">$512.<sup>96</sup></th>
                                            </tr>
                                            <tr>
                                                <td class="border-0 px-0">Lap Infant</td>
                                                <th class="border-0 px-0" scope="row">$59<sup>96</sup></th>
                                            </tr>
                                            <tr>
                                                <td class="border-0 px-0">Child</td>
                                                <th class="border-0 px-0" scope="row">$12<sup>96</sup></th>
                                            </tr>
                                            <tr>
                                                <td class="border-0 px-0 text-black poppins-extrabold border-top">Total Price (USD)</td>
                                                <th class="border-0 px-0 text-secondary poppins-extrabold border-top" scope="row">$522<sup>96</sup></th>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="cardDtlSec card bg-gray p-3 rounded printSec">
                                <p class="mb-0">Please <a href="#" class="text-orange poppins-medium">print</a> and keep this receipt. Your corangeit card may be billed in multiple charges totaling the above amount. Some airlines may charge <a href="#" class="text-orange poppins-medium">Baggage Fees</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       </React.Fragment>;
};

export default BookingConfirmation;
