// src/pages/Home.js
import React,{useState,useEffect,useRef} from 'react';
//import DatePicker from 'react-datepicker';
import { DateRangePicker,Calendar  } from 'react-date-range';
import { format,addDays   } from 'date-fns';
import { enGB } from "date-fns/locale";

import { getSeatchrecords } from '../services';
import SearchModal from './modals/SearchModal.js'
import 'react-date-range/dist/styles.css'; // main css file
import 'react-date-range/dist/theme/default.css'; // theme css file
import { useNavigate } from 'react-router-dom'



const Search = ({ishowHeading,props,preData,launchSearch}) => {
     const myInput = useRef(null);
    const navigate = useNavigate()
    // Calculate 15 days from today
    const fifteenDaysFromToday = new Date();
    fifteenDaysFromToday.setDate(fifteenDaysFromToday.getDate() + 15);
     
    const [showDatePicker, setShowDatePicker] = useState(false);
    const [showCalanderPicker, setShowCalanderPicker] = useState(false);
    const [startDate, setStartDate] =  useState(null);
    const [endDate, setEndDate] = useState(null);
    const [selectedOption, setSelectedOption] = useState('roundtrip');
    const [isround, setIsround] = useState(true);
    const [departfrom, setDepartfrom] = useState('');
    const [departfromcode, setDepartfromcode] = useState('');
    const [arivesat, setArivesat] = useState('');
    const [arivesatcode, setArivesatcode] = useState('');
    const [rticon, setRticon] = useState(false);
    const [isOpen, setIsOpen] = useState(false);
    const [isOpenchild, setIsOpenchild] = useState(false);
    const [flightclassval, setFlightclassval] = useState('Economy');
    const [adultcount, setAdultcount] = useState(1);
    const [childcount, setChildcount] = useState(0);
    const [infantcount, setInfantcount] = useState(0);
    const [totalPassanger, setTotalPassanger] = useState(1);
    const dropdownRef = useRef(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [searcherrclass, setSearcherrclass] = useState(false);
    const [derror, setDerror] = useState('');
    const [aerror, setAerror] = useState('');
    const [aderror, setAderror] = useState('');
    const [rderror, setRderror] = useState('');
    const [submitted, setSubmitted] = useState(false);
    const [suggestions, setSuggestions] = useState([]);
    const [dsuggestions, setDsuggestions] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
      const [error, setError] = useState("");


// Format the selected date to show in the input field
    const formattedStartDate = startDate ? format(startDate, "dd-MM-yyyy") : format(new Date(), "dd-MM-yyyy") ;
    const formattedEndDate = endDate ? format(endDate, "dd-MM-yyyy") : "";
   const [state, setState] = useState([
      {
        startDate: new Date(),
        endDate: addDays(new Date(), 7),
        key: 'selection'
      }
    ]);

   useEffect(() => {
      
    setStartDate(new Date());
    console.log('user');
    console.log(preData);

    
    if(preData != null && Object.keys(preData).length != 0){
        setDepartfrom(preData.Origin);
        setArivesat(preData.Destination);
        setStartDate(new Date(preData.DepartureDate));
        setEndDate(new Date(preData.ReturnDate));
        setAdultcount(preData.AdultCount);
        setChildcount(preData.ChildCount);
        setInfantcount(preData.InfantCount);
        setDepartfromcode(preData.OriginAirportCode);
        setArivesatcode(preData.DestinationAirportCode);
        const totalPass =  preData.AdultCount+preData.ChildCount+preData.InfantCount;
        setTotalPassanger(totalPass);
        let tripClass = preData.ClassType;
        if(tripClass == '1'){
            setFlightclassval('Economy');
        }else if(flightclassval == '2'){
             setFlightclassval('Business');
        }else if(flightclassval == '3'){
            setFlightclassval('First');
        }else if(flightclassval == '4'){
            setFlightclassval('Premium');
        }
        setSelectedOption(preData.tripType);
        if(preData.tripType == 2){
            setIsround(true);
        }
        
    }

    if(launchSearch == true){
        myInput?.current?.click();
    }
    
    }, [launchSearch]);

  
    const handleRadioChange = (event) => {
        setSelectedOption(event.target.value);
        
        if(event.target.value != 'roundtrip'){
            setIsround(false);
        }else{
            setIsround(true);
        }
    };


    const fetchSuggestions = async (query,iFor) => {
        if (!query) {
          setSuggestions([]);
          return;
        }

        setIsLoading(true);
        setError("");

        getSeatchrecords(query).then(res => {

        console.log(res)
        if(iFor == 1){
            setSuggestions(res.data.Model || []); // Adjust based on your API response
        }else{
            setDsuggestions(res.data.Model || []); // Adjust based on your API response
        }
        

      }).catch(err => {
        console.error("Error fetching data:", err);
      });


      };

      const handleChange = (e) => {
        const value = e.target.value;
        setDepartfrom(value);
        fetchSuggestions(value,1);
        setDerror('')
      };

      const handleSuggestionClick = (suggestion) => {
        setDepartfromcode(suggestion.AirportCode);
        setDepartfrom(suggestion.AutoSuggest);
        setSuggestions([]);
      };

      const handledChange = (e) => {
        const value = e.target.value;
        setArivesat(value);
        fetchSuggestions(value,2);

        setAerror('')
      };

      const handledSuggestionClick = (suggestion) => {
        setArivesatcode(suggestion.AirportCode);
        setArivesat(suggestion.AutoSuggest);
        setDsuggestions([]);
      };

     const handelShowdatepicker = (elm) =>{
        setShowDatePicker(elm)
         setIsOpen(false);
    }

    const ClearField = (elm) => {
        if(elm == 1){
            setDepartfrom('');
            setSuggestions([]);
        }else{
            setArivesat('');
            setDsuggestions([]);
        }
        
    }



    const closeModal = () => {
        setIsModalOpen(false)
    }

    const handelPassangerCount = (tp,isFor) => {
        if(tp == 1){
            if(isFor == 'adult' && adultcount < 9 && totalPassanger < 9){
                setAdultcount(adultcount+1);
                setTotalPassanger(totalPassanger+1)
                
            }else if(isFor == 'child' && childcount < 9 && totalPassanger < 9){
                setChildcount(childcount+1)
                setTotalPassanger(totalPassanger+1)
                if(childcount == 9){
                    setIsModalOpen(true)
                }
            }else if(isFor == 'infant' && infantcount < 1 && totalPassanger < 9) {
                setInfantcount(infantcount+1)
                setTotalPassanger(totalPassanger+1)
            }
        }else{
            if(isFor == 'adult' && adultcount > 0){
                setAdultcount(adultcount-1)
                setTotalPassanger(totalPassanger-1)
            }else if(isFor == 'child' && childcount > 0){
                setChildcount(childcount-1)
                setTotalPassanger(totalPassanger-1)
            }else if(isFor == 'infant' && infantcount > 0){
                setInfantcount(infantcount-1)
                setTotalPassanger(totalPassanger-1)
            }

        }

        if(totalPassanger == 9 ){
            setIsModalOpen(true)
        }
    }

    const handleToggle = () => {
        setIsOpen(!isOpen);
        setShowDatePicker(false);
    };

    const donehandleToggle = () => {
        setIsOpen(false);
    };

    const handleInsideClick = (e) => {
        // Prevent the dropdown from closing
        e.stopPropagation();
    }; 

    const handleInsidechildClick = (e) => {
        // Prevent the dropdown from closing
        setIsOpenchild(!isOpenchild);

    }; 

    const handleChildToggle = (e) => {
        // Prevent the dropdown from closing
        setIsOpenchild(!isOpenchild);
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        setSearcherrclass(false);
        setSearcherrclass(false);

        setDerror('')
        setAerror('')
        setAderror('')
        setRderror('')


        if('' == departfrom){
           setSearcherrclass(true); 
            setDerror('Enter Depart From');
            setSubmitted(false);
        }else if('' == arivesat){
           setSearcherrclass(true);
            setAerror('Enter Arives At');
            setSubmitted(false); 
        }else if(null == startDate){
           setSearcherrclass(true);
            setAderror('Enter departure date');
            setSubmitted(false); 
        }else if(null == endDate && isround){

            setSearcherrclass(true);
            setRderror('Enter retun date');
            setSubmitted(false); 
        }else{

            const formData = {'departfrom':departfrom,'arivesat':arivesat,'startdate':startDate,'enddate':endDate,'adultcount':adultcount,'childcount':childcount,'infantcount':infantcount,'tripType':selectedOption,'totalPassanger':totalPassanger}
            const depon = format(startDate, "dd-MM-yyyy");
            let reton = '';

            if(isround == true){
                 reton = format(endDate, "dd-MM-yyyy");
            }
            
             
            let tripClass = 1;
            if(flightclassval == 'Business'){
                tripClass = 2;
            }else if(flightclassval == 'First'){
                 tripClass = 3;
            }else if(flightclassval == 'Premium'){
                 tripClass = 4;
            }
            navigate('/flightsearch?org='+departfromcode+'&des='+arivesatcode+'&depon='+depon+'&reton='+reton+'&adt='+adultcount+'&chd='+childcount+'&inf='+infantcount+'&class='+tripClass+'',{
                state: {'formdata':formData}
              })
            window.location.reload();
        }
    };

    const setFlightclass = (fClass) => {
        setFlightclassval(fClass);
    }

    
  

    const currentDate = new Date();
    currentDate.setDate(currentDate.getDate() + 1);
    const getCurrentDate = new Intl.DateTimeFormat('en-GB', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
    }).format(currentDate);

    const retDate = new Date();
    retDate.setDate(retDate.getDate() + 15);
    const getRetDate = new Intl.DateTimeFormat('en-GB', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
    }).format(retDate);

    const rotateValues = () => {
        setDepartfrom((prev) => arivesat);
        setArivesat((prev) => departfrom);
        setRticon((prev) => !prev)
    } 

    const handleSelect = (ranges) => {
        console.log(ranges);
        setState(ranges);
        setStartDate(ranges[0].startDate);
        setEndDate(ranges[0].endDate);
        //setShowDatePicker(false); // Close datepicker after selection
    };

    const handlecalanderSelect = (date) => {
        console.log(date); // native Date object
        setStartDate(date);
      }






    return <div className="heroSetion position-relative py-5">
            <div className="container searchWidgetSecContainer">
                {ishowHeading == 1 && <div className="hsTagline text-center mb-4">
                    <h2 className="text-black mb-1 poppins-bold">Book <span className="text-primary">Cheap Flights </span> with travelslake</h2>
                </div> }
              {ishowHeading == 1 &&    <div className="align-items-center d-flex h-auto justify-content-center mb-3 opacity-100 visible widgetTopBar">
                
                   <ul className="list-unstyled d-flex mb-0 tripType gap-2">
                        <li>
                            <input className="form-check-input" type="radio" name="select" id="roundTrip" 
                            value="roundtrip" checked={selectedOption === 'roundtrip'}
                            onChange={handleRadioChange}/>
                            <label className="form-check-label" for="roundTrip">
                                <div className="tripIco"><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M5.49793 11.2869L5 11.7932L6.49378 12.8059L7.07469 11.9198L5.49793 11.2869Z" fill="black" />
                                        <path d="M8.82031 14.4937L8.32239 15L7.32654 13.481L8.19791 12.8903L8.82031 14.4937Z" fill="black" />
                                        <path d="M9.7289 8.54413L10.7662 7.44709L5.99446 5.3374L5.28906 6.0547L9.7289 8.54413Z" fill="black" />
                                        <path d="M11.5144 10.1899L12.5933 9.13501L14.668 13.9873L13.9626 14.7046L11.5144 10.1899Z" fill="black" />
                                        <path d="M8.1935 5L7.65408 5.59071L8.06902 5.75949L8.52545 5.25316L8.1935 5Z" fill="black" />
                                        <path d="M15 11.751L14.4191 12.2995L14.2531 11.8776L14.751 11.4135L15 11.751Z" fill="black" />
                                        <path d="M9.97935 5.80176L9.39844 6.39247L9.81338 6.56125L10.2698 6.09711L9.97935 5.80176Z" fill="black" />
                                        <path d="M14.2109 9.93663L13.63 10.5273L13.464 10.1054L13.9205 9.64127L14.2109 9.93663Z" fill="black" />
                                        <path d="M11.5984 7.23645C9.57346 8.9242 7.32449 12.2434 6.45312 13.6921C7.96073 12.6513 11.366 10.1225 12.9262 8.3335C14.4863 6.54448 14.5721 5.81593 14.4199 5.67528C14.3231 5.49244 13.6232 5.5487 11.5984 7.23645Z" fill="black" />
                                        <path d="M19.9039 11.3921C19.9672 10.9371 20 10.4724 20 10C20 4.47715 15.5228 0 10 0C6.81334 0 3.97482 1.49055 2.14361 3.81248L1.05263 3.15789V6.31579L4.21053 5.05263L3.1618 4.4234C4.77982 2.44171 7.24215 1.17647 10 1.17647C14.8731 1.17647 18.8235 5.1269 18.8235 10C18.8235 10.338 18.8045 10.6715 18.7675 10.9996L18.7697 11L19.9039 11.3921Z" fill="black" />
                                        <path d="M1.53562 15.3273L9.11922 19.9617C5.92375 19.6829 3.15894 17.9011 1.53562 15.3273Z" fill="black" />
                                        <path d="M1.1476 14.6557C0.414789 13.2652 0 11.681 0 10C0 9.87938 0.0021357 9.75925 0.00637136 9.63966C0.397978 9.71248 0.807959 9.78598 1.17776 9.84744C1.1769 9.89819 1.17647 9.94904 1.17647 10C1.17647 11.1273 1.38788 12.2053 1.77322 13.1963L1.1476 14.6557Z" fill="black" />
                                        <path d="M0.0278345 9.25813C0.00987193 9.50308 0 9.75047 0 10C0 15.5228 4.47788 20 10.0007 20C13.1874 20 16.0259 18.5095 17.8571 16.1875L18.9481 16.8421V13.6842L15.7902 14.9474L16.8389 15.5766C15.2209 17.5583 12.7586 18.8235 10.0007 18.8235C5.12763 18.8235 1.17647 14.8731 1.17647 10C1.17647 9.86781 1.18011 9.73631 1.18586 9.60554L0.0278345 9.25813Z" fill="black" />
                                        <path d="M1.52849 4.68517L2.5079 5.33811C4.0659 2.8393 6.8384 1.17647 10 1.17647C14.8731 1.17647 18.8235 5.1269 18.8235 10C18.8235 10.051 18.8238 10.1018 18.823 10.1526C19.1928 10.214 19.6028 10.2875 19.9944 10.3603C19.9986 10.2407 20 10.1206 20 10C20 4.47715 15.5228 0 10 0C6.43009 0 3.29783 1.87064 1.52849 4.68517Z" fill="black" />
                                    </svg></div>
                                <span> Round Trip</span>
                            </label>
                        </li>
                        <li>
                            <input className="form-check-input" type="radio" name="select" id="oneWay" value="oneway" checked={selectedOption === 'oneway'}
                            onChange={handleRadioChange} />
                            <label className="form-check-label" for="oneWay">
                                <div className="tripIco"><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M20 10C20 15.5228 15.5228 20 10 20C4.47715 20 0 15.5228 0 10C0 9.87938 0.0021357 9.75925 0.00637136 9.63966C0.397978 9.71248 0.807959 9.78598 1.17776 9.84744C1.1769 9.89819 1.17647 9.94904 1.17647 10C1.17647 14.8731 5.1269 18.8235 10 18.8235C14.8731 18.8235 18.8235 14.8731 18.8235 10C18.8235 5.1269 14.8731 1.17647 10 1.17647C6.73341 1.17647 3.88142 2.95157 2.35601 5.58977L1.30186 5.06269C3.02181 2.03915 6.27277 0 10 0C15.5228 0 20 4.47715 20 10Z" fill="black"></path>
                                        <path d="M1.05263 3.15789L4.21053 5.05263L1.05263 6.31579V3.15789Z" fill="black"></path>
                                        <path d="M5.49793 11.2869L5 11.7932L6.49378 12.8059L7.07469 11.9198L5.49793 11.2869Z" fill="black"></path>
                                        <path d="M8.82031 14.4937L8.32239 15L7.32654 13.481L8.19791 12.8903L8.82031 14.4937Z" fill="black"></path>
                                        <path d="M9.7289 8.54413L10.7662 7.44709L5.99446 5.3374L5.28906 6.0547L9.7289 8.54413Z" fill="black"></path>
                                        <path d="M11.5144 10.1899L12.5933 9.13501L14.668 13.9873L13.9626 14.7046L11.5144 10.1899Z" fill="black"></path>
                                        <path d="M8.19347 5L7.65405 5.59071L8.06899 5.75949L8.52542 5.25316L8.19347 5Z" fill="black"></path>
                                        <path d="M15 11.751L14.4191 12.2995L14.2531 11.8776L14.751 11.4135L15 11.751Z" fill="black"></path>
                                        <path d="M9.97935 5.80176L9.39844 6.39247L9.81338 6.56125L10.2698 6.09711L9.97935 5.80176Z" fill="black"></path>
                                        <path d="M14.2109 9.93663L13.63 10.5273L13.464 10.1054L13.9205 9.64127L14.2109 9.93663Z" fill="black"></path>
                                        <path d="M11.5984 7.23645C9.57346 8.9242 7.32449 12.2434 6.45312 13.6921C7.96073 12.6513 11.366 10.1225 12.9262 8.3335C14.4863 6.54448 14.5721 5.81593 14.4199 5.67528C14.3231 5.49244 13.6232 5.5487 11.5984 7.23645Z" fill="black"></path>
                                    </svg></div>
                                <span>One-Way
                                </span>
                            </label>
                        </li>
                        {/* <li>
                            <input className="form-check-input" type="radio" name="select" id="multiCity" value="multicity" checked={selectedOption === 'multicity'}
                            onChange={handleRadioChange} />
                            <label className="form-check-label" for="multiCity">
                                <div className="tripIco"><svg width="21" height="22" viewBox="0 0 21 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M19.6609 15C22.4224 10.217 20.7836 4.10113 16.0007 1.33971C11.2178 -1.42172 5.10185 0.217035 2.34043 4.99996C0.747101 7.75969 0.618695 10.9632 1.71394 13.71L0.601562 14.3276L3.33638 15.9065L3.8214 12.5401L2.7521 13.1337C1.84492 10.7416 1.98036 7.97656 3.35928 5.5882C5.79583 1.36797 11.1922 -0.0779908 15.4124 2.35856C19.6327 4.79511 21.0786 10.1915 18.6421 14.4117C17.7552 15.9479 16.4761 17.1165 15.0044 17.864L15.3122 19.0238C17.0751 18.1834 18.6106 16.8191 19.6609 15Z" fill="black" />
                                        <path d="M8.79759 14.1645L8.80353 14.8746L10.5758 14.5344L10.3601 13.4971L8.79759 14.1645Z" fill="black" />
                                        <path d="M13.4144 14.0827L13.4204 14.7929L11.6421 14.4229L11.8406 13.3891L13.4144 14.0827Z" fill="black" />
                                        <path d="M9.84991 9.23331L9.8077 7.72407L4.94177 9.60646L4.95018 10.6125L9.84991 9.23331Z" fill="black" />
                                        <path d="M12.2762 9.13445L12.2932 7.6257L17.1913 9.58976L17.1997 10.5958L12.2762 9.13445Z" fill="black" />
                                        <path d="M6.25814 7.81292L6.29441 8.61205L6.70716 8.43798L6.67188 7.75721L6.25814 7.81292Z" fill="black" />
                                        <path d="M15.8448 7.77369L15.8218 8.57232L15.4061 8.39132L15.43 7.71105L15.8448 7.77369Z" fill="black" />
                                        <path d="M8.08786 7.11706L8.09479 7.94553L8.50754 7.77146L8.50209 7.12053L8.08786 7.11706Z" fill="black" />
                                        <path d="M14.0038 7.04868L14.0108 7.87714L13.5951 7.69615L13.5896 7.04521L14.0038 7.04868Z" fill="black" />
                                        <path d="M10.2471 6.98673C10.0087 9.61197 10.7656 13.5493 11.1738 15.1898C11.5039 13.3878 12.1236 9.1918 11.9618 6.82357C11.8 4.45534 11.3454 3.87954 11.1384 3.88767C10.9406 3.82684 10.4855 4.3615 10.2471 6.98673Z" fill="black" />
                                        <path d="M9 12.5C10.1935 12.5 11.3381 12.9741 12.182 13.818C13.0259 14.6619 13.5 15.8065 13.5 17C13.5 18.1935 13.0259 19.3381 12.182 20.182C11.3381 21.0259 10.1935 21.5 9 21.5C7.80653 21.5 6.66193 21.0259 5.81802 20.182C4.97411 19.3381 4.5 18.1935 4.5 17C4.5 15.8065 4.97411 14.6619 5.81802 13.818C6.66193 12.9741 7.80653 12.5 9 12.5ZM5.34375 17C5.34375 17.9697 5.72896 18.8997 6.41464 19.5854C7.10032 20.271 8.0303 20.6562 9 20.6562C9.9697 20.6562 10.8997 20.271 11.5854 19.5854C12.271 18.8997 12.6562 17.9697 12.6562 17C12.6562 16.0303 12.271 15.1003 11.5854 14.4146C10.8997 13.729 9.9697 13.3438 9 13.3438C8.0303 13.3438 7.10032 13.729 6.41464 14.4146C5.72896 15.1003 5.34375 16.0303 5.34375 17ZM9.28125 15.1719V16.8549L10.422 17.3116C10.5225 17.3554 10.602 17.4367 10.6437 17.5381C10.6853 17.6396 10.6858 17.7533 10.6451 17.8551C10.6044 17.9569 10.5256 18.0388 10.4254 18.0836C10.3253 18.1283 10.2117 18.1322 10.1087 18.0946L8.70244 17.5321C8.62428 17.5007 8.55729 17.4467 8.51008 17.3769C8.46287 17.3071 8.4376 17.2249 8.4375 17.1406V15.1719C8.4375 15.06 8.48195 14.9527 8.56106 14.8736C8.64018 14.7944 8.74749 14.75 8.85938 14.75C8.97126 14.75 9.07857 14.7944 9.15769 14.8736C9.2368 14.9527 9.28125 15.06 9.28125 15.1719Z" fill="black" />
                                    </svg></div>
                                <span>Multi-City
                                </span>
                            </label>
                        </li> */}
                    </ul>
                </div> }
                <div className={(searcherrclass ? 'errCls bg-white p-lg-3 p-5 rounded-pill searchWidgetSec shadow' : "bg-white p-lg-3 p-5 rounded-pill searchWidgetSec shadow")}>
                    <form className="widgetsearchForm" onSubmit={handleSubmit}>
                        <div className={(searcherrclass ? ' gx-xl-3 gx-2 row align-items-center' : "gx-xl-3 gx-2 row align-items-center")}>
                            <div className="align-items-md-center col-lg-5 d-md-flex mb-3 mb-lg-0 position-relative">
                                <div className="input-group flex-nowrap w-50 wh_input d-flex align-items-center position-relative">
                                    <img src={`${process.env.PUBLIC_URL}/assets/images/take-off.png`} alt="img" className="img-fluid" />
                                    <div className="input-field ps-2" >
                                        <input type="text" className='form-control border-0 p-0 ftextt' id="origin" placeholder="Depart From*"  value={departfrom} onChange={handleChange} autocomplete="off" />
                                        
                                       {departfrom != '' && <button type="button" class="typeahead-field-clear btn" onClick={() => ClearField(1)} onclick="ClearField(this)" ><i class="fa fa-times"></i></button> }
                                        {derror && <p style={{ fontSize:'14px',color: 'red', marginBottom: '10px',position: 'absolute',top:'32px',right:0 }}>{derror}</p>}
                                    </div>
                                    
                                    {suggestions.length > 0 && (
                                        <ul
                                           className="typeahead position-absolute"
                                        >
                                          {suggestions.map((suggestion, index) => (
                                            <li
                                              key={index}
                                              onClick={() => handleSuggestionClick(suggestion)}
                                              className=""
                                            >
                                              <a class={(suggestion.ParentId != null ? "chdcls dropdown-item" : "dropdown-item")} href="#" role="option">
                                                { suggestion.ParentId == null && <i class="fa fa-map-marker"></i> }
                                                 { suggestion.ParentId != null &&  <img src={`${process.env.PUBLIC_URL}/assets/images/take-off.png`} alt="img"  /> }
                                                {suggestion.AutoSuggest}</a>
                                            </li>
                                          ))}
                                        </ul>
                                      )}
                                    
                                </div>
                                <button type="button" className={rticon ? 'align-items-center bg-white d-flex itenerary-btn justify-content-center position-relative rounded-pill isrorateicon' : 'align-items-center bg-white d-flex itenerary-btn justify-content-center position-relative rounded-pill'} onClick={(e) => rotateValues()} ><img src={`${process.env.PUBLIC_URL}/assets/images/itesectinicon.png`} alt="icon" className="img-fluid" /></button>
                                <div className="dest_input input-group flex-nowrap ms-xl-2 ms-md-1 w-50 d-flex align-items-center">
                                    <img src={`${process.env.PUBLIC_URL}/assets/images/landing.png`} alt="img" className="img-fluid" />
                                    <div className="input-field ps-2">
                                        <input type="text" className="form-control border-0 p-0 ftextt" id="destina" placeholder="Arives At*" value={arivesat} onChange={(e) => setArivesat(e.target.value)} onChange={handledChange} autocomplete="off" />

                                        
                                    {arivesat != '' &&  <button type="button" class="typeahead-field-clear btn" onClick={() => ClearField(2)} ><i class="fa fa-times"></i></button> }
                                    {aerror && <p style={{ fontSize:'14px',color: 'red', marginBottom: '10px',position: 'absolute',top:'32px',right:0 }}>{aerror}</p>}
                                    </div>
                                    {dsuggestions.length > 0 && (
                                        <ul
                                           className="typeahead position-absolute"
                                        >
                                          {dsuggestions.map((dsuggestion, index) => (
                                            <li
                                              key={index}
                                              onClick={() => handledSuggestionClick(dsuggestion)}
                                              className=""
                                            >
                                              <a class={(dsuggestion.ParentId != null ? "chdcls dropdown-item" : "dropdown-item")} href="#" role="option">
                                                 { dsuggestion.ParentId == null && <i class="fa fa-map-marker"></i> }
                                                 { dsuggestion.ParentId != null &&  <img src={`${process.env.PUBLIC_URL}/assets/images/take-off.png`} alt="img"  /> }
                                               {dsuggestion.AutoSuggest}</a>
                                            </li>
                                          ))}
                                        </ul>
                                      )}
                                </div>
                            </div>    
                            <div className="align-items-center col-lg-3 d-flex mb-3 mb-lg-0 px-2 border-lg-left border-bottom">
                                
                                    

                                    {(isround) && (
                                        <div className="input-group ps-lg-2 d-flex align-items-center"><img src={`${process.env.PUBLIC_URL}/assets/images/calender.png`} alt="img" className="img-fluid" />
                                        <input
                type="text"
                readOnly
                value={formattedStartDate}
                onClick={() => handelShowdatepicker(!showDatePicker)}
                className="form-control border-0"
                placeholder={formattedStartDate}
            />
                                        <img src={`${process.env.PUBLIC_URL}/assets/images/calender.png`} alt="img" className="img-fluid" />
                        <input
                type="text"
                readOnly
                value={
                    formattedEndDate
                        ? `${formattedEndDate}`
                        : "Return Date*"
                }
                onClick={() => handelShowdatepicker(!showDatePicker) }
                className="form-control border-0"
                placeholder="Click to select dates"
            />

            {showDatePicker && (
                <div className="date-picker-container" style={{ margin: "20px" }}>
                       <DateRangePicker
  onChange={item => handleSelect([item.selection])}
  showSelectionPreview={true}
  moveRangeOnFirstSelection={false}
  minDate={addDays(new Date(), +1)}
 
  ranges={state}
  showPreview={false}
  staticRanges={[
    
  ]}

                        months={2}
                 
    scroll={{ enabled: false }}
  direction="horizontal"
/>;
                 </div>
            )}
                        {rderror && <p style={{ fontSize:'14px',color: 'red',position: 'absolute',top:'32px',right:0 }}>{rderror}</p>}
                                    </div>
                                    )} 

                                    {(!isround) && (
                                          <div className="input-group ps-lg-2 pe-lg-2 d-flex align-items-center"><img src={`${process.env.PUBLIC_URL}/assets/images/calender.png`} alt="img" className="img-fluid" />
                                            <input
                type="text"
                readOnly
                value={formattedStartDate}
                onClick={() => setShowCalanderPicker(!showCalanderPicker)}
                className="form-control border-0"
                placeholder={formattedStartDate}
            />
                                          {showCalanderPicker && ( <div className="date-picker-container" style={{ margin: "20px" }}><Calendar
        date={new Date()}
        onChange={handlecalanderSelect}
      /></div>

                                          )}

                                          </div>
                                    )}
                                    
                                
                            </div>
                            <div className="col-lg-3 mb-3 mb-lg-0 d-flex align-items-center border-lg-left border-bottom">
                                <div className="input-group ps-lg-2 w-100">
                                    <div className="dropdown w-100" ref={dropdownRef}>
                                        <button className="bg-transparent border-0 dropdown-toggle px-0 poppins-medium seatAvailBtn text-start w-100 d-flex align-items-center" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" onClick={handleToggle}
                aria-expanded={isOpen}><img src={`${process.env.PUBLIC_URL}/assets/images/traveller.png`} alt="img" className="img-fluid" />
                                            <p className="mb-0 w-100 ps-2">{totalPassanger}&nbsp;Traveller <span className="barlow-regular d-block fs-6"> {flightclassval} </span></p>
                                        </button>
                                        <div className={isOpen ? 'show dropdown-menu p-3 w-100' : "dropdown-menu p-3 w-100"}   aria-labelledby="dropdownMenuButton" onClick={handleInsideClick}>
                                            <div className="dropdown">
                                                <button className={isOpenchild ? 'show bg-gray btn dropdown-toggle flightClass poppins-medium text-black text-start w-100' : "bg-gray btn dropdown-toggle flightClass poppins-medium text-black text-start w-100"} type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false" onClick={handleChildToggle} aria-expanded={isOpenchild}>
                                                    {flightclassval}
                                                </button>
                                                <ul className={isOpenchild ? 'show dropdown-menu tripClass w-100 bg-gray' : "dropdown-menu tripClass w-100 bg-gray"} aria-labelledby="dropdownMenuButton" onClick={handleInsidechildClick}>
                                                    <li><button type="button" className={isOpenchild ? ' dropdown-item' : "dropdown-item"} onClick={() => setFlightclass('Economy')}>Economy <span className="selectedIcon"><img src={`${process.env.PUBLIC_URL}/assets/images/tick.svg`} alt="icon" className="img-fluid" /></span></button>
                                                    </li>
                                                    <li><button type="button" className="dropdown-item" onClick={() => setFlightclass('Business')}>Business <span className="selectedIcon"><img src={`${process.env.PUBLIC_URL}/assets/images/tick.svg`} alt="icon" className="img-fluid" /></span></button>
                                                    </li>
                                                    <li><button type="button" className="dropdown-item" onClick={() => setFlightclass('First')}>First <span className="selectedIcon"><img src={`${process.env.PUBLIC_URL}/assets/images/tick.svg`} alt="icon" className="img-fluid" /></span></button>
                                                    </li>
                                                    <li><button type="button" className="dropdown-item" onClick={() => setFlightclass('Premium Ecomomy')}>Premium Ecomomy <span className="selectedIcon"><img src={`${process.env.PUBLIC_URL}/assets/images/tick.svg`} alt="icon" className="img-fluid" /></span></button>
                                                    </li>
                                                </ul>
                                            </div>
                                            <ul className="passengerDtl list-unstyled mb-0 mt-3">
                                                <li className="d-flex py-2 px-3">
                                                    <label className="font-500 trv_drp_label">Adult</label>
                                                    <div className="flex-nowrap justify-content-end input-group ps-4">
                                                        

                                                    <span className="bg-transparent btn-right input-group-text rounded-circle" onClick={() => handelPassangerCount(0,'adult')}><svg width="10" height="10"  viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <g clipPath="url(#clip0_665_20)">
                                                                    <path d="M10 4.09091V5.90909H5.9098e-05L0 4.09091H10Z" fill="black"></path>
                                                                </g>
                                                                <defs>
                                                                    <clipPath id="clip0_665_20">
                                                                        <rect width="10" height="10" fill="white"></rect>
                                                                    </clipPath>
                                                                </defs>
                                                            </svg></span>
                                                        <input type="text" value={adultcount} readOnly="" className="bg-primary border-0 p-0 rounded-circle text-center text-white" min="0" max="10" />

                                                    <span className="bg-transparent btn-left input-group-text rounded-circle" onClick={() => handelPassangerCount(1,'adult')}><svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <g clipPath="url(#clip0_665_18)">
                                                                    <path d="M5.90909 0V4.09091H10V5.90909H5.90909V10H4.09091V5.90909H0V4.09091H4.09091V0H5.90909Z" fill="black"></path>
                                                                </g>
                                                                <defs>
                                                                    <clipPath id="clip0_665_18">
                                                                        <rect width="10" height="10" fill="white"></rect>
                                                                    </clipPath>
                                                                </defs>
                                                            </svg></span>
                                                        
                                                    </div>
                                                </li>
                                                <li className="d-flex py-2 px-3">
                                                    <label className="font-500 trv_drp_label">Child</label>
                                                    <div className="flex-nowrap input-group ps-4 justify-content-end">
                                                       <span className="bg-transparent btn-left input-group-text rounded-circle" onClick={() => handelPassangerCount(0,'child')}><svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <g clipPath="url(#clip0_665_20)">
                                                                    <path d="M10 4.09091V5.90909H5.9098e-05L0 4.09091H10Z" fill="black"></path>
                                                                </g>
                                                                <defs>
                                                                    <clipPath id="clip0_665_20">
                                                                        <rect width="10" height="10" fill="white"></rect>
                                                                    </clipPath>
                                                                </defs>
                                                            </svg></span>
                                                        <input type="text" value={childcount} readOnly="" className="bg-primary border-0 p-0 rounded-circle text-center text-white" />

                                                     <span className="bg-transparent btn-left input-group-text rounded-circle" onClick={() => handelPassangerCount(1,'child')}><svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <g clipPath="url(#clip0_665_18)">
                                                                    <path d="M5.90909 0V4.09091H10V5.90909H5.90909V10H4.09091V5.90909H0V4.09091H4.09091V0H5.90909Z" fill="black"></path>
                                                                </g>
                                                                <defs>
                                                                    <clipPath id="clip0_665_18">
                                                                        <rect width="10" height="10" fill="white"></rect>
                                                                    </clipPath>
                                                                </defs>
                                                            </svg></span>


                                                        
                                                    </div>
                                                </li>
                                                <li className="d-flex py-2 px-3">
                                                    <label className="font-500 trv_drp_label">Infant</label>
                                                    <div className="flex-nowrap input-group ps-4 justify-content-end">
                                                        <span className="bg-transparent btn-left input-group-text rounded-circle" onClick={() => handelPassangerCount(0,'infant')}><svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <g clipPath="url(#clip0_665_20)">
                                                                    <path d="M10 4.09091V5.90909H5.9098e-05L0 4.09091H10Z" fill="black"></path>
                                                                </g>
                                                                <defs>
                                                                    <clipPath id="clip0_665_20">
                                                                        <rect width="10" height="10" fill="white"></rect>
                                                                    </clipPath>
                                                                </defs>
                                                            </svg></span>
                                                        <input type="text" value={infantcount} readOnly="" className="bg-primary border-0 p-0 rounded-circle text-center text-white" />

                                                    <span className="bg-transparent btn-left input-group-text rounded-circle" onClick={() => handelPassangerCount(1,'infant')}><svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <g clipPath="url(#clip0_665_18)">
                                                                    <path d="M5.90909 0V4.09091H10V5.90909H5.90909V10H4.09091V5.90909H0V4.09091H4.09091V0H5.90909Z" fill="black"></path>
                                                                </g>
                                                                <defs>
                                                                    <clipPath id="clip0_665_18">
                                                                        <rect width="10" height="10" fill="white"></rect>
                                                                    </clipPath>
                                                                </defs>
                                                            </svg></span>


                                                        
                                                    </div>
                                                </li>
                                            </ul>
                                            <button type="button" className="btn btn-primary mt-2 text-uppercase border-0 w-100 h-100" onClick={handleToggle}>Done</button>
                                        </div> 
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-1 mb-lg-0">
                                <button ref={myInput} type="submit" className="border-0 btn btn-primary h-100 rounded-circle searchBtn text-uppercase">{ishowHeading == 1 && <img src={`${process.env.PUBLIC_URL}/assets/images/icon-park-outline_search.png`} alt="img" className="img-fluid" />}{ishowHeading == 0 && <img src={`${process.env.PUBLIC_URL}/assets/images/edit.png`} alt="img" className="img-fluid" />}</button>
                            </div>
                         </div>
                    </form>
                </div>
                <p className="mb-0 mt-2 text-black-65 text-center">Dates are for informational purpose only. Fares about to be displayed may not necessarily be for the selected dates.</p>
                <div className="secure-tag justify-content-center mt-2 d-flex"><img src={`${process.env.PUBLIC_URL}/assets/images/securetag.png`} alt="" /><span className="ps-2">Secure Payment</span></div>
            </div>
                 <SearchModal isOpen={isModalOpen} onClose={closeModal} title="My Modal Title">
                
                </SearchModal>
            </div>;
};

export default Search;
