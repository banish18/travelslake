// src/pages/Home.js
import React,{useState,useEffect,useRef} from 'react';
import { getSeatchrecords } from '../services';
import { useNavigate,useLocation } from 'react-router-dom'
import BookingBanner from './sections/BookingBanner.js';
import BookingDetails from './sections/BookingDetails.js';


const Bookingoptions = () => {
    const navigate = useNavigate();
    const { state } = useLocation();
    const [error, setError] = useState("");
    const [selectedOption, setSelectedOption] = useState('basic');

    const dealsRec = state?.dealdata;
   useEffect(() => {
        console.log('helo');
    }, []);

  
    const handleChange = (eventval) => {
        setSelectedOption(eventval);
    };

    const nextStep = () => {
        navigate('/payment-detail',{
                state: {'dealdata':dealsRec,'selectedsec':'payment'}
              });
    }
    return <React.Fragment> <BookingBanner selectedcls="options"/>
        <div class="mainContent py-5">
            <div class="container pb-5 pb-lg-0 position-relative">
                <div class="row">
                    <div class="col-lg-9 pe-lg-4">
                        <div class="mainInfoDtlSec">
                            <div class="dtlSecInner border-bottom pb-3 mb-4">
                                <div class="align-items-center d-flex justify-content-between luggageProSec">
                                    <div class="bg-white rounded">
                                        <h5 class="mb-1 poppins-semibold">Lost Baggage Protection</h5>
                                        <p class="fs-6 mb-0 poppins-regular text-black-65">Get compensated in case your baggage is delayed or lost, at just $1000/traveler</p>
                                    </div>
                                    <div class="bg-light-orange p-2 rounded text-center travelProPrice">
                                        <h4 class="mb-0 poppins-semibold">$5.00</h4>
                                        <p class="mb-0">Per Traveler</p>
                                    </div>
                                </div>
                                <div class="mt-4 protetFeatureSec">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="align-items-center d-flex protetFeatureBox">
                                                <div class="align-items-center d-flex justify-content-center pfbIco">
                                                    <img src={`${process.env.PUBLIC_URL}/assets/images/image173.png`} alt="img" class="img-fluid" />
                                                </div>
                                                <div class="pfbText">
                                                    <h6 class="mb-0 poppins-bold text-start">Live Tracking</h6>
                                                    <p class="mb-0 text-start">Real time update on Email &amp; SMS about baggage status</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="align-items-center d-flex protetFeatureBox">
                                                <div class="align-items-center d-flex justify-content-center pfbIco">
                                                    <img src={`${process.env.PUBLIC_URL}/assets/images/image174.png`} alt="img" class="img-fluid" />
                                                </div>
                                                <div class="pfbText">
                                                    <h6 class="mb-0 poppins-bold text-start">No Proof Required</h6>
                                                    <p class="mb-0 text-start">No need to provide the details of the bag content</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="align-items-center d-flex protetFeatureBox">
                                                <div class="align-items-center d-flex justify-content-center pfbIco">
                                                    <img src={`${process.env.PUBLIC_URL}/assets/images/image175(1).png`} alt="img" class="img-fluid" />
                                                </div>
                                                <div class="pfbText">
                                                    <h6 class="mb-0 poppins-bold text-start">Guaranteed Payment</h6>
                                                    <p class="mb-0 text-start">Collect $1000 for every bag that doesn't arrive in 96hrs</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="align-items-center blueBadges d-flex justify-content-between my-4 py-3">
                                    <div class="align-items-center bbwrapper d-flex me-md-3">
                                        <div class="bbIco">
                                            <img src={`${process.env.PUBLIC_URL}/assets/images/brb-logo.png`} alt="img" class="img-fluid" />
                                        </div>
                                        <p class="mb-0 ps-3 text-start">I agree to purchase the Delayed and Lost Baggage Protection service powered by Blue Ribbon Bags, LLC and also to all <a href="#">T&amp;Cs</a> of the service agreement.</p>
                                    </div>
                                    <a href="#" class="addToTrip btn btn-primary fs-6 rounded-pill">Add To Trip</a>
                                </div>
                                <div class="disclaimer">
                                    <p><span class="text-orange poppins-bold">Disclaimer:</span> "Terms & conditions of Blue Ribbon Bags baggage tracking services are set out at: Service Agreement (<a href="#" class="text-orange">blueribbonbags.com</a>). Superfares is not endorsing or making any representation in relation to such services."</p>
                                </div>
                            </div>
                            <div class="dtlSecInner pb-3 mb-4">
                                <h5 class="mb-1 poppins-semibold">Lost Baggage Protection</h5>
                                <p class="fs-6 mb-0 poppins-regular text-black-65">Get compensated in case your baggage is delayed or lost, at just $1000/traveler</p>
                                <div class="mt-4">
                                    <div class="row g-lg-5">
                                        <div class="col-md-4">
                                            <div onClick={() => handleChange('basic')} class={(selectedOption == 'basic' ? "card position-relative rounded-4 shadow text-center basicPack h-100 travelPackageSec active" : "card position-relative rounded-4 shadow text-center basicPack h-100 ")}>
                                                <div class="bg-transparent card-header d-flex justify-content-between mt-4 p-0">
                                                    <h5 class="mb-0 trPackTitle">Basic</h5>
                                                    <h3 class="mb-0 me-2">$0<span>/Per</span></h3>
                                                </div>
                                                <div class={(selectedOption == 'basic' ? "card-body trPack travelPackageSec" : "card-body trPack")}>
                                                    <h6 class="card-title mb-2 text-start">Includes:</h6>
                                                    <ul class="list-unstyled text-start">
                                                        <li class="align-items-center d-flex mb-3"><i class="la-check las"></i><span>Basic Customer Support</span></li>
                                                        <li class="align-items-center d-flex mb-3"><i class="la-check las"></i><span>Basic Cancelation Help</span></li>
                                                        <li class="align-items-center d-flex mb-3"><i class="la-check las"></i><span>Basic Rescheduling Help</span></li>
                                                    </ul>
                                                    <a href="#" class="btn d-block fs-6 p-0 text-blue text-decoration-underline text-start">View More Details</a>
                                                </div>
                                                <div class="bg-transparent card-footer p-0 selectedBtn text-muted">
                                                    <a  class="btn btn-primary bg-white shadow text-black fs-6 px-4 rounded-pill">Selected</a>
                                                </div>
                                            </div>
                                        </div>
                                                                                <div class="col-md-4">
                                            <div onClick={() => handleChange('standard')} class={(selectedOption == 'standard' ? "card position-relative rounded-4 shadow text-center basicPack h-100 travelPackageSec active" : "card position-relative rounded-4 shadow text-center basicPack h-100 ")}>
                                                <div class="bg-transparent card-header d-flex justify-content-between mt-4 p-0">
                                                    <h5 class="mb-0 trPackTitle">Standard</h5>
                                                    <h3 class="mb-0 me-2">$0<span>/Per</span></h3>
                                                </div>
                                                <div class={(selectedOption == 'standard' ? "card-body trPack travelPackageSec" : "card-body trPack")}>
                                                    <h6 class="card-title mb-2 text-start">Includes:</h6>
                                                    <ul class="list-unstyled text-start">
                                                        <li class="align-items-center d-flex mb-3"><i class="la-check las"></i><span>Dedicated 24*7 Customer Support</span></li>
                                                        <li class="align-items-center d-flex mb-3"><i class="la-check las"></i><span>Prioritized Custmer Service Response</span></li>
                                                        <li class="align-items-center d-flex mb-3"><i class="la-check las"></i><span>Exclusive Promo Codes for Discounts</span></li>
                                                        <li class="align-items-center d-flex mb-3"><i class="la-check las"></i><span>Free  Cancelation within 24 Hours of Booking</span></li>
                                                        <li class="align-items-center d-flex mb-3"><i class="la-check las"></i><span>Basic Rescheduling Help</span></li>
                                                    </ul>
                                                    <a href="#" class="btn d-block fs-6 p-0 text-blue text-decoration-underline text-start">View More Details</a>
                                                </div>
                                                <div class="bg-transparent card-footer p-0 selectedBtn text-muted">
                                                    <a class="btn btn-primary bg-white shadow text-black fs-6 px-4 rounded-pill">Selected</a>
                                                </div>
                                            </div>
                                        </div>
                                            <div class="col-md-4">
                                            <div onClick={() => handleChange('premium')} class={(selectedOption == 'premium' ? "card position-relative rounded-4 shadow text-center basicPack h-100 travelPackageSec active" : "card position-relative rounded-4 shadow text-center basicPack h-100 ")}>
                                                <div class="bg-transparent card-header d-flex justify-content-between mt-4 p-0">
                                                    <h5 class="mb-0 trPackTitle">Premium</h5>
                                                    <h3 class="mb-0 me-2">$0<span>/Per</span></h3>
                                                </div>
                                                <div  class={(selectedOption == 'premium' ? "card-body trPack travelPackageSec" : "card-body trPack")}>
                                                    <h6 class="card-title mb-2 text-start">Includes:</h6>
                                                    <ul class="list-unstyled text-start">
                                                        <li class="align-items-center d-flex mb-3"><i class="la-check las"></i><span>Basic Customer Support</span></li>
                                                        <li class="align-items-center d-flex mb-3"><i class="la-check las"></i><span>Basic Cancelation Help</span></li>
                                                        <li class="align-items-center d-flex mb-3"><i class="la-check las"></i><span>Basic Rescheduling Help</span></li>
                                                         <li class="align-items-center d-flex mb-3"><i class="la-check las"></i><span>Exclusive Promo Codes for Discounts</span></li>
                                                    </ul>
                                                    <a href="#" class="btn d-block fs-6 p-0 text-blue text-decoration-underline text-start">View More Details</a>
                                                </div>
                                                <div class="bg-transparent card-footer p-0 selectedBtn text-muted">
                                                    <a onClick={() => handleChange('premium')}  class="btn btn-primary bg-white shadow text-black fs-6 px-4 rounded-pill">Selected</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="contBtnSec nextBtn nextBtnFF text-end mt-4">
                                <a class="border-0 btn btn-primary nextBtnLink pe-2 ps-3 rounded-pill text-white" onClick={() => nextStep()} role="button">Next<i class="la-angle-right las ms-2 p-1 rounded-circle"></i></a>
                            </div>
                        </div>
                    </div>
                    <BookingDetails />
                </div>
            </div>
        </div></React.Fragment>;
};

export default Bookingoptions;
