// src/pages/About.js
import React from 'react';

const About = () => {
    return <div className="heroSetion position-relative py-5">
            <div className="container searchWidgetSecContainer">
               <h2 className="text-center">Coming Soon........</h2>
        </div></div>;
};

export default About;
