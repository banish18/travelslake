// src/pages/Home.js
import {React,useState,useEffect} from 'react';
import Search from './Search.js';
import Mediator from './sections/Mediator.js';
import Filters from './sections/Filters.js';
import FlightDetails from './sections/FlightDetails.js';
import ExpireModal from './modals/ExpireModal.js';
import { useLocation,useNavigate } from 'react-router-dom'
import PriceAlertModal from './modals/PriceAlertModal.js'
import { getFlightRecords,formatFlightTime,formatFlightDate } from '../services';

const currSign = process.env.REACT_APP_Currsign;

const FlightRecords = () => {
    const ITEMS_PER_LOAD = 5; // Number of items to load at a time
    const [timeLeft, setTimeLeft] = useState(15 * 60); // 15 minutes in seconds
    const { state,search } = useLocation();
    const navigate = useNavigate();
    const [isLoading, setIsLoading] = useState(true);
    const [alertvalue, setAlertvalue] = useState(true);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [flightRec, setFlightRec] = useState([]);
    const [searchdata, setSearchdata] = useState([]);
    const [isexpModalOpen, setIsexpModalOpen] = useState(false);
    const [launchSearch, setLaunchSearch] = useState(false);
    const dealsRec = state?.dealdata;
     // State for displayed items
    
    const [visibleCount, setVisibleCount] = useState(ITEMS_PER_LOAD);


    useEffect(() => {
         getFlights();
         const timer = setInterval(() => {
              setTimeLeft((prevTime) => {
                if (prevTime <= 1) {
                  clearInterval(timer);
                  onTimerEnd(); // Execute the function when the timer ends
                  return 0;
                }
                return prevTime - 1;
              });
            }, 1000);

            // Cleanup interval on component unmount
            return () => clearInterval(timer);
    }, []);


    const onTimerEnd = () => {
        setIsexpModalOpen(true)
      };


    const [displayedItems, setDisplayedItems] = useState(
        flightRec.slice(0, ITEMS_PER_LOAD)
      );
    const handleLoadMore = () => {
        const newCount = visibleCount + ITEMS_PER_LOAD;
        setDisplayedItems(flightRec.slice(0, newCount));
        setVisibleCount(newCount);
    };

    const getFlights = async () => {
        const query = new URLSearchParams(search);
       await getFlightRecords(query.get('sid')).then(res => {
            console.log(res)
            if(res.data.IsSuccess && res.data.Model.IsExpired == false){
               setIsLoading(false)
               setSearchdata(res.data.Model.SearchRequest);
               const frecords = res.data.Model.ListOfContracts;
               setFlightRec(res.data.Model.ListOfContracts);
               setDisplayedItems(frecords.slice(0, ITEMS_PER_LOAD));
              // setTimeLeft(frecords?.ExpireTime);
              // console.log(res.data.Model.SearchRequest);
            }else{
                setIsLoading(false);
                setSearchdata(res.data.Model.SearchRequest);
                setIsexpModalOpen(true)
            }
        }).catch(err => {
            setIsLoading(false)
        console.error("Error fetching data:", err);
        });
    }

    const getAfterdec = (n) => {
        console.log();
         const nn = Math.abs(n); // Change to positive
         const fd = nn - Math.floor(n);
         const finalval = fd.toFixed(2).split('.')
         return '.'+finalval[1];
    }

    const closeexpModal = () => {
        setIsexpModalOpen(false)
    }


    const nextStep = (suggestion) => {
        console.log(suggestion);
        navigate('/contact-info',{
                state: {'dealdata':suggestion,'searchdata':searchdata,'selectedsec':'contact'}
              });
    }

     const closeModal = () => {
        setIsModalOpen(false)
    }

    const showAlert = () => {
        setAlertvalue(!alertvalue);
        if(alertvalue){
            setIsModalOpen(true)
        }
    }

   

    const launchSearchExc = () => {
        
        setLaunchSearch(true);
    }

    return <div className="home">
            {isLoading && <Mediator />}
           {!isLoading && <div><Search ishowHeading={0} preData={searchdata} launchSearch={launchSearch} /> <div className="mainContent py-5">
            <div className="container">
                <div className="row">
                    <Filters />
                    <div className="col-lg-9 ps-lg-4">
                        {/*<div className="justify-content-md-between mb-3 sortListingSec">
                            <div className="align-items-center row sortingBtn">
                                <div className="col-lg-3 col-md-6">
                                    <div className="active align-items-center bg-gray d-flex justify-content-between px-2 py-2 rounded sortBox">
                                        <p className="fs-6 mb-0 sortTxt text-black-65 text-uppercase">Nonstop First</p>
                                        <h5 className="mb-0 poppins-semibold">$1,035</h5>
                                    </div>
                                </div>
                                <div className="col-lg-3 col-md-6">
                                    <div className="align-items-center bg-gray d-flex justify-content-between px-2 py-2 rounded sortBox">
                                        <p className="fs-6 mb-0 sortTxt text-black-65 text-uppercase">Lowest Price</p>
                                        <h5 className="mb-0 poppins-semibold">$1,035</h5>
                                    </div>
                                </div>
                                <div className="col-lg-3 col-md-6">
                                    <div className="align-items-center bg-gray d-flex justify-content-between px-2 py-2 rounded sortBox">
                                        <p className="fs-6 mb-0 sortTxt text-black-65 text-uppercase">Shortest Duration</p>
                                        <h5 className="mb-0 poppins-semibold">$1,035</h5>
                                    </div>
                                </div>
                                <div className="col-lg-3 col-md-6">
                                    <div className="align-items-center bg-gray d-flex form-check form-switch justify-content-between px-2 py-2 recomendedBtn rounded">
                                        <label className="form-check-label fs-6 pe-3 poppins-semibold text-blue" for="flexSwitchCheckDefault">Create Price Alert</label>
                                        <input className="border-0 form-check-input" type="checkbox" id="flexSwitchCheckDefault" value="{(alertvalue ? 'on' : 'off')}" onChange={showAlert} />
                                    </div>
                                </div>
                            </div>
                        </div> */}
                        {!isLoading && displayedItems?.length > 0 && 
                        <div className="fligtListingSec pb-4">
                            
                                {displayedItems?.map((suggestion, index) => ( <div className="bg-white border flightListContainer mb-3 shadow-none">
                                <div className="flcBox px-1">
                                    <div className="align-items-lg-center d-lg-flex justify-content-lg-between p-1 row position-relative">
                                        <div className="col-md-7 col-lg-8 departSec flightDealsDtlWrapper">
                                             
                                               {suggestion?.Outbound?.ListOfFlights?.map((innerflights, index) => ( <div className={index > 0 ? "d-flex flsLftDtl justify-content-between p-2 border-top" : "d-flex flsLftDtl justify-content-between p-2"}>
                                                <div className="airCompany align-items-center d-flex pe-3">
                                                    <img src={`${process.env.PUBLIC_URL}/assets/images/air01.png`} alt="air" className="rounded-pill" width="32" height="32" />
                                                    <p className="airlineName ps-2 text-start mb-0 poppins-semibold">
                                                            {innerflights?.AirlineName}<br />
                                                            <span className="text-black-50 poppins-regular fs-6">{innerflights?.AirlineCode}</span></p>
                                                   
                                                </div>
                                                <div className="align-items-center border-left d-flex routeDtlSec">
                                                    <div className="pe-3 routeOrigin text-end">
                                                        <h5 className="mb-0 timeLoc poppins-semibold">
                                                            {formatFlightTime(innerflights?.DepartureTime,2)}
                                                            <span className="routeloc d-block fs-6 text-black-65">
                                                                {innerflights?.OriginCityName}
                                                            </span>
                                                        </h5>
                                                    </div>
                                                    <div className="routPath w-50">
                                                        <span className="text-black-65">{formatFlightTime(suggestion?.Outbound?.TripDuration,1)}</span>
                                                        <div className="routPathLine position-relative">
                                                        </div>
                                                        <span className=" pt-1 text-black-65">Nonstop </span>
                                                    </div>
                                                   <div className="ps-3 routeDest">

                                                        {suggestion?.Outbound?.ListOfFlights.length == 1 && <h5 className="timeLoc ps-3 mb-0 poppins-semibold">
                                                            {formatFlightTime(suggestion?.Outbound?.ListOfFlights[0].ArrivalTime,2)}
                                                            <span className="routeloc d-block fs-6 text-black-65">
                                                                {innerflights?.DestinationCityName}
                                                            </span>
                                                        </h5> }
                                                        {suggestion?.Outbound?.ListOfFlights.length > 1 && <h5 className="mb-0 ps-3 timeLoc poppins-semibold">
                                                            {formatFlightTime(suggestion?.Outbound?.ListOfFlights[1].ArrivalTime,2)}
                                                            <span className="routeloc d-block fs-6 text-black-65">
                                                                {innerflights?.DestinationCityName}
                                                            </span>
                                                        </h5> }
                                                         
                                                    </div> 
                                                </div>
                                            </div> ))}  

                                        </div>
                                        <div className="col-md-5 col-lg-4 d-flex  justify-content-between align-items-center">
                                            <div className="align-items-center d-flex flsPriceBtn flex-row">
                                                <h5 className="mb-0 pe-3 poppins-semibold ps-4 text-center text-orange">{currSign}${Math.floor(suggestion?.TotalFare)}<sup>{getAfterdec(suggestion?.TotalFare)}</sup>
                                                    {/* <span className="d-block extraDis fs-6 text-blue">Extra 10% Off</span> */ }
                                                <br />
                                                <a type="button" className="flight_details_btn mt-1" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight">Flight Details <i className="fa fa-chevron-down ms-1"></i>
                                                       
                                                        </a>
                                                </h5>
                                                
                                            </div>
                                            <div className="hurryBtn text-end">
                                                <button type="button" className="btn btn-outline-primary flsBookingBtn poppins-regular px-3 py-2 rounded-pill" onClick={() => nextStep(suggestion)}>Book Now <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M9 9L5.5 13L7.5 14.5L12 9L7.5 3.49999L5.5 4.99999L9 9Z" fill="#FF6433"></path>
                                                    </svg></button>
                                                <FlightDetails suggestion={suggestion} searchdata={searchdata}/>
                                            </div>
                                        </div>
                                        {suggestion?.AvailableSeats <= 5 && <span className="seatleftOnly">Only {suggestion?.AvailableSeats} seats left</span>  }
                                    </div>
                                </div>
                            </div>  ))}
                            {visibleCount < flightRec.length && (<div className="loadMoreSec text-center mt-4">
                                <a onClick={handleLoadMore} className="bg-gray btn btn-secondary px-4 rounded-pill text-black" role="button">Load More Flights</a>
                            </div>)}

                        </div> } 

                    </div>
                </div>
            </div>
        </div><PriceAlertModal isOpen={isModalOpen} onClose={closeModal} title="My Modal Title">
                
                </PriceAlertModal>
                <ExpireModal isOpen={isexpModalOpen} onClose={closeexpModal} launchSearch={launchSearchExc} title="My Modal Title">
                
                </ExpireModal>
                </div>

                } 
            </div>;
};

export default FlightRecords;
