// src/pages/Home.js
import React,{useState,useEffect,useRef} from 'react';
import { getSeatchrecords } from '../services';
import { getAllcountries } from '../countries';
import { useNavigate,useLocation } from 'react-router-dom'
import BookingBanner from './sections/BookingBanner.js';
import BookingDetails from './sections/BookingDetails.js';
import 'react-phone-number-input/style.css'
import PhoneInput, {
    formatPhoneNumber,
    formatPhoneNumberIntl,
    isPossiblePhoneNumber,
    isValidPhoneNumber
} from 'react-phone-number-input'
import { Calendar  } from 'react-date-range';

const Contactinfo = () => {
    const navigate = useNavigate();
    const { state } = useLocation();
    const [error, setError] = useState("");
    const [selectedOption, setSelectedOption] = useState('Mr');
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');
    const [perror, setPerror] = useState('');
    const [eerror, setEerror] = useState('');
    const [gerror, setGerror] = useState('');
    const [ferror, setFerror] = useState('');
    const [merror, setMerror] = useState('');
    const [lerror, setLerror] = useState('');
    const [derror, setDerror] = useState('');
    const [countries, SetCountries] = useState(getAllcountries());
    const [countrycode, setCountrycode] = useState('+1');
    const [isChecked, setIsChecked] = useState(false);
    const [submitted, setSubmitted] = useState(false);
    const [flightRec, setFlightRec] = useState([]);
    const [searchdata, setSearchdata] = useState(false);
    const [adultformData, setAdultFormData] = useState([{ gender:'Mr',fname: "",mname: "",lname: "", dob: "" }  ]);
    const [childformData, setChildFormData] = useState([{ cgender:'Mr',cfname: "",cmname: "",clname: "", cdob: "" }  ]);
    const [infantformData, setInfantFormData] = useState([{ igender:'Mr',ifname: "",imname: "",ilname: "", idob: "" }  ]);
    const [errors, setErrors] = useState([]);
    const [cerrors, setCerrors] = useState([]);
    const [ierrors, setIerrors] = useState([]);
    useEffect(() => {
      
        const dealsRec = state?.searchdata;


        
        setFlightRec(state?.dealdata);
        setSearchdata(state?.searchdata);
        setAdultFormData([]);
        setChildFormData([]);
        setInfantFormData([]);
        const adultCount = dealsRec?.AdultCount;
        if(adultCount != undefined && adultCount != 0){
            for (var i = 0; i < adultCount; i++) {
                 setAdultFormData((oldValue) => [...oldValue, { gender:'Mr',fname: "",mname: "",lname: "", dob: "" }]);
            }
        }else{
            setAdultFormData([]);
        }

        const childCount = dealsRec?.ChildCount;
        if(childCount != undefined && childCount != 0){
            for (var i = 0; i < childCount; i++) {
                 setChildFormData((oldValue) => [...oldValue, { cgender:'Mr',cfname: "",cmname: "",clname: "", cdob: "" }]);
            }
        }else{
            setChildFormData([]);
        }

         const infantcount = dealsRec?.InfantCount;
        if(infantcount != 0){
            for (var i = 0; i < infantcount; i++) {
                 setInfantFormData((oldValue) => [...oldValue, { igender:'Mr',ifname: "",imname: "",ilname: "", idob: "" }]);
            }
        }else{
             setInfantFormData([]);
        }
    },[])

 
    const validateEmail = (email) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    };

    // Handle input change
    const handleInputChange = (index, field, value,isfor) => {
        if(isfor == 1){
            console.log(index+' - '+field+' - '+value);
             const updatedFormData = [...adultformData];
            updatedFormData[index][field] = value;
            setAdultFormData(updatedFormData);
        }else if(isfor == 2){
            const updatedFormData = [...childformData];
            updatedFormData[index][field] = value;
            setChildFormData(updatedFormData);
        }else{
            const updatedFormData = [...infantformData];
            updatedFormData[index][field] = value;
            setInfantFormData(updatedFormData);
        }
       
      };

     const validateFields = () => {
            const newErrors = adultformData.map((field) => {
          let error = {};
          if (!field.fname) error.fname = "First name is required.";
          if (!field.mname) error.mname = "Middel name is required.";
          if (!field.lname) error.lname = "Last name is required.";
          if (!field.dob) error.dob = "DOB is required.";
         
          return error;
        });
        setErrors(newErrors);
        return newErrors.every((error) => Object.keys(error).length === 0);
     }
     const validatecFields = () => {
       
           const cnewErrors = childformData.map((field) => {
          let error = {};
         
          if (!field.cfname) error.cfname = "First name is required.";
          if (!field.cmname) error.cmname = "Middel name is required.";
          if (!field.clname) error.clname = "Last name is required.";
          if (!field.cdob) error.cdob = "DOB is required.";
          
          
          // else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(field.email))
          //   error.email = "Invalid email format.";
          return error;
        });
           console.log(cnewErrors);
         setCerrors(cnewErrors);
        return cnewErrors.every((error) => Object.keys(error).length === 0);

     }

     const validateiFields = () => {
           const  inewErrors = infantformData.map((field) => {
          let error = {};
         
          if (!field.ifname) error.ifname = "First name is required.";
          if (!field.imname) error.imname = "Middel name is required.";
          if (!field.ilname) error.ilname = "Last name is required.";
          if (!field.idob) error.idob = "DOB is required.";
          
          
          // else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(field.email))
          //   error.email = "Invalid email format.";
          return error;
        });
        setIerrors(inewErrors);
        return inewErrors.every((error) => Object.keys(error).length === 0);

     }



  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
     setEerror('');
      setPerror('');
            setEerror('');
    if ('' == phone) {
        
        setPerror('Please enter a valid phone number');
        setSubmitted(false);
    } 
    if (!validateEmail(email)) {
             
            setEerror('Please enter a valid email address');
            setSubmitted(false);
        }
    
    if (validateFields() && validatecFields() && validateiFields()) {
       
            
            setSubmitted(true);
            navigate('/booking-options',{
                state: {'dealdata':flightRec,'selectedsec':'options'}
              });
    

      
    }
       

  };



    // const handleSubmit = (e) => {
    //     e.preventDefault();
    //     console.log(phone);
    //     if ('' == phone) {
    //         setPerror('Please enter a valid phone number');
    //         setSubmitted(false);
    //     } 
    //     else if (!validateEmail(email)) {
    //          setPerror('');
    //         setEerror('Please enter a valid email address');
    //         setSubmitted(false);
    //     }else {
    //         setPerror('');
    //         setEerror('');
            
    //         setSubmitted(true);
    //         navigate('/booking-options',{
    //             state: {'dealdata':dealsRec}
    //           });
    //     }
        


    // };

   
  
    const handleRadioChange = (event) => {
        setSelectedOption(event.target.value);
    };


    return <React.Fragment>
        <BookingBanner selectedcls="contact"/>
        <div class="mainContent py-5">
            <div class="container pb-5 pb-lg-0 position-relative">
                <div class="row">
                    <div class="col-lg-9 pe-lg-4">
                        <div class="mainInfoDtlSec">
                        <form  onSubmit={handleSubmit} >
                            <div class="bg-white border-bottom contactInfoSec pb-4 rounded">
                                <h5 class="mb-1 poppins-semibold">Contact Information {adultformData.length}</h5>
                                <p class="text-black-65 fs-6 poppins-regular">Your ticket and flight info will be sent here</p>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class={perror ? "erricls input-group mb-3 phnInput bg-gray" : "input-group mb-3 phnInput bg-gray"}>
                                            
                                           {/*  <ul class="dropdown-menu" style={{height:'400px',overflowY:'scroll'}}>
                                           { countries.map((field, index) => (
                                                <li onClick={() => setCountrycode(field.dial_code)}><a class="dropdown-item px-1" ><i className="fa fa-us" /> {field.dial_code}</a></li>
                                            ))}
                                            </ul> */}
                                            

      <PhoneInput
  placeholder="Enter phone number"
  value={phone}
  defaultCountry="US"
  onChange={setPhone}
  error={phone ? (isValidPhoneNumber(phone) ? undefined : 'Invalid phone number') : 'Phone number required'}/>



                                            
                                            
                                        </div>
                                        {perror && <p style={{ color: 'red', marginTop: '-16px' }}>{perror}</p>}
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <input type="text" class={eerror ? "erricls form-control bg-gray" : "form-control bg-gray"}  id="email" placeholder="Enter email" value={email} autocomplete="new-off" onChange={(e) => setEmail(e.target.value)} />
                                             {eerror && <p style={{ color: 'red', marginBottom: '10px' }}>{eerror}</p>}
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check ps-0 d-flex align-items-center">
                                            <input class="form-check-input mt-0" type="checkbox" value="" id="flexCheckDefault" />
                                            <label class="form-check-label text-black-65 fs-6" for="flexCheckDefault">
                                                Update me on order status, news and exclusive offers via sms, rcs, whatsapp and email
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="travelerInfoSec rounded bg-white pt-4 mb-4">
                                <h5 class="mb-1 poppins-semibold">Traveler Information</h5>
                                <p class="text-black-65 fs-6 poppins-regular"><span class="text-orange poppins-regular">Important!</span> All names and dates of birth must match each traveler's passport or government issued photo ID.</p>
                                
                                {adultformData.map((field, index) => (
                                   <div> 
                                <div class="travelerBox">
                                    <h6 class="text-start poppins-bold mb-2">{index+1}. Adult (18+ Years)</h6> 
                                
                                <div class="row mt-4 mb-2">
                                    <div class="form-check col ps-2">
                                        <input class="form-check-input mt-0" type="radio" name={`adult-${index}`}  id="flexRadioDefault1" checked={field.gender == 'Mr' }
                             value="Mr" onChange={(e) => handleInputChange(index, "gender", e.target.value,1)}/>
                                        <label class="form-check-label poppins-regular" for="flexRadioDefault1">
                                            Mr.
                                        </label>
                                    </div>
                                    <div class="form-check col">
                                        <input class="form-check-input" type="radio" name={`adult-${index}`}  id="flexRadioDefault1" checked={field.gender == 'Mrs'}
                            value="Mrs" onChange={(e) => handleInputChange(index, "gender", e.target.value,1)}/>
                                        <label class="form-check-label poppins-regular" for="flexRadioDefault1">
                                            Mrs.
                                        </label>
                                    </div>
                                    <div class="form-check col">
                                        <input class="form-check-input" type="radio" name={`adult-${index}`}  id="flexRadioDefault1" checked={field.gender == 'Ms'}
                           value="Ms" onChange={(e) => handleInputChange(index, "gender", e.target.value,1)}/>
                                        <label class="form-check-label poppins-regular" for="flexRadioDefault1">
                                            Ms.
                                        </label>
                                    </div>
                                </div>
                                </div>
                                    <div key={index} class="row">
                                        <div class="col-sm-6 col-lg-3">
                                            <div class="mb-3">
                                                <label for="fname" class="form-label poppins-medium fs-6 mb-1">First Name<span class="text-red">*</span></label>
                                              <input type="text" class={errors[index]?.fname ? "erricls form-control bg-gray" : "form-control bg-gray"} id="mname" placeholder="Enter middle Name" autoComplete="new-password" value={field.fname} onChange={(e) => handleInputChange(index, "fname", e.target.value,1)}/>
                                                {errors[index]?.fname && <span style={{ color: 'red', marginBottom: '10px' }}>{errors[index].fname}</span>}
                                            </div>
                                        </div>
                                        <div class="col-sm-6 col-lg-3">
                                            <div class="mb-3">
                                                <label for="mname" class="form-label poppins-medium fs-6 mb-1">Middle Name<span class="text-red">*</span></label>
                                                <input type="text" class={errors[index]?.mname ? "erricls form-control bg-gray" : "form-control bg-gray"} id="mname" placeholder="Enter middle Name" autoComplete="new-password" value={field.mname} onChange={(e) => handleInputChange(index, "mname", e.target.value,1)}/>
                                                {errors[index]?.mname && <span style={{ color: 'red', marginBottom: '10px' }}>{errors[index].mname}</span>}
                                            </div>
                                        </div>
                                        <div class="col-sm-6 col-lg-3">
                                            <div class="mb-3">
                                                <label for="lname" class="form-label poppins-medium fs-6 mb-1">Last Name<span class="text-red">*</span></label>
                                                <input type="text" class={errors[index]?.lname ? "erricls form-control bg-gray" : "form-control bg-gray"} id="lname" placeholder="Enter last Name" autoComplete="new-password" value={field.lname} onChange={(e) => handleInputChange(index, "lname", e.target.value,1)}/>
                                                {errors[index]?.lname && <span style={{ color: 'red', marginBottom: '10px' }}>{errors[index].lname}</span>}
                                            </div>
                                        </div>
                                        <div class="col-sm-6 col-lg-3">
                                            <div class="mb-3">
                                                <label for="calender" class="form-label poppins-medium fs-6 mb-1">Date of Birth</label>
                                                <input type="date" class={errors[index]?.dob ? "erricls form-control bg-gray" : "form-control bg-gray"} id="date" placeholder="20-12-1996" autoComplete="new-password" value={field.dob} onChange={(e) => handleInputChange(index, "dob", e.target.value,1)}/>
                                                {errors[index]?.dob && <span style={{ color: 'red', marginBottom: '10px' }}>{errors[index].dob}</span>}
                                            </div>
                                        </div>
                                    </div></div>
                                    ))}

                                    {childformData.map((field, index) => (
                                   <div> 
                                <div class="travelerBox">
                                    <h6 class="text-start poppins-bold mb-2">{index+1}. Child</h6> 
                                
                                <div class="row mt-4 mb-2">
                                    <div class="form-check col ps-2">
                                        <input class="form-check-input mt-0" type="radio" name={`child-${index}`} id="flexRadioDefault1" checked={field.cgender == 'Mr' }
                             value="Mr" onChange={(e) => handleInputChange(index, "cgender", e.target.value,2)}/>
                                        <label class="form-check-label poppins-regular" for="flexRadioDefault1">
                                            Mr.
                                        </label>
                                    </div>
                                    <div class="form-check col">
                                        <input class="form-check-input" type="radio" name={`child-${index}`} id="flexRadioDefault1" checked={field.cgender == 'Mrs'}
                            value="Mrs" onChange={(e) => handleInputChange(index, "cgender", e.target.value,2)}/>
                                        <label class="form-check-label poppins-regular" for="flexRadioDefault1">
                                            Mrs.
                                        </label>
                                    </div>
                                    <div class="form-check col">
                                        <input class="form-check-input" type="radio" name={`child-${index}`} id="flexRadioDefault1" checked={field.cgender == 'Ms'}
                           value="Ms" onChange={(e) => handleInputChange(index, "cgender", e.target.value,2)}/>
                                        <label class="form-check-label poppins-regular" for="flexRadioDefault1">
                                            Ms.
                                        </label>
                                    </div>
                                </div>
                                </div>
                                    <div key={index} class="row">
                                        <div class="col-sm-6 col-lg-3">
                                            <div class="mb-3">
                                                <label for="fname" class="form-label poppins-medium fs-6 mb-1">First Name<span class="text-red">*</span></label>
                                                <input type="text" class={cerrors[index]?.cfname ? "erricls form-control bg-gray" : "form-control bg-gray"} id="fname" placeholder="Enter First Name" autoComplete="new-password" value={field.cfname}  onChange={(e) => handleInputChange(index, "cfname", e.target.value,2)}/>
                                                {cerrors[index]?.cfname && <span style={{ color: 'red', marginBottom: '10px' }}>{cerrors[index].cfname}</span>}
                                            </div>
                                        </div>
                                        <div class="col-sm-6 col-lg-3">
                                            <div class="mb-3">
                                                <label for="mname" class="form-label poppins-medium fs-6 mb-1">Middle Name<span class="text-red">*</span></label>
                                                <input type="text" class={cerrors[index]?.cmname ? "erricls form-control bg-gray" : "form-control bg-gray"} id="mname" placeholder="Enter middle Name" autoComplete="new-password" value={field.cmname} onChange={(e) => handleInputChange(index, "cmname", e.target.value,2)}/>
                                                {cerrors[index]?.cmname && <span style={{ color: 'red', marginBottom: '10px' }}>{cerrors[index].cmname}</span>}
                                            </div>
                                        </div>
                                        <div class="col-sm-6 col-lg-3">
                                            <div class="mb-3">
                                                <label for="lname" class="form-label poppins-medium fs-6 mb-1">Last Name<span class="text-red">*</span></label>
                                                <input type="text" class={cerrors[index]?.clname ? "erricls form-control bg-gray" : "form-control bg-gray"} id="lname" placeholder="Enter last Name" autoComplete="new-password" value={field.clname} onChange={(e) => handleInputChange(index, "clname", e.target.value,2)}/>
                                                {cerrors[index]?.clname && <span style={{ color: 'red', marginBottom: '10px' }}>{cerrors[index].clname}</span>}
                                            </div>
                                        </div>
                                        <div class="col-sm-6 col-lg-3">
                                            <div class="mb-3">
                                                <label for="calender" class="form-label poppins-medium fs-6 mb-1">Date of Birth</label>
                                                <input type="date" class={cerrors[index]?.cdob ? "erricls form-control bg-gray" : "form-control bg-gray"} id="date" placeholder="20/12/1996" autoComplete="new-password" value={field.cdob} onChange={(e) => handleInputChange(index, "cdob", e.target.value,2)}/>
                                                {cerrors[index]?.cdob && <span style={{ color: 'red', marginBottom: '10px' }}>{cerrors[index].cdob}</span>}
                                            </div>
                                        </div>
                                    </div></div>
                                    ))}

                                    {infantformData.map((field, index) => (
                                   <div> 
                                <div class="travelerBox">
                                    <h6 class="text-start poppins-bold mb-2">{index+1}. Infant</h6> 
                                
                                <div class="row mt-4 mb-2">
                                    <div class="form-check col ps-2">
                                        <input class="form-check-input mt-0" type="radio" name={`infant-${index}`} id="{index}_flexRadioDefault1" checked={field.igender == 'Mr' }
                             value="Mr" onChange={(e) => handleInputChange(index, "igender", e.target.value,3)}/>
                                        <label class="form-check-label poppins-regular" for="{index}_flexRadioDefault1">
                                            Mr.
                                        </label>
                                    </div>
                                    <div class="form-check col">
                                        <input class="form-check-input" type="radio" name={`infant-${index}`} id="flexRadioDefault1" checked={field.igender == 'Mrs'}
                            value="Mrs" onChange={(e) => handleInputChange(index, "igender", e.target.value,3)}/>
                                        <label class="form-check-label poppins-regular" for="flexRadioDefault1">
                                            Mrs.
                                        </label>
                                    </div>
                                    <div class="form-check col">
                                        <input class="form-check-input" type="radio" name={`infant-${index}`} id="flexRadioDefault1" checked={field.igender == 'Ms'}
                           value="Ms" onChange={(e) => handleInputChange(index, "igender", e.target.value,3)}/>
                                        <label class="form-check-label poppins-regular" for="flexRadioDefault1">
                                            Ms.
                                        </label>
                                    </div>
                                </div>
                                </div>
                                    <div key={index} class="row">
                                        <div class="col-sm-6 col-lg-3">
                                            <div class="mb-3">
                                                <label for="fname" class="form-label poppins-medium fs-6 mb-1">First Name<span class="text-red">*</span></label>
                                                <input type="text" class={ierrors[index]?.ifname ? "erricls form-control bg-gray" : "form-control bg-gray"} id="fname" placeholder="Enter First Name" autoComplete="new-password" value={field.ifname}  onChange={(e) => handleInputChange(index, "ifname", e.target.value,3)}/>
                                                {ierrors[index]?.ifname && <span style={{ color: 'red', marginBottom: '10px' }}>{ierrors[index].ifname}</span>}
                                            </div>
                                        </div>
                                        <div class="col-sm-6 col-lg-3">
                                            <div class="mb-3">
                                                <label for="mname" class="form-label poppins-medium fs-6 mb-1">Middle Name<span class="text-red">*</span></label>
                                                <input type="text" class={ierrors[index]?.imname ? "erricls form-control bg-gray" : "form-control bg-gray"} id="mname" placeholder="Enter middle Name" autoComplete="new-password" value={field.imname} onChange={(e) => handleInputChange(index, "imname", e.target.value,3)}/>
                                                {ierrors[index]?.imname && <span style={{ color: 'red', marginBottom: '10px' }}>{ierrors[index].imname}</span>}
                                            </div>
                                        </div>
                                        <div class="col-sm-6 col-lg-3">
                                            <div class="mb-3">
                                                <label for="lname" class="form-label poppins-medium fs-6 mb-1">Last Name<span class="text-red">*</span></label>
                                                <input type="text" class={ierrors[index]?.ilname ? "erricls form-control bg-gray" : "form-control bg-gray"} id="lname" placeholder="Enter last Name" autoComplete="new-password" value={field.ilname} onChange={(e) => handleInputChange(index, "ilname", e.target.value,3)}/>
                                                {ierrors[index]?.ilname && <span style={{ color: 'red', marginBottom: '10px' }}>{ierrors[index].ilname}</span>}
                                            </div>
                                        </div>
                                        <div class="col-sm-6 col-lg-3">
                                            <div class="mb-3">
                                                <label for="calender" class="form-label poppins-medium fs-6 mb-1">Date of Birth</label>
                                                <input type="date" class={ierrors[index]?.idob ? "erricls form-control bg-gray" : "form-control bg-gray"} id="date" placeholder="DOB" autoComplete="new-password" value={field.idob} onChange={(e) => handleInputChange(index, "idob", e.target.value,3)} data-date-format="DD-MMMM-YYYY"/>
                                                {ierrors[index]?.idob && <span style={{ color: 'red', marginBottom: '10px' }}>{ierrors[index].idob}</span>}

                                            </div>
                                        </div>
                                    </div></div>
                                    ))}
                            </div>
                            <div class="contBtnSec nextBtn nextBtnFF text-end mt-4">
                                <button type="submit" class="border-0 btn btn-primary nextBtnLink pe-2 ps-3 rounded-pill text-white" role="button">Next<i class="la-angle-right las ms-2 p-1 rounded-circle"></i></button>
                            </div>
                            </form>
                        </div>
                    </div>
                    <BookingDetails suggestion={state?.dealdata} searchdata={state?.searchdata}/>
                </div>
            </div>
        </div></React.Fragment>;
};

export default Contactinfo;
