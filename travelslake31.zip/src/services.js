import axios from "axios"
import instance from './httpService';
import { format,addDays   } from 'date-fns';
const Apiurl    = process.env.REACT_APP_APIUrl;
const swsApiurl = process.env.REACT_APP_CWSAPIURL;


/* Get search field autocomplete flight records */


export const getSeatchrecords = (query) => {
    return axios({
        url: swsApiurl+`/airports?q=${query}`,
        method: 'get',
    headers: {
        "Content-Type": "application/json",
    }
 });


}
/* Get countries list */
export const getCountries = (query) => {
    return axios({
        url: swsApiurl+`/countrylist`,
        method: 'get',
    headers: {
        "Content-Type": "application/json",
    }
 });


}

/* Get countries list */
export const getStatesdata = (countrycode) => {
    return axios({
        url: swsApiurl+`/statebycountry?cc=${countrycode}`,
        method: 'get',
    headers: {
        "Content-Type": "application/json",
    }
 });


}


/* Get Homepage data , deals etc */

export const getHomepagedata = (getDealsArr) => {
    
    const data = instance({
        // url of the api endpoint (can be changed)
        url: "api/commoncontent/",
        method: "POST",
        data: getDealsArr,
      });

    return data;



}

/* Get Flight Token from data */

export const getFlighttoken = (data) => {
    return axios({
    url: Apiurl+'flightsearch/web?'+data,
    method: 'get',
    headers: {
        "Content-Type": "application/json",
    },
 })

}

/* Get Flight Token from data */

export const getFlightRecords = (token) => {
     const data = instance({
        // url of the api endpoint (can be changed)
         url: '/flight/fetch/?xSId='+token,
        method: "POST"
      });

     return data;

}

/*format time 01h 16m */
export const formatFlightTime = (tm,evall) => {
    if(evall == 1 && tm != null){
        const timvalue = tm.match(/.{1,2}/g);
        return timvalue[0]+'hr '+timvalue[1]+'m';
    }else if(evall == 2 ){
        const timvalue = tm.match(/.{1,2}/g);
        return convertTo12HourFormat(timvalue[0]+':'+timvalue[1],1);
    }else if(evall == 3 && tm != null){
        const timvalue = tm.match(/.{1,2}/g);
        const dt = convertTo12HourFormat(timvalue[0]+':'+timvalue[1],2);
        return dt.replace("AM","").replace("PM","");
    }

}




const convertTo12HourFormat = (time,istp) => {
    const [hours, minutes] = time.split(":");
    const date = new Date();
    date.setHours(hours);
    date.setMinutes(minutes);
    if(istp == 1){
         return date.toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
          hour12: true,
        });
    }else{
         return date.toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
          hour12: true,
        });
    }
   
};

export const formatFlightDate = (date) => {
   let dateRex = date.match(/.{1,2}/g);
   dateRex = dateRex[1]+'/'+dateRex[0]+'/'+dateRex[2];
   console.log(dateRex)
   return format(new Date(dateRex), "dd, MMM yy")
};
