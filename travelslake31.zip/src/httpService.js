import axios from "axios"
const Apiurl    = process.env.REACT_APP_APIUrl;
const swsApiurl = process.env.REACT_APP_CWSAPIURL;

const instance = axios.create({
  baseURL : '',
  headers: {
    'Content-Type': "application/json",
    timeout : 1000,
  }, 
  // .. other options
});

export default instance;