// src/components/Header.js
import React from 'react';
import { Link } from 'react-router-dom';
const contactNumber = process.env.REACT_APP_DefaultContactNumber;
const Header = () => {
    return (
        <header className="sticky-sm-top bg-white py-1">
        <nav className="mainHeader navbar navbar-expand-lg py-lg-0">
            <div className="container">
                <Link className="nav-link" to="/"><img src={`${process.env.PUBLIC_URL}/assets/images/logo-header.png`}alt="logo" /></Link>
                <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse align-items-stretch" id="navbarSupportedContent">
                    <ul className="navbar-nav customNav mx-auto mb-2 mb-lg-0">
                        <li className="nav-item">
                                <Link className="nav-link" to="/">Home</Link>
                        </li>
                        <li className="nav-item">
                             <Link className="nav-link" to="/about">About</Link>
                        </li>
                        <li className="nav-item dropdown megamenu">
                            <a className="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" aria-expanded="false">
                                Top Airlines
                            </a>
                           {/* <ul className="dropdown-menu megamenu-content" aria-labelledby="navbarDropdownMenuLink">
                                <li><a className="dropdown-item" href="#"> Pal Provincial Airlines</a></li>
                                <li><a className="dropdown-item" href="#">Royal Air Maroc</a></li>
                                <li><a className="dropdown-item" href="#">Turkish Airlines</a></li>
                                <li><a className="dropdown-item" href="#">Qatar Airways</a></li>
                                <li><a className="dropdown-item" href="#">Sunwing Airlines</a></li>
                                <li><a className="dropdown-item" href="#">United Airlines</a></li>
                            </ul> */}
                        </li>
                        <li className="nav-item dropdown megamenu">
                            <a className="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" aria-expanded="false">
                                Top Destinations
                            </a>
                           {/* <ul className="dropdown-menu megamenu-content" aria-labelledby="navbarDropdownMenuLink">
                                <li><a className="dropdown-item" href="#">Houston</a></li>
                                <li><a className="dropdown-item" href="#">Kelowna</a></li>
                                <li><a className="dropdown-item" href="#">London</a></li>
                                <li><a className="dropdown-item" href="#">Mexico City</a></li>
                                <li><a className="dropdown-item" href="#">Minneapolis</a></li>
                                <li><a className="dropdown-item" href="#">Indianapolis</a></li>
                                <li><a className="dropdown-item" href="#">Las Vegas</a></li>
                                <li><a className="dropdown-item" href="#">Los Angeles</a></li>
                                <li><a className="dropdown-item" href="#">Miami</a></li>
                                <li><a className="dropdown-item" href="#">Montreal</a></li>
                            </ul>*/}
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to="/contact">Contact</Link>
                        </li>
                    </ul>
                    <div className="language ms-3 d-flex align-items-center">
                        <ul className="navbar-nav">
                            <li className="nav-item dropdown">
                                <a href="#" id="languages" className="align-items-center d-flex dropdown-toggle nav-link pe-3 ps-2 py-1 rounded-pill" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <img id="imgNavSel" src={`${process.env.PUBLIC_URL}/assets/images/us.svg`} alt="" className="flag-icon rounded-circle me-2" width="20" height="20" />
                                    <span id="lanNavSel"> ENG</span><span className="caret ps-2"></span>
                                </a>
                                <div id="languages-list" className="dropdown-menu show-dropdown" aria-labelledby="dropdown-list" x-placement="bottom-start" >
                                    <a id="naven" data-lang-name="English" href="" className="language dropdown-item">
                                        <img id="imgNaven" src={`${process.env.PUBLIC_URL}/assets/images/us.svg`} alt="en" className="flag-icon rounded-circle me-1" width="20" height="20" />
                                        <span id="lanNaven "> English</span>
                                    </a>
                                    <a id="naves" data-lang-name="Español" href="" className="language dropdown-item">
                                        <img id="imgNaves" src={`${process.env.PUBLIC_URL}/assets/images/mx.svg`} alt="es" className="flag-icon rounded-circle me-1" width="20" height="20" />
                                        <span id="lanNaves "> Español</span>
                                    </a>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div className="call-button p-2 bg-light-orange rounded-pill">
                        <a href="tel:{contactNumber}" role="button" className="phone_number d-flex align-items-center text-decoration-none">
                            <div className="contactNo pe-2 ps-4 text-end">
                                <p className="mb-0 text-black barlow-regular">Need help? Call us</p>
                                <h5 className="mb-0 text-orange poppins-bold">{contactNumber}</h5>
                            </div>
                            <img className="phoneImg" alt="Call Toll-Free for Best Fare!" src={`${process.env.PUBLIC_URL}/assets/images/call_agentH.png`} />
                        </a>
                    </div>
                    
                </div>
            </div>
        </nav>
    </header>
    );
};

export default Header;
