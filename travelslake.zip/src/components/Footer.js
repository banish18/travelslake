// src/components/Footer.js
import React from 'react';

const Footer = () => {
    return (
        <footer className="footerMain">
            
            <div className="my-4 py-3 qualityPaymentCardSec">
                <div className="container">
                    <div className="row align-items-center">
                        <div className="col">
                            <ul className="align-items-center d-flex list-unstyled mb-3 mb-md-0 qualitySymbols">
                                <li className="qsBoxe"><img src="assets/images/arc.png" alt="" className="img-fluid" /></li>
                                <li className="qsBoxe"><img src="assets/images/asta.png" alt="" className="img-fluid" /></li>
                                <li className="qsBoxe"><img src="assets/images/clin.png" alt="" className="img-fluid" /></li>
                                <li className="qsBoxe"><img src="assets/images/trustedsite.png" alt="" className="img-fluid" /></li>
                                <li className="qsBoxe"><img src="assets/images/comodo.png" alt="" className="img-fluid" /></li>
                            </ul>
                        </div>
                        <div className="col">
                            <ul className="d-flex justify-content-end list-unstyled mb-0 ms-auto payCards">
                                <li><img src="assets/images/ms.png" alt="" /></li>
                                <li><img src="assets/images/vs.png" alt="" /></li>
                                <li><img src="assets/images/vse.png" alt="" /></li>
                                <li><img src="assets/images/dis.png" alt="" /></li>
                                <li><img src="assets/images/ae.png" alt="" /></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div className="copyrightSec">
                <div className="container">
                    <p className="border-opacity-25 border-top fs-6 poppins-regular mb-0 py-3 text-center text-white text-white-65">Copyright © 2013-2029</p>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
