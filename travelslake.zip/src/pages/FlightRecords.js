// src/pages/Home.js
import {React,useState,useEffect} from 'react';
import Search from './Search.js';
import Mediator from './sections/Mediator.js';
import { useLocation,useNavigate } from 'react-router-dom'
import PriceAlertModal from './modals/PriceAlertModal.js'
const FlightRecords = () => {
    const { state } = useLocation();
    const navigate = useNavigate();
    const [isLoading, setIsLoading] = useState(true);
    const [alertvalue, setAlertvalue] = useState(true);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const dealsRec = state?.dealdata;
    useEffect(() => {
        setTimeout(
            function() {
                
                setIsLoading(false)
            }
            .bind(this),
            5000
        );
    }, []);
    const nextStep = () => {
        const dealdsRec = state?.formdata;
           
        navigate('/contact-info',{
                state: {'dealdata':dealdsRec,'selectedsec':'contact'}
              });
    }

     const closeModal = () => {
        setIsModalOpen(false)
    }

    const showAlert = () => {
        setAlertvalue(!alertvalue);
        if(alertvalue){
            setIsModalOpen(true)
        }
    }

    return <div className="home">
            
            {isLoading && <Mediator /> }
           {!isLoading && <div><Search ishowHeading={0} preData={state?.formdata}/> <div class="mainContent py-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3">
                        <button class="btn btn-secondary bg-green-100 text-uppercase text-white d-lg-none w-100 mb-3" type="button" data-bs-toggle="collapse" data-bs-target="#collapsefilterSec" aria-expanded="false" aria-controls="collapsefilterSec">
                            Filter
                        </button>
                        <aside class="bg-white collapse d-lg-block filterSec mb-3 mb-lg-0 p-3 rounded-3 shadow" id="collapsefilterSec">

                            <div class="border-bottom filterBox mb-4">
                                <h6 class="mb-2 poppins-semibold">Stop</h6>
                                <div class="filterCheckboxSec">
                                    <ul class="d-inline-flex gap-2 list-unstyled mb-0 w-100">
                                        <li class="mb-1">
                                            <div class="fcBox form-check mb-0 overflow-hidden rounded-2 text-center">
                                                <label class="form-check-label w-100" for="flexCheckDefault1">
                                                    <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault1" checked="" />
                                                    <span>Non Stop</span>
                                                </label>
                                            </div>
                                        </li>
                                        <li class="mb-1">
                                            <div class="fcBox form-check mb-0 overflow-hidden rounded-2 text-center">
                                                <label class="form-check-label w-100" for="flexCheckDefault2">
                                                    <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault2" />
                                                    <span>One Stop
                                                    </span>
                                                </label>
                                            </div>
                                        </li>
                                        <li class="mb-1">
                                            <div class="fcBox form-check mb-0 overflow-hidden rounded-2 text-center">
                                                <label class="form-check-label w-100" for="flexCheckDefault3">
                                                    <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault3" />
                                                    <span>2+ Stop
                                                    </span>
                                                </label>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="border-bottom filterBox mb-4">
                                <h6 class="mb-2 poppins-semibold">Departure from</h6>
                                <div class="filterCheckboxSec">
                                    <ul class="list-unstyled mb-0 d-inline-flex flex-wrap w-100">
                                        <li class="w-50 p-1 mb-1">
                                            <div class="fcBox form-check mb-0 overflow-hidden rounded-pill text-center">
                                                <label class="form-check-label w-100" for="flexCheckDefault4">
                                                    <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault4" checked="" />
                                                    <span>Before 6AM</span>
                                                </label>
                                            </div>
                                        </li>
                                        <li class="w-50 p-1 mb-1">
                                            <div class="fcBox form-check mb-0 overflow-hidden rounded-pill text-center">
                                                <label class="form-check-label w-100" for="flexCheckDefault5">
                                                    <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault5" />
                                                    <span>6AM - 12PM
                                                    </span>
                                                </label>
                                            </div>
                                        </li>
                                        <li class="w-50 p-1 mb-1">
                                            <div class="fcBox form-check mb-0 overflow-hidden rounded-pill text-center">
                                                <label class="form-check-label w-100" for="flexCheckDefault6">
                                                    <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault6" />
                                                    <span>12PM - 6PM
                                                    </span>
                                                </label>
                                            </div>
                                        </li>
                                        <li class="w-50 p-1 mb-1">
                                            <div class="fcBox form-check mb-0 overflow-hidden rounded-pill text-center">
                                                <label class="form-check-label w-100" for="flexCheckDefault7">
                                                    <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault7" />
                                                    <span>After 6PM
                                                    </span>
                                                </label>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="border-bottom filterBox mb-4">
                                <h6 class="mb-3 poppins-semibold">Flight Price</h6>
                                <div class="filterCheckboxSec">
                                    <div class="rangeSlider">
                                        {/*} Range Silder */}
                                        <input type="range" class="form-range" id="priceRange" min="36" max="672" value="100" />
                                        <div class="minMaxLabel d-flex justify-content-between">
                                            <span id="minPrice">$36</span>
                                            <span id="maxPrice">$672</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="filterBox">
                                <h6 class="mb-3 poppins-semibold">Airlines</h6>
                                <div class="filterCheckboxSec">
                                    <ul class="list-unstyled mb-0" id="airlinesList">
                                        <li class="align-items-center d-flex justify-content-between">
                                            <div class="form-check mb-0">
                                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault1" checked="" />
                                                <label class="form-check-label" for="flexCheckDefault1">
                                                    Vistara
                                                </label>
                                            </div>
                                            <span class="filterCount">
                                                44
                                            </span>
                                        </li>
                                        <li class="align-items-center d-flex justify-content-between">
                                            <div class="form-check mb-0">
                                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault2" />
                                                <label class="form-check-label" for="flexCheckDefault2">
                                                    Air India
                                                </label>
                                            </div>
                                            <span class="filterCount">
                                                148
                                            </span>
                                        </li>
                                        <li class="align-items-center d-flex justify-content-between">
                                            <div class="form-check mb-0">
                                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault3" />
                                                <label class="form-check-label" for="flexCheckDefault3">
                                                    Air Asia
                                                </label>
                                            </div>
                                            <span class="filterCount">
                                                69
                                            </span>
                                        </li>
                                        <li class="align-items-center d-flex justify-content-between">
                                            <div class="form-check mb-0">
                                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault4" />
                                                <label class="form-check-label" for="flexCheckDefault4">
                                                    Vistara
                                                </label>
                                            </div>
                                            <span class="filterCount">
                                                44
                                            </span>
                                        </li>
                                        <li class="align-items-center d-flex justify-content-between">
                                            <div class="form-check mb-0">
                                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault5" />
                                                <label class="form-check-label" for="flexCheckDefault5">
                                                    Air India
                                                </label>
                                            </div>
                                            <span class="filterCount">
                                                44
                                            </span>
                                        </li>
                                        <li class="align-items-center d-flex justify-content-between">
                                            <div class="form-check mb-0">
                                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault6" />
                                                <label class="form-check-label" for="flexCheckDefault6">
                                                    Vistara
                                                </label>
                                            </div>
                                            <span class="filterCount">
                                                44
                                            </span>
                                        </li>
                                        <li class="align-items-center d-flex justify-content-between hidden">
                                            <div class="form-check mb-0">
                                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault7" />
                                                <label class="form-check-label" for="flexCheckDefault7">
                                                    Air India
                                                </label>
                                            </div>
                                            <span class="filterCount">
                                                104
                                            </span>
                                        </li>
                                        <li class="align-items-center d-flex justify-content-between hidden">
                                            <div class="form-check mb-0">
                                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault8" />
                                                <label class="form-check-label" for="flexCheckDefault8">
                                                    Air Asia
                                                </label>
                                            </div>
                                            <span class="filterCount">
                                                44
                                            </span>
                                        </li>
                                        <li class="align-items-center d-flex justify-content-between hidden">
                                            <div class="form-check mb-0">
                                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault5" />
                                                <label class="form-check-label" for="flexCheckDefault5">
                                                    Air India
                                                </label>
                                            </div>
                                            <span class="filterCount">
                                                44
                                            </span>
                                        </li>
                                        <li class="align-items-center d-flex justify-content-between hidden">
                                            <div class="form-check mb-0">
                                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault6" />
                                                <label class="form-check-label" for="flexCheckDefault6">
                                                    Vistara
                                                </label>
                                            </div>
                                            <span class="filterCount">
                                                44
                                            </span>
                                        </li>
                                    </ul>
                                    <div>
                                        <span class="fs-6 more-button" id="showMoreBtn">More <span class="icon">+</span></span>
                                        <span class="more-button hidden" id="showLessBtn">Less <span class="icon">-</span></span>
                                    </div>
                                    <button class="bg-gray border btn mt-4 px-2 py-1 reset-btn rounded-pill w-100" type="reset" value="Clear All">Clear All Filters</button>
                                </div>
                            </div>
                        </aside>
                    </div>
                    <div class="col-lg-9 ps-lg-4">
                        <div class="justify-content-md-between mb-3 sortListingSec">
                            <div class="align-items-center row sortingBtn">
                                <div class="col-lg-3 col-md-6">
                                    <div class="active align-items-center bg-gray d-flex justify-content-between px-2 py-2 rounded sortBox">
                                        <p class="fs-6 mb-0 sortTxt text-black-65 text-uppercase">Nonstop First</p>
                                        <h5 class="mb-0 poppins-semibold">$1,035</h5>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                    <div class="align-items-center bg-gray d-flex justify-content-between px-2 py-2 rounded sortBox">
                                        <p class="fs-6 mb-0 sortTxt text-black-65 text-uppercase">Lowest Price</p>
                                        <h5 class="mb-0 poppins-semibold">$1,035</h5>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                    <div class="align-items-center bg-gray d-flex justify-content-between px-2 py-2 rounded sortBox">
                                        <p class="fs-6 mb-0 sortTxt text-black-65 text-uppercase">Shortest Duration</p>
                                        <h5 class="mb-0 poppins-semibold">$1,035</h5>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                    <div class="align-items-center bg-gray d-flex form-check form-switch justify-content-between px-2 py-2 recomendedBtn rounded">
                                        <label class="form-check-label fs-6 pe-3 poppins-semibold text-blue" for="flexSwitchCheckDefault">Create Price Alert</label>
                                        <input class="border-0 form-check-input" type="checkbox" id="flexSwitchCheckDefault" value="{(alertvalue ? 'on' : 'off')}" onChange={showAlert} />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="fligtListingSec pb-4">
                            <div class="bg-white border flightListContainer mb-3 shadow-none">
                                <div class="flcBox px-1">
                                    <div class="align-items-lg-center d-lg-flex justify-content-lg-between p-1 row">
                                        <div class="col-md-7 col-lg-8 departSec flightDealsDtlWrapper">
                                            <div class="d-flex flsLftDtl justify-content-between">
                                                <div class="airCompany align-items-center d-flex pe-3">
                                                    <img src={`${process.env.PUBLIC_URL}/assets/images/air01.png`} alt="air" class="rounded-pill" width="32" height="32" />
                                                    <p class="airlineName ps-2 text-start mb-0 poppins-semibold">
                                                        IndiGo<br />
                                                        <span class="text-black-50 poppins-regular fs-6">6E-5218</span>
                                                    </p>
                                                </div>
                                                <div class="align-items-center border-left d-flex routeDtlSec">
                                                    <div class="pe-3 routeOrigin text-end">
                                                        <h5 class="mb-0 timeLoc poppins-semibold">
                                                            07:05
                                                            <span class="routeloc d-block fs-6 text-black-65">
                                                                LAX
                                                            </span>
                                                        </h5>
                                                    </div>
                                                    <div class="routPath w-50">
                                                        <span class="text-black-65">01h 16m</span>
                                                        <div class="routPathLine position-relative">
                                                        </div>
                                                        <span class=" pt-1 text-black-65">Nonstop </span>
                                                    </div>
                                                    <div class="ps-3 routeDest">
                                                        <h5 class="timeLoc ps-3 mb-0 poppins-semibold">
                                                            07:05
                                                            <span class="routeloc d-block fs-6 text-black-65">
                                                                LAX
                                                            </span>
                                                        </h5>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-5 col-lg-4 d-flex justify-content-between align-items-center">
                                            <div class="align-items-center d-flex flsPriceBtn">
                                                <h5 class="mb-0 pe-3 poppins-semibold ps-4 text-center text-orange">$78<sup>.19</sup>
                                                    <span class="d-block extraDis fs-6 text-blue">Extra 20% Off</span>
                                                </h5>
                                            </div>
                                            <div class="hurryBtn text-end">
                                                <button type="button" class="btn btn-outline-primary flsBookingBtn poppins-regular px-3 py-2 rounded-pill" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight">Select <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M9 9L5.5 13L7.5 14.5L12 9L7.5 3.49999L5.5 4.99999L9 9Z" fill="#FF6433"></path>
                                                    </svg></button>
                                                <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel" aria-modal="true" role="dialog">
                                                    <div class="border-bottom offcanvas-header">
                                                        <h5 class="offcanvas-title poppins-bold" id="offcanvasRightLabel">Review Flight Details</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                                                    </div>
                                                    <div class="offcanvas-body">
                                                        <ul class="border-0 gap-2 ittr-sec-tab mb-3 nav nav-tabs" id="myTab" role="tablist">
                                                            <li class="nav-item" role="presentation">
                                                                <button class="nav-link active" id="departure-sec-tab" data-bs-toggle="tab" data-bs-target="#departure-sec" type="button" role="tab" aria-controls="departure-sec" aria-selected="true">Departure Flight</button>
                                                            </li>
                                                            <li class="nav-item" role="presentation">
                                                                <button class="nav-link" id="return-sec-tab" data-bs-toggle="tab" data-bs-target="#return-sec" type="button" role="tab" aria-controls="return-sec" aria-selected="false" tabindex="-1">Return Flight</button>
                                                            </li>
                                                        </ul>
                                                        <div class="tab-content" id="myTabContent">
                                                            <div class="tab-pane fade active show" id="departure-sec" role="tabpanel" aria-labelledby="departure-sec-tab">
                                                                <div class="flightDtlContent">
                                                                    <div class="border-bottom d-flex justify-content-between pb-2">
                                                                        <div class="dstiTxt">
                                                                            <h6 class="poppins-bold mb-0 text-start">Los Angeles - Las Vegas<span class="orange-text"></span></h6>
                                                                        </div>
                                                                        <div class="bggeTxt">
                                                                            <ul class="alrghtDtl barlow-regular d-inline-flex fs-6 gap-3 list-unstyled mb-0 text-black-65">
                                                                                <li>1 stop</li>
                                                                                <li>8h 50m</li>
                                                                                <li> 1 Traveler</li>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                    <div class="bg-white flight-box-mainwrq my-2">
                                                                        <div class="airlineBaggageDtl align-items-center d-flex justify-content-between mb-2">
                                                                            <div class="airCompany align-items-center d-flex pe-4">
                                                                                <img src={`${process.env.PUBLIC_URL}/assets/images/air01.png`} alt="air" class="rounded-circle" width="30" height="30" />
                                                                                <p class="airlineName poppins-semibold mb-0 ps-2 text-start">
                                                                                    IndiGo<br/>
                                                                                    <span class="fs-6 poppins-regular text-black-50">6E-5218</span>
                                                                                </p>
                                                                            </div>
                                                                            <div class="ite-date">
                                                                                <span class="mb-0 text-black-65 fs-6 poppins-regular">Tue, Apr 16</span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="row airbox-details align-items-center">
                                                                            <div class="col-3 col-sm-3 col-md-3 col-lg-3 col-xl-3 col-xxl-3 text-start pe-0">
                                                                                <h5 class="poppins-bold mb-0">06:05 AM</h5>
                                                                                <p class="mb-0">BOM - Mumbai</p>
                                                                            </div>
                                                                            <div class="col-6 col-sm-6 col-md-6 col-lg-6 col-xl-6 col-xxl-6">
                                                                                <div class="align-items-center border-left d-flex routeDtlSec w-100">
                                                                                    <div class="pe-3 routeOrigin text-end">
                                                                                        <h5 class="mb-0 pe-3 poppins-semibold timeLoc">
                                                                                            07:05
                                                                                            <span class="routeloc d-block fs-6 text-black-65">
                                                                                                LAX
                                                                                            </span>
                                                                                        </h5>
                                                                                    </div>
                                                                                    <div class="routPath w-50">
                                                                                        <span class="text-black-65">01h 16m</span>
                                                                                        <div class="routPathLine position-relative">
                                                                                        </div>
                                                                                        <ul class="alrghtDtl barlow-regular d-inline-flex fs-6 gap-3 list-unstyled mb-0 text-black-65">
                                                                                            <li class="px-0">AS-604</li>
                                                                                            <li class="px-0">Boeing 73H</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="ps-3 routeDest">
                                                                                        <h5 class="mb-0 poppins-semibold ps-3 timeLoc">
                                                                                            07:05
                                                                                            <span class="routeloc d-block fs-6 text-black-65">
                                                                                                LAX
                                                                                            </span>
                                                                                        </h5>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-3 col-lg-3 col-md-3 col-sm-3 col-xl-3 col-xxl-3 ps-0 text-start">
                                                                                <h5 class="poppins-bold mb-0">07:21 AM</h5>
                                                                                <p class="mb-0">DEL - New Delhi</p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="bg-light-orange cabiOtherDtl my-4 position-relative py-2 text-center">
                                                                        <ul class="baggageDtl d-inline-flex justify-content-around list-unstyled mb-0 w-100">
                                                                            <li>Baggage: <span class="text-black-50">Adult</span></li>
                                                                            <li>Check In: <span class="text-black-50">0 Kg</span></li>
                                                                            <li>Cabin: <span class="text-black-50">7 Kgs</span></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="tab-pane fade" id="return-sec" role="tabpanel" aria-labelledby="return-sec-tab">
                                                                <div class="flightDtlContent">
                                                                    <div class="border-bottom d-flex justify-content-between pb-2">
                                                                        <div class="dstiTxt">
                                                                            <h6 class="poppins-bold mb-0 text-start">Las Vegas - Los Angeles<span class="orange-text"></span></h6>
                                                                        </div>
                                                                        <div class="bggeTxt">
                                                                            <ul class="alrghtDtl barlow-regular d-inline-flex fs-6 gap-3 list-unstyled mb-0 text-black-65">
                                                                                <li>1 stop</li>
                                                                                <li>8h 50m</li>
                                                                                <li> 1 Traveler</li>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                    <div class="bg-white flight-box-mainwrq my-2">
                                                                        <div class="airlineBaggageDtl align-items-center d-flex justify-content-between mb-2">
                                                                            <div class="airCompany align-items-center d-flex pe-4">
                                                                                <img src={`${process.env.PUBLIC_URL}/assets/images/air01.png`} alt="air" class="rounded-circle" width="30" height="30" />
                                                                                <p class="airlineName poppins-semibold mb-0 ps-2 text-start">
                                                                                    IndiGo<br/>
                                                                                    <span class="fs-6 poppins-regular text-black-50">6E-5218</span>
                                                                                </p>
                                                                            </div>
                                                                            <div class="ite-date">
                                                                                <span class="mb-0 text-black-65 fs-6 poppins-regular">Tue, Apr 16</span></div>
                                                                        </div>
                                                                        <div class="row airbox-details align-items-center">
                                                                            <div class="col-3 col-sm-3 col-md-3 col-lg-3 col-xl-3 col-xxl-3 text-start pe-0">
                                                                                <h5 class="poppins-bold mb-0">06:05 AM</h5>
                                                                                <p class="mb-0">BOM - Mumbai</p>
                                                                            </div>
                                                                            <div class="col-6 col-sm-6 col-md-6 col-lg-6 col-xl-6 col-xxl-6">
                                                                                <div class="align-items-center border-left d-flex routeDtlSec w-100">
                                                                                    <div class="pe-3 routeOrigin text-end">
                                                                                        <h5 class="mb-0 pe-3 poppins-semibold timeLoc">
                                                                                            07:05
                                                                                            <span class="routeloc d-block fs-6 text-black-65">
                                                                                                LAX
                                                                                            </span>
                                                                                        </h5>
                                                                                    </div>
                                                                                    <div class="routPath w-50">
                                                                                        <span class="text-black-65">01h 16m</span>
                                                                                        <div class="routPathLine position-relative">
                                                                                        </div>
                                                                                        <ul class="alrghtDtl barlow-regular d-inline-flex fs-6 gap-3 list-unstyled mb-0 text-black-65">
                                                                                            <li class="px-0">AS-604</li>
                                                                                            <li class="px-0">Boeing 73H</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="ps-3 routeDest">
                                                                                        <h5 class="mb-0 poppins-semibold ps-3 timeLoc">
                                                                                            07:05
                                                                                            <span class="routeloc d-block fs-6 text-black-65">
                                                                                                LAX
                                                                                            </span>
                                                                                        </h5>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-3 col-lg-3 col-md-3 col-sm-3 col-xl-3 col-xxl-3 ps-0 text-start">
                                                                                <h5 class="poppins-bold mb-0">07:21 AM</h5>
                                                                                <p class="mb-0">DEL - New Delhi</p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="bg-light-orange cabiOtherDtl my-4 position-relative py-2 text-center">
                                                                        <ul class="baggageDtl d-inline-flex justify-content-around list-unstyled mb-0 w-100">
                                                                            <li>Baggage: <span class="text-black-50">Adult</span></li>
                                                                            <li>Check In: <span class="text-black-50">0 Kg</span></li>
                                                                            <li>Cabin: <span class="text-black-50">7 Kgs</span></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <h5 class="poppins-bold text-start">This itinerary includes a self-transfer</h5>
                                                        <p class="text-start">Our self-transfer hack helps you reach any destination by connecting separate flights. Since these flights are officially independent from one another, you might need to leave the transit zone:</p>
                                                        <ul class="fs-6 list-group-item-info pe-3 py-4 rounded-1 text-start">
                                                            <li class="mb-2">If you have&nbsp;<b>checked baggage</b>, you’ll need to collect it and recheck it</li>
                                                            <li class="mb-2">If you don’t have a <b>boarding pass for your next flight</b>, you’ll need to check in for that flight.</li>
                                                            <li class="mb-2">In some cases, you’ll need to go through <b>passport control</b> again as if you’d be entering the country, so you might need a&nbsp;visa.</li>
                                                            <li>Check the&nbsp;<b>airport terminal</b> for your next flight, as it might be different from the one you landed at.</li>
                                                        </ul>
                                                    </div>
                                                    <div class="bg-gray flightPriceDtl px-3 py-3">
                                                        <div class="align-items-center me-0 ms-0 row">
                                                            <div class="col-6 col-sm-6 col-md-6 col-lg-6 col-xl-6 col-xxl-6 ps-0 text-start">
                                                                <h3 class="mb-0 poppins-bold">$142.<sup>97</sup><span class="fs-6 poppins-regular-italic ps-2 text-black-50">Fare / person</span></h3>
                                                            </div>
                                                            <div class="col-6 col-sm-6 col-md-6 col-lg-6 col-xl-6 col-xxl-6 text-end pe-0"><a type="button" class="border-0 btn btn-primary flsBookingNowBtn px-4 py-2 rounded-pill text-uppercase text-white" onClick={() => nextStep()}>Book Now</a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="loadMoreSec text-center mt-4">
                                <a href="#" class="bg-gray btn btn-secondary px-4 rounded-pill text-black" role="button">Load More Flights</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div><PriceAlertModal isOpen={isModalOpen} onClose={closeModal} title="My Modal Title">
                
                </PriceAlertModal></div> }
            </div>;
};

export default FlightRecords;
