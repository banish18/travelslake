// src/pages/Home.js
import {React,useState,useEffect} from 'react';
import Search from './Search.js';
import Mediator from './sections/Mediator.js';
import Filters from './sections/Filters.js';
import { useLocation,useNavigate } from 'react-router-dom'
import PriceAlertModal from './modals/PriceAlertModal.js'
import { getFlightRecords,formatFlightTime } from '../services';

const currSign = process.env.REACT_APP_Currsign;

const FlightRecords = () => {
    const { state,search } = useLocation();
    const navigate = useNavigate();
    const [isLoading, setIsLoading] = useState(true);
    const [alertvalue, setAlertvalue] = useState(true);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [flightRec, setFlightRec] = useState([]);
    const [searchdata, setSearchdata] = useState([]);
    const dealsRec = state?.dealdata;
    useEffect(() => {
         getFlights();
    }, []);

    const getFlights = async () => {
        const query = new URLSearchParams(search);
       await getFlightRecords(query.get('sid')).then(res => {
            console.log(res)
            if(res.data.IsSuccess && res.data.Model.IsExpired == false){
               setIsLoading(false)
               setSearchdata(res.data.Model.SearchRequest);
               setFlightRec(res.data.Model.ListOfContracts);
              // console.log(res.data.Model.SearchRequest);
            }else{
                //alert("Error fetching data:", res.data.Message);
            }
        }).catch(err => {
        console.error("Error fetching data:", err);
        });
    }

    const getAfterdec = (n) => {
        console.log();
         const nn = Math.abs(n); // Change to positive
         const fd = nn - Math.floor(n);
         const finalval = fd.toFixed(2).split('.')
         return '.'+finalval[1];
    }


    const nextStep = (suggestion) => {
        console.log(suggestion);
        navigate('/contact-info',{
                state: {'dealdata':suggestion,'searchdata':searchdata,'selectedsec':'contact'}
              });
    }

     const closeModal = () => {
        setIsModalOpen(false)
    }

    const showAlert = () => {
        setAlertvalue(!alertvalue);
        if(alertvalue){
            setIsModalOpen(true)
        }
    }

    const totolTraver = () => {
        return searchdata.AdultCount+searchdata.ChildCount+searchdata.InfantCount;
    }

    return <div className="home">
            {isLoading && <Mediator />}
           {!isLoading && <div><Search ishowHeading={0} preData={searchdata}/> <div class="mainContent py-5">
            <div class="container">
                <div class="row">
                    <Filters />
                    <div class="col-lg-9 ps-lg-4">
                        {/*<div class="justify-content-md-between mb-3 sortListingSec">
                            <div class="align-items-center row sortingBtn">
                                <div class="col-lg-3 col-md-6">
                                    <div class="active align-items-center bg-gray d-flex justify-content-between px-2 py-2 rounded sortBox">
                                        <p class="fs-6 mb-0 sortTxt text-black-65 text-uppercase">Nonstop First</p>
                                        <h5 class="mb-0 poppins-semibold">$1,035</h5>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                    <div class="align-items-center bg-gray d-flex justify-content-between px-2 py-2 rounded sortBox">
                                        <p class="fs-6 mb-0 sortTxt text-black-65 text-uppercase">Lowest Price</p>
                                        <h5 class="mb-0 poppins-semibold">$1,035</h5>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                    <div class="align-items-center bg-gray d-flex justify-content-between px-2 py-2 rounded sortBox">
                                        <p class="fs-6 mb-0 sortTxt text-black-65 text-uppercase">Shortest Duration</p>
                                        <h5 class="mb-0 poppins-semibold">$1,035</h5>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                    <div class="align-items-center bg-gray d-flex form-check form-switch justify-content-between px-2 py-2 recomendedBtn rounded">
                                        <label class="form-check-label fs-6 pe-3 poppins-semibold text-blue" for="flexSwitchCheckDefault">Create Price Alert</label>
                                        <input class="border-0 form-check-input" type="checkbox" id="flexSwitchCheckDefault" value="{(alertvalue ? 'on' : 'off')}" onChange={showAlert} />
                                    </div>
                                </div>
                            </div>
                        </div> */}
                        {!isLoading && flightRec?.length > 0 && 
                        <div class="fligtListingSec pb-4">
                            
                                {flightRec?.map((suggestion, index) => ( <div class="bg-white border flightListContainer mb-3 shadow-none">
                                <div class="flcBox px-1">
                                    <div class="align-items-lg-center d-lg-flex justify-content-lg-between p-1 row">
                                        <div class="col-md-7 col-lg-8 departSec flightDealsDtlWrapper">
                                            <div class="d-flex flsLftDtl justify-content-between">
                                                <div class="airCompany align-items-center d-flex pe-3">
                                                    <img src={`${process.env.PUBLIC_URL}/assets/images/air01.png`} alt="air" class="rounded-pill" width="32" height="32" />
                                                    {suggestion?.Airlines?.map((fltrec, index) => (
                                                         <p class="airlineName ps-2 text-start mb-0 poppins-semibold">
                                                            {fltrec?.Name}<br />
                                                            <span class="text-black-50 poppins-regular fs-6">{fltrec?.Code}</span>
                                                        </p>
                                                    ))}
                                                   
                                                </div>
                                                <div class="align-items-center border-left d-flex routeDtlSec">
                                                    <div class="pe-3 routeOrigin text-end">
                                                        {suggestion?.Outbound?.ListOfFlights.length == 1 && <h5 class="mb-0 timeLoc poppins-semibold">
                                                            {formatFlightTime(suggestion?.Outbound?.ListOfFlights[0].DepartureTime,2)}
                                                            <span class="routeloc d-block fs-6 text-black-65">
                                                                LAX
                                                            </span>
                                                        </h5> }
                                                        {suggestion?.Outbound?.ListOfFlights.length > 1 && <h5 class="mb-0 timeLoc poppins-semibold">
                                                            {formatFlightTime(suggestion?.Outbound?.ListOfFlights[0].DepartureTime,2)}
                                                            <span class="routeloc d-block fs-6 text-black-65">
                                                                LAX
                                                            </span>
                                                        </h5> }
                                                    </div>
                                                    <div class="routPath w-50">
                                                        <span class="text-black-65">{formatFlightTime(suggestion?.Outbound?.TripDuration,1)}</span>
                                                        <div class="routPathLine position-relative">
                                                        </div>
                                                        <span class=" pt-1 text-black-65">Nonstop </span>
                                                    </div>
                                                   <div class="ps-3 routeDest">

                                                        {suggestion?.Outbound?.ListOfFlights.length == 1 && <h5 class="timeLoc ps-3 mb-0 poppins-semibold">
                                                            {formatFlightTime(suggestion?.Outbound?.ListOfFlights[0].ArrivalTime,2)}
                                                            <span class="routeloc d-block fs-6 text-black-65">
                                                                LAX
                                                            </span>
                                                        </h5> }
                                                        {suggestion?.Outbound?.ListOfFlights.length > 1 && <h5 class="mb-0 ps-3 timeLoc poppins-semibold">
                                                            {formatFlightTime(suggestion?.Outbound?.ListOfFlights[1].ArrivalTime,2)}
                                                            <span class="routeloc d-block fs-6 text-black-65">
                                                                LAX
                                                            </span>
                                                        </h5> }
                                                         
                                                    </div> 
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-5 col-lg-4 d-flex  justify-content-between align-items-center">
                                            <div class="align-items-center d-flex flsPriceBtn flex-row">
                                                <h5 class="mb-0 pe-3 poppins-semibold ps-4 text-center text-orange">{currSign}${Math.floor(suggestion?.TotalFare)}<sup>{getAfterdec(suggestion?.TotalFare)}</sup>
                                                    {/* <span class="d-block extraDis fs-6 text-blue">Extra 10% Off</span> */ }
                                                <br />
                                                <a type="button" className="flight_details_btn mt-1" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight">Flight Details <i class="fa fa-chevron-down ms-1"></i>
                                                       
                                                        </a>
                                                </h5>
                                                
                                            </div>
                                            <div class="hurryBtn text-end">
                                                <button type="button" class="btn btn-outline-primary flsBookingBtn poppins-regular px-3 py-2 rounded-pill" onClick={() => nextStep(suggestion)}>Book Now <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M9 9L5.5 13L7.5 14.5L12 9L7.5 3.49999L5.5 4.99999L9 9Z" fill="#FF6433"></path>
                                                    </svg></button>
                                                <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel" aria-modal="true" role="dialog">
                                                    <div class="border-bottom offcanvas-header">
                                                        <h5 class="offcanvas-title poppins-bold" id="offcanvasRightLabel">Review Flight Details</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                                                    </div>
                                                    <div class="offcanvas-body">
                                                        {suggestion?.Inbound != null && <ul class="border-0 gap-2 ittr-sec-tab mb-3 nav nav-tabs" id="myTab" role="tablist">
                                                        
                                                            <li class="nav-item" role="presentation">
                                                                <button class="nav-link active" id="departure-sec-tab" data-bs-toggle="tab" data-bs-target="#departure-sec" type="button" role="tab" aria-controls="departure-sec" aria-selected="true">Departure Flight</button>
                                                            </li>
                                                            <li class="nav-item" role="presentation">
                                                                <button class="nav-link" id="return-sec-tab" data-bs-toggle="tab" data-bs-target="#return-sec" type="button" role="tab" aria-controls="return-sec" aria-selected="false" tabindex="-1">Return Flight</button>
                                                            </li>
                                                        </ul> }
                                                        {suggestion?.Inbound == null && <ul class="border-0 gap-2 ittr-sec-tab mb-3 nav nav-tabs" id="myTab" role="tablist">
                                                        
                                                            <li class="nav-item" role="presentation">
                                                                <button class="nav-link active" id="departure-sec-tab" data-bs-toggle="tab" data-bs-target="#departure-sec" type="button" role="tab" aria-controls="departure-sec" aria-selected="true">Departure Flight</button>
                                                            </li>
                                                            
                                                        </ul> }
                                                        <div class="tab-content" id="myTabContent">
                                                            <div class="tab-pane fade active show" id="departure-sec" role="tabpanel" aria-labelledby="departure-sec-tab">
                                                                <div class="flightDtlContent">
                                                                    <div class="border-bottom d-flex justify-content-between pb-2">
                                                                        <div class="dstiTxt">
                                                                            <h6 class="poppins-bold mb-0 text-start">{searchdata?.OriginCityName} - {searchdata?.DestinationCityName}<span class="orange-text"></span></h6>
                                                                        </div>
                                                                        <div class="bggeTxt">
                                                                            <ul class="alrghtDtl barlow-regular d-inline-flex fs-6 gap-3 list-unstyled mb-0 text-black-65">
                                                                                <li>{suggestion?.Outbound?.Stops} stop</li>
                                                                                <li>{formatFlightTime(suggestion?.Outbound?.TripDuration,1)}</li>
                                                                                <li> {totolTraver()} Traveler</li>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                    <div class="bg-white flight-box-mainwrq my-2">
                                                                        <div class="airlineBaggageDtl align-items-center d-flex justify-content-between mb-2">
                                                                            <div class="airCompany align-items-center d-flex pe-4">
                                                                                <img src={`${process.env.PUBLIC_URL}/assets/images/air01.png`} alt="air" class="rounded-circle" width="30" height="30" />
                                                                                <p class="airlineName poppins-semibold mb-0 ps-2 text-start">
                                                                                    IndiGo<br/>
                                                                                    <span class="fs-6 poppins-regular text-black-50">6E-5218</span>
                                                                                </p>
                                                                            </div>
                                                                            <div class="ite-date">
                                                                                <span class="mb-0 text-black-65 fs-6 poppins-regular">Tue, Apr 16</span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="row airbox-details align-items-center">
                                                                            <div class="col-3 col-sm-3 col-md-3 col-lg-3 col-xl-3 col-xxl-3 text-start pe-0">
                                                                                <h5 class="poppins-bold mb-0">06:05 AM</h5>
                                                                                <p class="mb-0">BOM - Mumbai</p>
                                                                            </div>
                                                                            <div class="col-6 col-sm-6 col-md-6 col-lg-6 col-xl-6 col-xxl-6">
                                                                                <div class="align-items-center border-left d-flex routeDtlSec w-100">
                                                                                    <div class="pe-3 routeOrigin text-end">
                                                                                        <h5 class="mb-0 pe-3 poppins-semibold timeLoc">
                                                                                            07:05
                                                                                            <span class="routeloc d-block fs-6 text-black-65">
                                                                                                LAX
                                                                                            </span>
                                                                                        </h5>
                                                                                    </div>
                                                                                    <div class="routPath w-50">
                                                                                        <span class="text-black-65">01h 16m</span>
                                                                                        <div class="routPathLine position-relative">
                                                                                        </div>
                                                                                        <ul class="alrghtDtl barlow-regular d-inline-flex fs-6 gap-3 list-unstyled mb-0 text-black-65">
                                                                                            <li class="px-0">AS-604</li>
                                                                                            <li class="px-0">Boeing 73H</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="ps-3 routeDest">
                                                                                        <h5 class="mb-0 poppins-semibold ps-3 timeLoc">
                                                                                            07:05
                                                                                            <span class="routeloc d-block fs-6 text-black-65">
                                                                                                LAX
                                                                                            </span>
                                                                                        </h5>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-3 col-lg-3 col-md-3 col-sm-3 col-xl-3 col-xxl-3 ps-0 text-start">
                                                                                <h5 class="poppins-bold mb-0">07:21 AM</h5>
                                                                                <p class="mb-0">DEL - New Delhi</p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="bg-light-orange cabiOtherDtl my-4 position-relative py-2 text-center">
                                                                        <ul class="baggageDtl d-inline-flex justify-content-around list-unstyled mb-0 w-100">
                                                                            <li>Baggage: <span class="text-black-50">Adult</span></li>
                                                                            <li>Check In: <span class="text-black-50">0 Kg</span></li>
                                                                            <li>Cabin: <span class="text-black-50">7 Kgs</span></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            {suggestion?.Inbound != null && <div class="tab-pane fade" id="return-sec" role="tabpanel" aria-labelledby="return-sec-tab">
                                                                <div class="flightDtlContent">
                                                                    <div class="border-bottom d-flex justify-content-between pb-2">
                                                                        <div class="dstiTxt">
                                                                            <h6 class="poppins-bold mb-0 text-start">Las Vegas - Los Angeles<span class="orange-text"></span></h6>
                                                                        </div>
                                                                        <div class="bggeTxt">
                                                                            <ul class="alrghtDtl barlow-regular d-inline-flex fs-6 gap-3 list-unstyled mb-0 text-black-65">
                                                                                <li>1 stop</li>
                                                                                <li>8h 50m</li>
                                                                                <li> 1 Traveler</li>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                    <div class="bg-white flight-box-mainwrq my-2">
                                                                        <div class="airlineBaggageDtl align-items-center d-flex justify-content-between mb-2">
                                                                            <div class="airCompany align-items-center d-flex pe-4">
                                                                                <img src={`${process.env.PUBLIC_URL}/assets/images/air01.png`} alt="air" class="rounded-circle" width="30" height="30" />
                                                                                <p class="airlineName poppins-semibold mb-0 ps-2 text-start">
                                                                                    IndiGo<br/>
                                                                                    <span class="fs-6 poppins-regular text-black-50">6E-5218</span>
                                                                                </p>
                                                                            </div>
                                                                            <div class="ite-date">
                                                                                <span class="mb-0 text-black-65 fs-6 poppins-regular">Tue, Apr 16</span></div>
                                                                        </div>
                                                                        <div class="row airbox-details align-items-center">
                                                                            <div class="col-3 col-sm-3 col-md-3 col-lg-3 col-xl-3 col-xxl-3 text-start pe-0">
                                                                                <h5 class="poppins-bold mb-0">06:05 AM</h5>
                                                                                <p class="mb-0">BOM - Mumbai</p>
                                                                            </div>
                                                                            <div class="col-6 col-sm-6 col-md-6 col-lg-6 col-xl-6 col-xxl-6">
                                                                                <div class="align-items-center border-left d-flex routeDtlSec w-100">
                                                                                    <div class="pe-3 routeOrigin text-end">
                                                                                        <h5 class="mb-0 pe-3 poppins-semibold timeLoc">
                                                                                            07:05
                                                                                            <span class="routeloc d-block fs-6 text-black-65">
                                                                                                LAX
                                                                                            </span>
                                                                                        </h5>
                                                                                    </div>
                                                                                    <div class="routPath w-50">
                                                                                        <span class="text-black-65">01h 16m</span>
                                                                                        <div class="routPathLine position-relative">
                                                                                        </div>
                                                                                        <ul class="alrghtDtl barlow-regular d-inline-flex fs-6 gap-3 list-unstyled mb-0 text-black-65">
                                                                                            <li class="px-0">AS-604</li>
                                                                                            <li class="px-0">Boeing 73H</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="ps-3 routeDest">
                                                                                        <h5 class="mb-0 poppins-semibold ps-3 timeLoc">
                                                                                            07:05
                                                                                            <span class="routeloc d-block fs-6 text-black-65">
                                                                                                LAX
                                                                                            </span>
                                                                                        </h5>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-3 col-lg-3 col-md-3 col-sm-3 col-xl-3 col-xxl-3 ps-0 text-start">
                                                                                <h5 class="poppins-bold mb-0">07:21 AM</h5>
                                                                                <p class="mb-0">DEL - New Delhi</p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="bg-light-orange cabiOtherDtl my-4 position-relative py-2 text-center">
                                                                        <ul class="baggageDtl d-inline-flex justify-content-around list-unstyled mb-0 w-100">
                                                                            <li>Baggage: <span class="text-black-50">Adult</span></li>
                                                                            <li>Check In: <span class="text-black-50">0 Kg</span></li>
                                                                            <li>Cabin: <span class="text-black-50">7 Kgs</span></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div> }
                                                        </div>
                                                        <h5 class="poppins-bold text-start">This itinerary includes a self-transfer</h5>
                                                        <p class="text-start">Our self-transfer hack helps you reach any destination by connecting separate flights. Since these flights are officially independent from one another, you might need to leave the transit zone:</p>
                                                        <ul class="fs-6 list-group-item-info pe-3 py-4 rounded-1 text-start">
                                                            <li class="mb-2">If you have&nbsp;<b>checked baggage</b>, you’ll need to collect it and recheck it</li>
                                                            <li class="mb-2">If you don’t have a <b>boarding pass for your next flight</b>, you’ll need to check in for that flight.</li>
                                                            <li class="mb-2">In some cases, you’ll need to go through <b>passport control</b> again as if you’d be entering the country, so you might need a&nbsp;visa.</li>
                                                            <li>Check the&nbsp;<b>airport terminal</b> for your next flight, as it might be different from the one you landed at.</li>
                                                        </ul>
                                                    </div>
                                                    <div class="bg-gray flightPriceDtl px-3 py-3">
                                                        <div class="align-items-center me-0 ms-0 row">
                                                            <div class="col-6 col-sm-6 col-md-6 col-lg-6 col-xl-6 col-xxl-6 ps-0 text-start">
                                                                <h3 class="mb-0 poppins-bold">$142.<sup>97</sup><span class="fs-6 poppins-regular-italic ps-2 text-black-50">Fare / person</span></h3>
                                                            </div>
                                                            <div class="col-6 col-sm-6 col-md-6 col-lg-6 col-xl-6 col-xxl-6 text-end pe-0"><a type="button" class="border-0 btn btn-primary flsBookingNowBtn px-4 py-2 rounded-pill text-uppercase text-white" onClick={() => nextStep(suggestion)}>Book Now</a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>  ))}
                            <div class="loadMoreSec text-center mt-4">
                                <a href="#" class="bg-gray btn btn-secondary px-4 rounded-pill text-black" role="button">Load More Flights</a>
                            </div>

                        </div> } 
                    </div>
                </div>
            </div>
        </div><PriceAlertModal isOpen={isModalOpen} onClose={closeModal} title="My Modal Title">
                
                </PriceAlertModal></div>} 
            </div>;
};

export default FlightRecords;
