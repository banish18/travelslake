// src/pages/Home.js
import {React,useState} from 'react';
import { Link } from 'react-router-dom';
const contactNumber = process.env.REACT_APP_DefaultContactNumber;
const supportEmail = process.env.REACT_APP_SupportEmail;

const Contact = () => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [contact, setContact] = useState('');
    const [message, setMessage] = useState('');
    const [emailerror, setEmailerror] = useState('');
    const [nameerror, setNameerror] = useState('');
    const [conatacterror, setContacterror] = useState('');
    const [messageerror, setMessageerror] = useState(false);
    const [submitted, setSubmitted] = useState(false);

    const validateEmail = (email) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        setEmailerror('');
        setNameerror('');
        setContacterror('');
        setMessageerror('');
        if ('' == name) {
            setNameerror('Please enter your name');
            setSubmitted(false);
        }else if (!validateEmail(email)) {
            setEmailerror('Please enter a valid email address');
            setSubmitted(false);
        }else if ('' == contact) {
            setContacterror('Please enter your contact number');
            setSubmitted(false);
        }else if ('' == message) {
            setMessageerror('Please enter your contact number');
            setSubmitted(false);
        } else {
            setEmailerror('');
            setNameerror('');
            setContacterror('');
            setMessageerror('');
            setSubmitted(true);
            console.log('Form submitted successfully:', email);
        }
        


    };

    return <div className="">
            <div className="heroSetion position-relative py-5">
            <div className="container">
              <div className="col-12 position-relative">
                        <h4 className="mb-2 poppins-bold text-center">Contact Us</h4>
                        <nav  aria-label="breadcrumb">
                            <ol className="breadcrumb justify-content-center mb-0">
                                <li className="breadcrumb-item"><Link className="" to="/">Home</Link></li>
                                <li className="breadcrumb-item active" aria-current="page">Contact Us</li>
                            </ol>
                        </nav>
                    </div>
            </div>
        </div><div className="getInTouchSec mb-5">
            <div className="container overflow-visible p-lg-5 p-md-3 rounded-4">
                <div className="row">
                    <div className="col">
                        <h4 className="karla-bold text-left mb-1 text-black karla-extrabold">Get In Touch</h4>
                        <p className="mb-3 text-black-65 karla-regular">Your email address will not be published. Required fields are marked *</p>
                    </div>
                </div>
                <div className="row">
                    <div className="col-md-7 pe-md-3">
                        <form onSubmit={handleSubmit} className="g-3 needs-validation needs-validation" id="contactusform" >
                            <div className="form-group">
                                <label className="visually-hidden" for="Name">Name*</label>
                                <input className="form-control  mb-3" data-val="true" data-val-regex=" " data-val-regex-pattern="^[a-zA-Z ]+$" data-val-required=" " id="Name" maxlength="50" name="Name" placeholder="Name*" type="text" value={name} onChange={(e) => setName(e.target.value)} fdprocessedid="ih170e" /> 
                                <span className="field-validation-valid" data-valmsg-for="Name" data-valmsg-replace="true"></span>
                            </div>
                            
                            {nameerror && <p style={{ color: 'red', marginBottom: '10px' }}>{nameerror}</p>}
                            
                            <div className="form-group">
                                <label className="visually-hidden" for="Email">Email</label>
                                <input className="form-control  mb-3" data-val="true" data-val-regex=" " data-val-regex-pattern="\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*" data-val-required=" " id="Email" maxlength="50" name="Email" placeholder="Email*" type="text" value={email} onChange={(e) => setEmail(e.target.value)} fdprocessedid="ghgcc5" />
                                <span className="field-validation-valid" data-valmsg-for="Email" data-valmsg-replace="true"></span>
                            </div>
                            {emailerror && <p style={{ color: 'red', marginBottom: '10px' }}>{emailerror}</p>}
                            <div className="form-group">
                                <label className="visually-hidden" for="ContactNumber">ContactNumber</label>
                                <input className="form-control  mb-3" data-val="true" data-val-regex=" " data-val-regex-pattern="\d{10}" data-val-required=" " id="ContactNumber" maxlength="10" name="ContactNumber" placeholder="Contact Number*" type="text" value={contact} onChange={(e) => setContact(e.target.value)} fdprocessedid="xnmc8" />
                                <span className="field-validation-valid" data-valmsg-for="ContactNumber" data-valmsg-replace="true"></span>
                            </div>
                            {conatacterror && <p style={{ color: 'red', marginBottom: '10px' }}>{conatacterror}</p>}
                            <div className="form-group">
                                <label className="visually-hidden" for="Message">Message</label>
                                <textarea className="form-control" data-val="true" data-val-required=" " id="Message" name="Message" placeholder="Your message here...*" rows="7" onChange={(e) => setMessage(e.target.value)}>{message}</textarea>
                                <span className="field-validation-valid" data-valmsg-for="Message" data-valmsg-replace="true"></span>
                            </div>
                           {messageerror && <p style={{ color: 'red', marginBottom: '10px' }}>{messageerror}</p>}
                            <button type="submit" onclick="return $(this).valid();" className="btn btn-primary d-flex me-0 ms-auto mt-4 px-3 py-2 rounded-pill text-uppercase" fdprocessedid="skvnis">Submit</button>

                            {submitted && <p style={{ color: 'green', marginBottom: '10px' }}>Email submitted successfully!</p>}  
                        </form>
                    </div>
                    <div className="col-md-5 px-lg-5 px-3">
                        <div className="align-items-center casBox d-flex mb-lg-0 mb-3">
                            <div className="align-items-center d-flex iconSec justify-content-center me-3 py-4 pe-3 rounded-circle">
                                <img src={`${process.env.PUBLIC_URL}/assets/images/location.png`} alt="icon" className="img-fluid" /> 
                            </div>
                            <div className="casTxt">
                                <h6 className="text-uppercase mb-2 karla-bold">Address:</h6>
                                <p className="mb-0 text-black-50 karla-semibold">119 Crabtree Ln, Milford, CT 06460</p>
                            </div>
                        </div>
                        <div className="align-items-center casBox d-flex mb-lg-0 mb-3">
                            <div className="align-items-center d-flex iconSec justify-content-center me-3 py-4 pe-3 rounded-circle">
                                <img src={`${process.env.PUBLIC_URL}/assets/images/call-calling.png`} alt="icon" className="img-fluid" />
                            </div>
                            <div className="casTxt">
                                <h6 className="text-uppercase karla-bold">Call us:</h6>
                                <a href="tel:{contactNumber}" className="bg-transparent karla-semibold text-green-100">{contactNumber}</a>
                            </div>
                        </div>
                        <div className="align-items-center casBox d-flex mb-lg-0 mb-3">
                            <div className="align-items-center d-flex iconSec justify-content-center me-3 py-4 pe-3 rounded-circle">
                                <img src={`${process.env.PUBLIC_URL}/assets/images/message.png`} alt="icon" className="img-fluid" />
                            </div>
                            <div className="casTxt">
                                <h6 className="text-uppercase karla-bold">Email:</h6>
                                <a href="mailto:{supportEmail}" className="bg-transparent karla-semibold text-green-100">{supportEmail}</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
            </div>;
};

export default Contact;
