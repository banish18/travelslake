// src/pages/Home.js
import {React,useState} from 'react';

const Newsletter = () => {
    const [email, setEmail] = useState('');
    const [error, setError] = useState('');
    const [terror, setTerror] = useState('');
    const [isChecked, setIsChecked] = useState(false);
    const [submitted, setSubmitted] = useState(false);

    const validateEmail = (email) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        if (!validateEmail(email)) {
            setError('Please enter a valid email address.');
            setSubmitted(false);
        }else if (!isChecked) {
            setTerror('You must agree to the terms and conditions.');
            setSubmitted(false);
        } else {
            setError('');
            setTerror('');
            setSubmitted(true);
            console.log('Form submitted successfully:', email);
        }
        


    };
    return <div className="container newsletterSignUpContainer mt-5">
                <div className="mb-5 newsletterSignUpSec px-4 rounded-4">
                    <div className="row">
                        <div className="col-lg-6">
                            <div className="align-items-center d-flex signUpTagline">
                                <div className="sutText">
                                    <p className="text-uppercase fs-6 mb-1 pt-4">Sign up to our Newsletter</p>
                                    <h5 className="poppins-bold">Get your free <span className="text-blue">real adventures</span> travel Newsletter</h5>
                                    <p className="mb-0 text-black fs-6 poppins-regular">Get your free travel newsletter full of travel ideas, destinations and adventuress. Discover new places to explore new adventures and new experiences.</p>
                                    <form className="newsletterSignForm mt-3" onSubmit={handleSubmit}>
                                        <div className="border input-group mb-2 p-1 rounded-pill bg-white">
                                            <input type="text" className="border-0 font-300 form-control p-1 ps-3 rounded-pill text-black" placeholder="Enter email ID" aria-label="Recipient's username" aria-describedby="button-addon2"  value={email} onChange={(e) => setEmail(e.target.value)} />

                                            



                                            <button className="btn btn-primary px-3 rounded-pill text-white" type="submit">Subscribe <svg className="ms-2" width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <g clipPath="url(#clip0_82_1055)">
                                                        <path d="M16.0744 3.64577L11.5744 15.2707C11.3813 15.7696 10.7431 15.9117 10.3566 15.542L7.82001 13.1157L6.26517 14.6705C6.02894 14.9068 5.62501 14.7394 5.62501 14.4054V11.0161L1.73157 7.29201C1.30653 6.88545 1.49356 6.17014 2.0632 6.02366L15.1882 2.64866C15.7792 2.49667 16.2947 3.07663 16.0744 3.64577ZM14.2501 4.50004L6.02375 9.86505L7.32534 11.11L14.2501 4.50004Z" fill="#FFF400" />
                                                    </g>
                                                    <defs>
                                                        <clipPath id="clip0_82_1055">
                                                            <rect width="18" height="18" fill="white" />
                                                        </clipPath>
                                                    </defs>
                                                </svg></button>
                                        </div>
                                         {error && <p style={{ color: 'red', marginBottom: '10px' }}>{error}</p>}
                                             
                                    </form>
                                    <div className="form-check d-flex ps-0 pb-4">
                                        <input className="form-check-input" type="checkbox" value="" id="flexCheckChecked" checked="" checked={isChecked}
                        onChange={(e) => setIsChecked(e.target.checked)} />
                                        <label className="form-check-label fs-6 barlow-regular" for="flexCheckChecked">
                                            I agree to receive offers according to conditions mentioned in our <a href="#" className="text-orange poppins-regular">Privacy Policy</a>.
                                        </label>
                                    </div>
                                    {terror && <p style={{ color: 'red', marginBottom: '10px' }}>{terror}</p>}
                                    {submitted && <p style={{ color: 'green', marginBottom: '10px' }}>Email submitted successfully!</p>}         
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-6 d-none d-lg-block">
                            <img src={`${process.env.PUBLIC_URL}/assets/images/traveler-with-map1.png`} alt="icon" className="img-fluid signEnvlop h-100" />
                        </div>
                    </div>
                </div>
            
        </div>;
};

export default Newsletter;
