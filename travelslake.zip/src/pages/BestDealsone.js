// src/pages/Home.js
import React,{useEffect,useState} from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Autoplay,Navigation, Pagination, Scrollbar, A11y } from 'swiper/modules';

import 'swiper/css';
import 'swiper/css/autoplay';

const BestDealsone = ({bestDeals}) => {
   // const [dealsdata, setDealsdata] = useState(bestDeals);
    const [returnDate, setReturnDate] = useState(null);
    const dealsdata = bestDeals;
    useEffect(() => {
        console.log(dealsdata)
    }, []);

    return <div className="bestDeals my-5">
            <div className="container">
                <div className="row">
                    <div className="col">
                        <h4 className="poppins-bold">Find Your Best Deals Here</h4>
                    </div>
                </div>
                {dealsdata?.length > 0 && ( 
                            <Swiper modules={[Navigation, Pagination, Scrollbar, Autoplay]} spaceBetween={20} slidesPerView={4} loop autoplay={{ delay: 2500 }}  >
                            {dealsdata?.map((destidata, index) => (
                                <SwiperSlide><div className="bg-transparent border-0 card text-bg-dark">
                                    <img src={`${process.env.PUBLIC_URL}/assets/images/d1.jpg`} className="card-img img-fluid rounded-4 border-0" alt="..." />
                                    <div className="card-img-overlay d-flex justify-content-between align-items-center">
                                        <div className="cioText">
                                            <p className="card-text mb-1 text-white">Tickets from $ {(destidata?.px).toFixed(2)}</p>
                                            <h6 className="card-title mb-0 d-flex"><span className="d-inline-block text-truncate">{destidata?.o}</span> <img src={`${process.env.PUBLIC_URL}/assets/images/itenWhite.png`} alt="" className="d-inline-block mx-2" /> <span className="d-inline-block text-truncate">{destidata?.d}</span></h6>
                                        </div>
                                        <a className="card-btn btn btn-light rounded-pill text-uppercase fs-6 poppins-semibold bg-white text-uppercase border-0 py-1" role="button" href="#">See details</a>
                                    </div>
                                </div></SwiperSlide>
                            ))}    
                        </Swiper>
                )}
               
            
            </div>
        </div>;
};

export default BestDealsone;
