// src/pages/Home.js
import {React,useState} from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';


const Featuresec = () => {
    

    return <div className="featureSec mb-5 pb-4">
            <div className="container">
                <div className="row">
                    <div className="col-lg-4 col-md-6 mb-md-0 mb-3">
                        <div className="fsBox px-2 py-3 bg-gray-light text-left d-flex align-items-center h-100">
                            <div className="fsBoxHoverIco" ><img src={`${process.env.PUBLIC_URL}/assets/images/ul.png`} alt="img" className="img-fluid" /></div>
                            <div className="fsBoxTxt ps-2">
                                <h6 className="poppins-bold text-black mb-2">Ultimate flexibility</h6>
                                <p className="mb-0 text-black-65 fs-6">You’re in control, with free cancellation
                                    and payment options to satisfy ay plan,</p>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4 col-md-6 mb-md-0 mb-3">
                        <div className="fsBox px-2 py-3 bg-gray-light text-left d-flex align-items-center h-100">
                            <div className="fsBoxHoverIco" ><img src={`${process.env.PUBLIC_URL}/assets/images/qa.png`} alt="img" className="img-fluid" /></div>
                            <div className="fsBoxTxt ps-2">
                                <h6 className="poppins-bold text-black mb-2">Quality Assured</h6>
                                <p className="mb-0 text-black-65 fs-6">Best quality service makes your travel experience hassle free.</p>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4 col-md-6 mb-md-0 mb-3">
                        <div className="fsBox px-2 py-3 bg-gray-light text-left d-flex align-items-center h-100">
                            <div className="fsBoxHoverIco" ><img src={`${process.env.PUBLIC_URL}/assets/images/kl.png`} alt="img" className="img-fluid" /></div>
                            <div className="fsBoxTxt ps-2">
                                <h6 className="poppins-bold text-black mb-2">24/7 Customer Support</h6>
                                <p className="mb-0 text-black-65 fs-6">Our human friendly support works 24/7 to provide you a great experience.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>;
};

export default Featuresec;
