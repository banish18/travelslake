// src/pages/Home.js
import {React,useState} from 'react';
import Search from './Search.js';
const Norecords = () => {
    

    return <div className="home">
                <Search ishowHeading={0} /><div class="container"><div class="row">
                        <div class="col-md-6 col-xl-7 ">
                            <div class=" no-result-list-left">
                                <h2 class="text-center text-md-start fs-4">Oops! Got No Results? No worries.</h2>
                                <p class="text-center text-md-start">We are unable to find flights that match your search criteria. Please try a new search for different airports or different dates.</p>
                                <h5 class="font-500">Search Help:</h5>
                                <ul>
                                    <li>Double-check your departure and destination airports for any typos.</li>
                                    <li>Try searching for different dates or a wider date range.</li>
                                    <li>Consider broadening your search with nearby airports or flexible travel dates.</li>
                                    <li>It’s possible that the flight you're looking for is not yet available. Check back later.</li>
                                    <li>For more assistance, feel free to contact our support team.</li>
                                </ul>
                                <p>Happy travels!</p>
                            </div>
                        </div>
                        <div class="col-md-6 col-xl-5">
                            
                        </div>
                    </div></div>
            </div>;
};

export default Norecords;
