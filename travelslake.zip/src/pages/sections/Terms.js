// src/pages/Home.js
import {React,useState} from 'react';

const Terms = () => {
    

    return <div className="container">
                <div className="termsCond">
                    <h5 className="rubik-semibold">Terms and Conditions</h5>
                    <p>When searching for airfares, discount and savings claims are based on multiple factors, including searching over 500 airlines to find our available fare. Coupon codes are valid for savings for qualified bookings off&nbsp;our service fees.</p>
                    <h6>Fare Disclosures</h6>
                    <p>* Unless otherwise noted, fares are roundtrip. Fares include all fuel surcharges,&nbsp;taxes &amp; fees&nbsp;and&nbsp;our service fees. Displayed fares are based on historical data, are subject to change. Tickets are nonrefundable, nontransferable, non-assignable and subject to airline restrictions. Name changes are not permitted. There is a higher probability of seats at the stated fare being available on Tuesday, Wednesday and Thursday, and it may require an advance purchase of up to 21 days and/or a Saturday night stay at the destination. Certain blackout dates may apply. Holidays and weekend travel may have a surcharge. See&nbsp;Terms and Conditions&nbsp;for other restrictions.</p>
                    <h6>Coupon Codes</h6>
                    <p>Expires Feb 29, 2024. Discount applies to service fees for qualified airline tickets, hotel, car rental bookings for destinations in the Western region (AZ, CO, ID, MT, NV, NM, UT, WY, AK, CA, HI, OR, WA) of the United States, Caribbean and Central America. Amount of service fee discount varies: for air bookings maximum savings of $5 per person applied to bookings from one (1) traveler up to three (3) travelers; the maximum discount applied is $15; for hotel bookings maximum savings of $12.99 applied on qualified purchases; for car rental bookings maximum savings of $8 applied on qualified bookings; for vacation package bookings maximum savings of $20 applied on qualified bookings. Promo Code and Instant Savings offers can be combined up to the amount of our service fees but cannot be used or combined with any other coupons, promotions or special offers. May be withdrawn at any time without notice. No cash value, void where prohibited.</p>
                    <h6>Seller of Travel</h6>
                    <p>The CheapOair Visa card is issued by Synchrony Bank pursuant to a license from Visa USA Inc.</p>
                </div>
                <div className="footer mt-5 rounded-4">
                    <div className="align-items-center row">
                        <div className="col-lg-5">
                            <a className="navbar-brand" href="#"><img src="assets/images/logo-header.png" alt="logo" /></a>
                            <p className="my-4">travelslake is a registered affiliate DBA of SAVI WORLD TRAVELS LLC in the state of Connecticut. We adhere to, by all means, the operational standards mentioned in the ARC Verified Travel Consultant agreement. Our Operations Centres are open 24 hours Monday through Sunday. Travelslake being a DBA is authorized to use the ARC# 07619743 of SAVI WORLD TRAVELS LLC.</p>
                            <ul className="d-flex gap-4 list-unstyled mb-0 socialIcons">
                                <li><a href="#"><i className="lab la-twitter"></i></a></li>
                                <li><a href="#"><i className="lab la-facebook-f"></i></a></li>
                                <li><a href="#"><i className="lab la-linkedin-in"></i></a></li>
                                <li><a href="#"><i className="lab la-instagram"></i></a></li>
                            </ul>
                        </div>
                        <div className="col-lg-7">
                            <div className="footerLinks">
                                <h6 className="poppins-semibold linkTitle text-uppercase text-black">Legal</h6>
                                <ul className="list-unstyled mainLinks mb-0">
                                    <li><a href="#">About Us</a></li>
                                    <li><a href="#">Cancellation and Refund
                                        </a></li>
                                    <li><a href="#">Disclaimer
                                        </a></li>
                                    <li><a href="#">Privacy Policy
                                        </a></li>
                                    <li><a href="#">Terms and Conditions</a></li>
                                </ul>
                                <h6 className="poppins-semibold linkTitle text-uppercase text-black">Top Airlines</h6>
                                <ul className="list-unstyled mainLinks mb-0">
                                    <li><a href="#">Air Serbia
                                        </a></li>
                                    <li><a href="#">Ita Airlines
                                        </a></li>
                                    <li><a href="#">Neosair
                                        </a></li>
                                    <li><a href="#">Sky Express</a></li>
                                    <li><a href="#">Viva Airlines</a></li>
                                </ul>
                                <h6 className="poppins-semibold linkTitle text-uppercase text-black">Top Destinations</h6>
                                <ul className="list-unstyled mainLinks mb-0">
                                    <li><a href="#">Rio</a></li>
                                    <li><a href="#">Tokyo
                                        </a></li>
                                    <li><a href="#">Vancouver
                                        </a></li>
                                    <li><a href="#">New York
                                        </a></li>
                                    <li><a href="#">San Francisco</a></li>
                                </ul>
                                <h6 className="poppins-semibold linkTitle text-uppercase text-black">Extras</h6>
                                <ul className="list-unstyled mainLinks mb-0">
                                    <li><a href="#">Airport Codes</a></li>
                                    <li><a href="#">FAQ
                                        </a></li>
                                    <li><a href="#">Cookie Policy
                                        </a></li>
                                    <li><a href="#">Travel Documents
                                        </a></li>
                                    <li><a href="#">Visa Information</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>;
};

export default Terms;
