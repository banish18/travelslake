// src/pages/Home.js
import {React,useState} from 'react';

const BookingDetails = () => {
    

    return <div class="col-lg-3">
                        <div class="shadow border-0 rounded-4 tripFareSmry">
                            <div class="border border-light card tripSmry w-auto mb-3">
                                <div class="bg-light-orange card-header position-relative py-4 text-center">
                                    <div class="align-items-center d-flex iteTitle justify-content-center mb-2">
                                        <h2 class="poppins-bold mb-0 text-black text-uppercase">LAS</h2>
                                        <span class="iconIte px-2"><button type="button" class="align-items-center bg-gray-light bg-white border-0 btn btn-primary d-flex itenerary-btn justify-content-center p-1 rounded-pill"><img src={`${process.env.PUBLIC_URL}/assets/images/itesectinicon.png`} alt="icon" class="img-fluid" /></button></span>
                                        <h2 class="poppins-bold mb-0 text-black text-uppercase">LAX</h2>
                                    </div>
                                    <ul class="alrghtDtl barlow-regular d-inline-flex fs-6 gap-0 list-unstyled mb-0 text-black-65">
                                        <li>1 stop</li>
                                        <li>8h 50m</li>
                                        <li> 1 Traveler</li>
                                    </ul>
                                    <button class="bg-transparent border-0 infoBtn text-secondary" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight"><i class="fa-solid fa-circle-info text-orange" aria-hidden="true"></i></button>
                                                <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel" aria-modal="true" role="dialog">
                                                    <div class="border-bottom offcanvas-header">
                                                        <h5 class="offcanvas-title poppins-bold" id="offcanvasRightLabel">Review Flight Details</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                                                    </div>
                                                    <div class="offcanvas-body">
                                                        <ul class="border-0 gap-2 ittr-sec-tab mb-3 nav nav-tabs" id="myTab" role="tablist">
                                                            <li class="nav-item" role="presentation">
                                                                <button class="nav-link active" id="departure-sec-tab" data-bs-toggle="tab" data-bs-target="#departure-sec" type="button" role="tab" aria-controls="departure-sec" aria-selected="true">Departure Flight</button>
                                                            </li>
                                                            <li class="nav-item" role="presentation">
                                                                <button class="nav-link" id="return-sec-tab" data-bs-toggle="tab" data-bs-target="#return-sec" type="button" role="tab" aria-controls="return-sec" aria-selected="false" tabindex="-1">Return Flight</button>
                                                            </li>
                                                        </ul>
                                                        <div class="tab-content" id="myTabContent">
                                                            <div class="tab-pane fade active show" id="departure-sec" role="tabpanel" aria-labelledby="departure-sec-tab">
                                                                <div class="flightDtlContent">
                                                                    <div class="border-bottom d-flex justify-content-between pb-2">
                                                                        <div class="dstiTxt">
                                                                            <h6 class="poppins-bold mb-0 text-start">Los Angeles - Las Vegas<span class="orange-text"></span></h6>
                                                                        </div>
                                                                        <div class="bggeTxt">
                                                                            <ul class="alrghtDtl barlow-regular d-inline-flex fs-6 gap-3 list-unstyled mb-0 text-black-65">
                                                                                <li>1 stop</li>
                                                                                <li>8h 50m</li>
                                                                                <li> 1 Traveler</li>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                    <div class="bg-white flight-box-mainwrq my-2">
                                                                        <div class="airlineBaggageDtl align-items-center d-flex justify-content-between mb-2">
                                                                            <div class="airCompany align-items-center d-flex pe-4">
                                                                                <img src={`${process.env.PUBLIC_URL}/assets/images/air01.png`} alt="air" class="rounded-circle" width="30" height="30" />
                                                                                <p class="airlineName poppins-semibold mb-0 ps-2 text-start">
                                                                                    IndiGo<br />
                                                                                    <span class="fs-6 poppins-regular text-black-50">6E-5218</span>
                                                                                </p>
                                                                            </div>
                                                                            <div class="ite-date">
                                                                                <span class="mb-0 text-black-65 fs-6 poppins-regular">Tue, Apr 16</span></div>
                                                                        </div>
                                                                        <div class="row airbox-details align-items-center">
                                                                            <div class="col-3 col-sm-3 col-md-3 col-lg-3 col-xl-3 col-xxl-3 text-start pe-0">
                                                                                <h5 class="poppins-bold mb-0">06:05 AM</h5>
                                                                                <p class="mb-0">BOM - Mumbai</p>
                                                                            </div>
                                                                            <div class="col-6 col-sm-6 col-md-6 col-lg-6 col-xl-6 col-xxl-6">
                                                                                <div class="align-items-center border-left d-flex routeDtlSec w-100">
                                                                                    <div class="pe-3 routeOrigin text-end">
                                                                                        <h5 class="mb-0 pe-3 poppins-semibold timeLoc">
                                                                                            07:05
                                                                                            <span class="routeloc d-block fs-6 text-black-65">
                                                                                                LAX
                                                                                            </span>
                                                                                        </h5>
                                                                                    </div>
                                                                                    <div class="routPath w-50">
                                                                                        <span class="text-black-65">01h 16m</span>
                                                                                        <div class="routPathLine position-relative">
                                                                                        </div>
                                                                                        <ul class="alrghtDtl barlow-regular d-inline-flex fs-6 gap-3 list-unstyled mb-0 text-black-65">
                                                                                            <li class="px-0">AS-604</li>
                                                                                            <li class="px-0">Boeing 73H</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="ps-3 routeDest">
                                                                                        <h5 class="mb-0 poppins-semibold ps-3 timeLoc">
                                                                                            07:05
                                                                                            <span class="routeloc d-block fs-6 text-black-65">
                                                                                                LAX
                                                                                            </span>
                                                                                        </h5>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-3 col-lg-3 col-md-3 col-sm-3 col-xl-3 col-xxl-3 ps-0 text-start">
                                                                                <h5 class="poppins-bold mb-0">07:21 AM</h5>
                                                                                <p class="mb-0">DEL - New Delhi</p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="bg-light-orange cabiOtherDtl my-4 position-relative py-2 text-center">
                                                                        <ul class="baggageDtl d-inline-flex justify-content-around list-unstyled mb-0 w-100">
                                                                            <li>Baggage: <span class="text-black-50">Adult</span></li>
                                                                            <li>Check In: <span class="text-black-50">0 Kg</span></li>
                                                                            <li>Cabin: <span class="text-black-50">7 Kgs</span></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="tab-pane fade" id="return-sec" role="tabpanel" aria-labelledby="return-sec-tab">
                                                                <div class="flightDtlContent">
                                                                    <div class="border-bottom d-flex justify-content-between pb-2">
                                                                        <div class="dstiTxt">
                                                                            <h6 class="poppins-bold mb-0 text-start">Las Vegas - Los Angeles<span class="orange-text"></span></h6>
                                                                        </div>
                                                                        <div class="bggeTxt">
                                                                            <ul class="alrghtDtl barlow-regular d-inline-flex fs-6 gap-3 list-unstyled mb-0 text-black-65">
                                                                                <li>1 stop</li>
                                                                                <li>8h 50m</li>
                                                                                <li> 1 Traveler</li>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                    <div class="bg-white flight-box-mainwrq my-2">
                                                                        <div class="airlineBaggageDtl align-items-center d-flex justify-content-between mb-2">
                                                                            <div class="airCompany align-items-center d-flex pe-4">
                                                                                <img src={`${process.env.PUBLIC_URL}/assets/images/air01.png`} alt="air" class="rounded-circle" width="30" height="30" />
                                                                                <p class="airlineName poppins-semibold mb-0 ps-2 text-start">
                                                                                    IndiGo<br />
                                                                                    <span class="fs-6 poppins-regular text-black-50">6E-5218</span>
                                                                                </p>
                                                                            </div>
                                                                            <div class="ite-date">
                                                                                <span class="mb-0 text-black-65 fs-6 poppins-regular">Tue, Apr 16</span></div>
                                                                        </div>
                                                                        <div class="row airbox-details align-items-center">
                                                                            <div class="col-3 col-sm-3 col-md-3 col-lg-3 col-xl-3 col-xxl-3 text-start pe-0">
                                                                                <h5 class="poppins-bold mb-0">06:05 AM</h5>
                                                                                <p class="mb-0">BOM - Mumbai</p>
                                                                            </div>
                                                                            <div class="col-6 col-sm-6 col-md-6 col-lg-6 col-xl-6 col-xxl-6">
                                                                                <div class="align-items-center border-left d-flex routeDtlSec w-100">
                                                                                    <div class="pe-3 routeOrigin text-end">
                                                                                        <h5 class="mb-0 pe-3 poppins-semibold timeLoc">
                                                                                            07:05
                                                                                            <span class="routeloc d-block fs-6 text-black-65">
                                                                                                LAX
                                                                                            </span>
                                                                                        </h5>
                                                                                    </div>
                                                                                    <div class="routPath w-50">
                                                                                        <span class="text-black-65">01h 16m</span>
                                                                                        <div class="routPathLine position-relative">
                                                                                        </div>
                                                                                        <ul class="alrghtDtl barlow-regular d-inline-flex fs-6 gap-3 list-unstyled mb-0 text-black-65">
                                                                                            <li class="px-0">AS-604</li>
                                                                                            <li class="px-0">Boeing 73H</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="ps-3 routeDest">
                                                                                        <h5 class="mb-0 poppins-semibold ps-3 timeLoc">
                                                                                            07:05
                                                                                            <span class="routeloc d-block fs-6 text-black-65">
                                                                                                LAX
                                                                                            </span>
                                                                                        </h5>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-3 col-lg-3 col-md-3 col-sm-3 col-xl-3 col-xxl-3 ps-0 text-start">
                                                                                <h5 class="poppins-bold mb-0">07:21 AM</h5>
                                                                                <p class="mb-0">DEL - New Delhi</p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="bg-light-orange cabiOtherDtl my-4 position-relative py-2 text-center">
                                                                        <ul class="baggageDtl d-inline-flex justify-content-around list-unstyled mb-0 w-100">
                                                                            <li>Baggage: <span class="text-black-50">Adult</span></li>
                                                                            <li>Check In: <span class="text-black-50">0 Kg</span></li>
                                                                            <li>Cabin: <span class="text-black-50">7 Kgs</span></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <h5 class="poppins-bold text-start">This itinerary includes a self-transfer</h5>
                                                        <p class="text-start">Our self-transfer hack helps you reach any destination by connecting separate flights. Since these flights are officially independent from one another, you might need to leave the transit zone:</p>
                                                        <ul class="fs-6 list-group-item-info pe-3 py-4 rounded-1 text-start">
                                                            <li class="mb-2">If you have&nbsp;<b>checked baggage</b>, you’ll need to collect it and recheck it</li>
                                                            <li class="mb-2">If you don’t have a <b>boarding pass for your next flight</b>, you’ll need to check in for that flight.</li>
                                                            <li class="mb-2">In some cases, you’ll need to go through <b>passport control</b> again as if you’d be entering the country, so you might need a&nbsp;visa.</li>
                                                            <li>Check the&nbsp;<b>airport terminal</b> for your next flight, as it might be different from the one you landed at.</li>
                                                        </ul>
                                                    </div>
                                                    <div class="bg-gray flightPriceDtl px-3 py-3">
                                                        <div class="align-items-center me-0 ms-0 row">
                                                            <div class="col-6 col-sm-6 col-md-6 col-lg-6 col-xl-6 col-xxl-6 ps-0 text-start">
                                                                <h3 class="mb-0 poppins-bold">$142.<sup>97</sup><span class="fs-6 poppins-regular-italic ps-2 text-black-50">Fare / person</span></h3>
                                                            </div>
                                                            <div class="col-6 col-sm-6 col-md-6 col-lg-6 col-xl-6 col-xxl-6 text-end pe-0"><a type="button" class="border-0 btn btn-primary flsBookingNowBtn px-4 py-2 rounded-pill text-uppercase text-white" href="#">Book Now</a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                </div>
                                <div class="card-body">
                                    <div class="departSec">
                                        <h6 class="poppins-semibold"><img src={`${process.env.PUBLIC_URL}/assets/images/take-off.png`} alt="img" class="img-fluid me-2" />Mon, 02/12</h6>
                                        <table class="table mb-0">
                                            <tbody>
                                                <tr>
                                                    <td class="border-0 px-0">Las Vegas&nbsp;(LAS)</td>
                                                    <th class="border-0 px-0" scope="row">08:55 PM</th>
                                                </tr>
                                                <tr>
                                                    <td class="border-0 px-0">Los Angeles (LAX)</td>
                                                    <th class="border-0 px-0" scope="row">10:05 PM</th>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="returnSec border-top pt-3">
                                        <h6 class="poppins-semibold"><img src={`${process.env.PUBLIC_URL}/assets/images/landing.png`} alt="img" class="img-fluid" /> Thu, Aug 22</h6>
                                        <table class="table mb-0">
                                            <tbody>
                                                <tr>
                                                    <td class="border-0 px-0">Las Vegas&nbsp;(LAS)</td>
                                                    <th class="border-0 px-0" scope="row">08:55 PM</th>
                                                </tr>
                                                <tr>
                                                    <td class="border-0 px-0">Los Angeles (LAX)</td>
                                                    <th class="border-0 px-0" scope="row">10:05 PM</th>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="border-light fareSmry w-auto">
                                        <div class="bg-light-orange mb-2 mt-3 position-relative py-2 rounded-0 text-center">
                                            <h6 class="fs-6 mb-0 poppins-bold text-uppercase">Summary of Charges</h6>
                                        </div>
                                        <div class="chargesSumry">
                                            <table class="table mb-0">
                                                <tbody>
                                                    <tr>
                                                        <td class="border-0 px-0">Adult (1 X $512.96)</td>
                                                        <th class="border-0 px-0" scope="row">$512.<sup>96</sup></th>
                                                    </tr>
                                                    <tr>
                                                        <td class="border-0 px-0">Lap Infant</td>
                                                        <th class="border-0 px-0" scope="row">$59<sup>96</sup></th>
                                                    </tr>
                                                    <tr>
                                                        <td class="border-0 px-0">Child</td>
                                                        <th class="border-0 px-0" scope="row">$12<sup>96</sup></th>
                                                    </tr>
                                                    <tr>
                                                        <td class="border-0 border-top poppins-bold pt-2 px-0 text-black">Total Price (USD)</td>
                                                        <th class="border-0 border-top poppins-extrabold pt-2 px-0 text-secondary" scope="row">$522<sup>96</sup></th>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>;
};

export default BookingDetails;
