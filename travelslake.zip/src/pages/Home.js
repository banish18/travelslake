// src/pages/Home.js
import React,{useEffect,useState} from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import Search from './Search.js';
import { getHomepagedata } from '../services';
import BestDealsone from './BestDealsone.js';
import PopularDealssec from './PopularDealssec.js';
import Newsletter from './Newsletter.js';
import Featuresec from './Featuresec.js';
import Terms from './sections/Terms.js'
const PopularDestination = process.env.REACT_APP_PopularDestination;
const PopularAirlines = process.env.REACT_APP_PopularAirlines;

const Home = () => {

    const [deals, setDeals] = useState([]);
    const [popularairlines, setPopularairlines] = useState([]);
    const [error, setError] = useState("");

    useEffect(() => {
        getDeals()
    }, []);

    const getDeals = async () => {
        var popDes = PopularDestination.split(',');
        var popAir = PopularAirlines.split(',');

        const getDealsArr = {'Airlines':popAir,"Airports":popDes}

       getHomepagedata(getDealsArr).then(res => {
        setDeals(res.data?.Model?.PopularDestinationsDeals);
        setPopularairlines(res.data?.Model?.PopularAirlinesDeals);
        console.log(res.data?.Model?.PopularAirlinesDeals);

      }).catch(err => {
        console.error("Error fetching data:", err);
      });
       // console.log(getHomepagedata());
       // const dealsrecords = getHomepagedata();
       // setDeals(dealsrecords?.PopularDestinationsDeals);
        //setPopularairlines(dealsrecords?.PopularAirlinesDeals);
    }
    
    return <div className="home">
            <Search ishowHeading={1}/>
            <BestDealsone bestDeals={deals} />
            <Featuresec />    
            <PopularDealssec airlines={popularairlines}/>    
            <Newsletter />    
            <Terms />
            </div>;
};

export default Home;
