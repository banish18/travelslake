import React,{useState} from "react";

const PriceAlertModal = ({ isOpen, onClose, title, children }) => {
    const [email, setEmail] = useState('');
    const [error, setError] = useState('');
    const [submitted, setSubmitted] = useState(false);
    const [emailalert, setEmailalert] = useState(false);
    if (!isOpen) return null;
    

    const validateEmail = (email) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        if (!validateEmail(email)) {
            setError('Please enter a valid email address.');
            setSubmitted(false);
        } else {
            setError('');
            
            setSubmitted(true);
            console.log('Form submitted successfully:', email);
        }
        


    };

    const handelChange = () => {
        setEmailalert(!emailalert);
    }

    return (
        <div class="modal" id="fareAlertModal" tabindex="-1" style={{display : "block"}} aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="border-0 modal-header p-0">
                            <div class="bg-blue-200 modalHdrSec pt-4 px-3 rounded-top text-center w-100">
                                <div class="mb-2 mhsTxt">
                                    <h3 class="mb-1 poppins-bold text-primary">Price Alerts!</h3>
                                </div>
                                <img src={`${process.env.PUBLIC_URL}/assets/images/price-alert.gif`} alt="icon" class="img-fluid timerGif" width="
                                100" />
                            </div><button onClick={onClose} type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body p-0 p-4 rounded text-center">
                            <div class="align-items-center d-flex iteneraryCity justify-content-center mb-2 mx-auto p-0">
                                <div class="departureCity">
                                    <h3 class="mb-0">BOM</h3>
                                    <h6>Mumbai</h6>
                                    <p>Fri, May 31</p>
                                </div>
                                <div class="align-items-center bg-gray d-flex flighIconPopup justify-content-center mx-5 rounded-circle"><img src={`${process.env.PUBLIC_URL}/assets/images/take-off.png`} alt="icon" class="img-fluid" /></div>
                                <div class="arivalCity">
                                    <h3 class="mb-0">HYD</h3>
                                    <h6>Hyderabad</h6>
                                    <p>Sat, Jun 15</p>
                                </div>
                            </div>
                            <div class="input-group my-3">
                                <form onSubmit={handleSubmit} className="form-control mt-3">
                                <input type="email" class="bg-light border form-control rounded w-100" id="email" placeholder="Enter email" value={email} onChange={(e) => setEmail(e.target.value)} />
                                {error && <p style={{ color: 'red', marginBottom: '10px' }}>{error}</p>}
                                <button class="border-0 btn btn-primary fareAlertBtn mt-3 p-2 poppins-bold rounded text-white w-100"  type="submit">Get Fare Alerts!</button>
                                {submitted && <p style={{ color: 'green', marginBottom: '10px' }}>Email submitted successfully!</p>}  
                                </form>
                            </div>
                            <div class="d-flex form-check mb-2 ps-0">
                                <input class="form-check-input" type="checkbox" value={emailalert} id="flexCheckDefault" checked={(emailalert && 'checked' : '')} onChange={handelChange} />
                                <label class="form-check-label text-start" for="flexCheckChecked">
                                    Email me TravelSlake’s favourite deals.
                                </label>
                            </div>
                            <p class="mb-0 text-start">By entering your email address you agree to TravelSlake's <a href="#" class="text-red">Terms and Conditions</a>, <a href="#" class="text-red">Privacy Policy</a> and to receive email marketing.</p>
                        </div>
                    </div>
                </div>
            </div>
    );
};

export default PriceAlertModal;