// src/pages/Home.js
import {React,useState} from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Autoplay,Navigation, Pagination, Scrollbar, A11y } from 'swiper/modules';
import { format,parseISO } from 'date-fns';
import 'swiper/css';
import 'swiper/css/autoplay';


const PopularDealssec = ({airlines}) => {
     const createLenth = (ln) => {
        let arr = [];
        for (var i = 0; i < ln; i++) {
             arr.push(i)
        }
        return arr;
    }
    const [usedlength,setUsedlength] = useState(0)
    const [udpatedair,setUpdatedair] = useState(0)
    const totalLength = createLenth(Math.ceil(airlines?.length / 3));
   
    const getAfterdec = (n) => {
        console.log();
         const nn = Math.abs(n); // Change to positive
         const fd = nn - Math.floor(n);
         const finalval = fd.toFixed(2).split('.')
         return '.'+finalval[1];
    }

    const airDiffData = (index) => {
        const data = airlines.slice(index*3, 3+index*3);
       
        return data;
    }

   

   
  
   
    return <div className="popularDealsSlideSec">
            <div className="container">
                <div className="row">
                    <div className="col">
                        <h4 className="poppins-bold">Find Your Best Deals Here</h4>
                    </div>
                </div>
                 {airlines?.length > 0 && ( 
                                        <Swiper modules={[Navigation, Pagination, Scrollbar, Autoplay]} spaceBetween={20} slidesPerView={2}  autoplay={{ delay: 2500,waitForTransition:true }} loop  >
                    {totalLength?.map((x, i) => (                    
                        <SwiperSlide>
                        {airDiffData(i)?.map((airdata, index) => (   
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="dealBoxWrapper">
                                    <a href="#" class="text-decoration-none">
                                        <div class="align-items-center border justify-content-between d-flex dealBox mt-3 p-2 rounded-pill">
                                            <div class="dealDtl d-flex align-items-center">
                                                <div class="planeDtl d-flex align-items-center">
                                                    <img src={`${process.env.PUBLIC_URL}/assets/images/aircompnylog.png`} alt="" class="rounded-circle border-light border" width="42" height="42" />
                                                    <p class="mb-0 poppins-semibold px-2 text-black text-truncate d-inline-block">{airdata?.originDetails.CityName}</p>
                                                </div>
                                                <div class="itenerary-dtl px-3 border-left">
                                                    <p class="mb-0 text-black fs-6">{format(parseISO(airdata?.i_on), "LLL-yy")}- {format(parseISO(airdata?.fd), "LLL-yy")} </p>
                                                    <h5 class="mb-0 poppins-semibold text-black">{airdata?.o} <img src={`${process.env.PUBLIC_URL}/assets/images/iiteIco.png`} alt="icon" class="img-fluid w-auto d-inline-block" /> {airdata?.d}</h5>
                                                </div>
                                            </div>
                                            <div class="ittePrice ps-2">
                                                <h5 class="text-orange mb-0">${Math.floor(airdata?.px)}<sup>{getAfterdec(airdata?.px)}</sup></h5>
                                            </div>
                                            <button class="book-btn btn btn-outline-primary fs-6 rounded-pill text-uppercase" role="button" href="#">Book Now</button>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            </div>
                            ))}
                        </SwiperSlide>
                    ))}
                </Swiper>
                )}
                </div></div>;
};

export default PopularDealssec;
