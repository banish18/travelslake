// src/App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './pages/Home';
import About from './pages/About';
import Contact from './pages/Contact';
import FlightRecords from './pages/FlightRecords';
import Contactinfo from './pages/Contactinfo';
import Bookingoptions from './pages/Bookingoptions';
import Paymentdetails from './pages/Paymentdetails';
import BookingConfirmation from './pages/BookingConfirmation';
import FlightSearch from './pages/FlightSearch';
import Norecords from './pages/Norecords';

function App() {
    return (
        <Router>
            <Header />
            <main>
                <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/about" element={<About />} />
                    <Route path="/contact" element={<Contact />} />
                    <Route path="/flights" element={<FlightRecords />} />
                    <Route path="/flightsearch" element={<FlightSearch />} />
                    <Route path="/contact-info" element={<Contactinfo />} />
                    <Route path="/booking-options" element={<Bookingoptions />} />
                    <Route path="/payment-detail" element={<Paymentdetails />} />
                    <Route path="/confirmation" element={<BookingConfirmation />} />
                    <Route path="/no-records" element={<Norecords />} />
                </Routes>
            </main>
            <Footer />
        </Router>
    );
}

export default App;
