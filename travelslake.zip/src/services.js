import axios from "axios"
import instance from './httpService';

const Apiurl    = process.env.REACT_APP_APIUrl;
const swsApiurl = process.env.REACT_APP_CWSAPIURL;


/* Get search field autocomplete flight records */


export const getSeatchrecords = (query) => {
    return axios({
        url: swsApiurl+`/airports?q=${query}`,
        method: 'get',
    headers: {
        "Content-Type": "application/json",
    }
 });


}
/* Get countries list */
export const getCountries = (query) => {
    return axios({
        url: swsApiurl+`/countrylist`,
        method: 'get',
    headers: {
        "Content-Type": "application/json",
    }
 });


}

/* Get countries list */
export const getStatesdata = (countrycode) => {
    return axios({
        url: swsApiurl+`/statebycountry?cc=${countrycode}`,
        method: 'get',
    headers: {
        "Content-Type": "application/json",
    }
 });


}


/* Get Homepage data , deals etc */

export const getHomepagedata = (getDealsArr) => {
    
    const data = instance({
        // url of the api endpoint (can be changed)
        url: "api/commoncontent/",
        method: "POST",
        data: getDealsArr,
      });

    return data;



}

/* Get Flight Token from data */

export const getFlighttoken = (data) => {
    return axios({
    url: Apiurl+'flightsearch/web?'+data,
    method: 'get',
    headers: {
        "Content-Type": "application/json",
    },
 })

}

/* Get Flight Token from data */

export const getFlightRecords = (token) => {
     const data = instance({
        // url of the api endpoint (can be changed)
         url: '/flight/fetch/?xSId='+token,
        method: "POST"
      });

     return data;

}

/*format time 01h 16m */
export const formatFlightTime = (tm,evall) => {
    if(evall == 1){
        const timvalue = tm.match(/.{1,2}/g);
        return timvalue[0]+'hr '+timvalue[1]+'m';
    }else{
        const timvalue = tm.match(/.{1,2}/g);
        return convertTo12HourFormat(timvalue[0]+':'+timvalue[1]);
    }

}


const convertTo12HourFormat = (time) => {
    const [hours, minutes] = time.split(":");
    const date = new Date();
    date.setHours(hours);
    date.setMinutes(minutes);
    return date.toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    });
  };
