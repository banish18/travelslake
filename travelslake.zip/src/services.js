import axios from "axios"

const Apiurl    = process.env.REACT_APP_APIUrl;
const swsApiurl = process.env.REACT_APP_CWSAPIURL;

export const getSeatchrecords = (query) => {
    return axios({
        url: swsApiurl+`/airports?q=${query}`,
        method: 'get',
    headers: {
        "Content-Type": "application/json",
    }
 });


}



export const getHomepagedata = (getDealsArr) => {
    return axios({
    url: '/commoncontent/',
    method: 'post',
    data:getDealsArr,
    headers: {
        "Content-Type": "application/json",
    },
 })

}

// export const getHomepagedata = () => {
//     const data = {"PopularAirlinesDeals": [
//             {
//                 "Id": "6734b1ff5c7a78e2c8bd351b",
//                 "o": "LAS",
//                 "originDetails": {
//                     "ID": 1117,
//                     "AirportCode": "LAS",
//                     "CityCode": "LAS",
//                     "CityName": "Las Vegas",
//                     "AirportName": "Las Vegas All Airports",
//                     "StateCode": "NV",
//                     "StateName": "Nevada",
//                     "CountryCode": "US",
//                     "CountryName": "United States",
//                     "AutoSuggest": null,
//                     "Text": "LAS - Las Vegas All Airports, Nevada, United States",
//                     "Type": "City",
//                     "IATACode": null,
//                     "Distance": "",
//                     "Latitude": "36.086945",
//                     "Longitude": "-115.1486",
//                     "SubType": "",
//                     "SubText": "",
//                     "MisspellMatchWord": "a",
//                     "Timezone": "-8",
//                     "Airports": "LAS,LSV,VGT",
//                     "ChiledAirportCodes": [
//                         "LAS",
//                         "LSV",
//                         "VGT"
//                     ],
//                     "ParentID": null
//                 },
//                 "d": "LAX",
//                 "destinationDetails": {
//                     "ID": 1874,
//                     "AirportCode": "LAX",
//                     "CityCode": "LAX",
//                     "CityName": "Los Angeles",
//                     "AirportName": "Los Angeles",
//                     "StateCode": "CA",
//                     "StateName": "California",
//                     "CountryCode": "US",
//                     "CountryName": "United States",
//                     "AutoSuggest": null,
//                     "Text": "LAX - Los Angeles, California, United States",
//                     "Type": "Airport",
//                     "IATACode": null,
//                     "Distance": "",
//                     "Latitude": "33.943398",
//                     "Longitude": "-118.40828",
//                     "SubType": "",
//                     "SubText": "",
//                     "MisspellMatchWord": "a",
//                     "Timezone": "-8",
//                     "Airports": "LAX",
//                     "ChiledAirportCodes": [
//                         "LAX"
//                     ],
//                     "ParentID": null
//                 },
//                 "fd": "2025-01-15T06:00:00+01:00",
//                 "td": null,
//                 "tt": 1,
//                 "cl": 1,
//                 "al": "AS",
//                 "st": 1,
//                 "px": 55.1,
//                 "i_on": "2024-11-13T14:04:47.171Z"
//             },
//             {
//                 "Id": "673492cc5c7a78e2c8bd3348",
//                 "o": "LAS",
//                 "originDetails": {
//                     "ID": 1117,
//                     "AirportCode": "LAS",
//                     "CityCode": "LAS",
//                     "CityName": "Las Vegas",
//                     "AirportName": "Las Vegas All Airports",
//                     "StateCode": "NV",
//                     "StateName": "Nevada",
//                     "CountryCode": "US",
//                     "CountryName": "United States",
//                     "AutoSuggest": null,
//                     "Text": "LAS - Las Vegas All Airports, Nevada, United States",
//                     "Type": "City",
//                     "IATACode": null,
//                     "Distance": "",
//                     "Latitude": "36.086945",
//                     "Longitude": "-115.1486",
//                     "SubType": "",
//                     "SubText": "",
//                     "MisspellMatchWord": "a",
//                     "Timezone": "-8",
//                     "Airports": "LAS,LSV,VGT",
//                     "ChiledAirportCodes": [
//                         "LAS",
//                         "LSV",
//                         "VGT"
//                     ],
//                     "ParentID": null
//                 },
//                 "d": "ONT",
//                 "destinationDetails": {
//                     "ID": 2678,
//                     "AirportCode": "ONT",
//                     "CityCode": "ONT",
//                     "CityName": "Ontario",
//                     "AirportName": "Ontario",
//                     "StateCode": "CA",
//                     "StateName": "California",
//                     "CountryCode": "US",
//                     "CountryName": "United States",
//                     "AutoSuggest": null,
//                     "Text": "ONT - Ontario, California, United States",
//                     "Type": "Airport",
//                     "IATACode": null,
//                     "Distance": "",
//                     "Latitude": "34.06068",
//                     "Longitude": "-117.59765",
//                     "SubType": "Municipal",
//                     "SubText": "POC - Brackett Field ",
//                     "MisspellMatchWord": "",
//                     "Timezone": "-8",
//                     "Airports": "ONT",
//                     "ChiledAirportCodes": [
//                         "ONT"
//                     ],
//                     "ParentID": null
//                 },
//                 "fd": "2025-01-16T06:00:00+01:00",
//                 "td": null,
//                 "tt": 1,
//                 "cl": 1,
//                 "al": "F9",
//                 "st": 1,
//                 "px": 27.98,
//                 "i_on": "2024-11-13T11:51:40.293Z"
//             },
//             {
//                 "Id": "6720b51c1657d92cb6ad3090",
//                 "o": "LAS",
//                 "originDetails": {
//                     "ID": 1117,
//                     "AirportCode": "LAS",
//                     "CityCode": "LAS",
//                     "CityName": "Las Vegas",
//                     "AirportName": "Las Vegas All Airports",
//                     "StateCode": "NV",
//                     "StateName": "Nevada",
//                     "CountryCode": "US",
//                     "CountryName": "United States",
//                     "AutoSuggest": null,
//                     "Text": "LAS - Las Vegas All Airports, Nevada, United States",
//                     "Type": "City",
//                     "IATACode": null,
//                     "Distance": "",
//                     "Latitude": "36.086945",
//                     "Longitude": "-115.1486",
//                     "SubType": "",
//                     "SubText": "",
//                     "MisspellMatchWord": "a",
//                     "Timezone": "-8",
//                     "Airports": "LAS,LSV,VGT",
//                     "ChiledAirportCodes": [
//                         "LAS",
//                         "LSV",
//                         "VGT"
//                     ],
//                     "ParentID": null
//                 },
//                 "d": "LAX",
//                 "destinationDetails": {
//                     "ID": 1874,
//                     "AirportCode": "LAX",
//                     "CityCode": "LAX",
//                     "CityName": "Los Angeles",
//                     "AirportName": "Los Angeles",
//                     "StateCode": "CA",
//                     "StateName": "California",
//                     "CountryCode": "US",
//                     "CountryName": "United States",
//                     "AutoSuggest": null,
//                     "Text": "LAX - Los Angeles, California, United States",
//                     "Type": "Airport",
//                     "IATACode": null,
//                     "Distance": "",
//                     "Latitude": "33.943398",
//                     "Longitude": "-118.40828",
//                     "SubType": "",
//                     "SubText": "",
//                     "MisspellMatchWord": "a",
//                     "Timezone": "-8",
//                     "Airports": "LAX",
//                     "ChiledAirportCodes": [
//                         "LAX"
//                     ],
//                     "ParentID": null
//                 },
//                 "fd": "2025-01-16T06:05:00+01:00",
//                 "td": null,
//                 "tt": 1,
//                 "cl": 1,
//                 "al": "UA",
//                 "st": 1,
//                 "px": 85.48,
//                 "i_on": "2024-10-29T10:12:44.478Z"
//             },
//             {
//                 "Id": "6734b1ff5c7a78e2c8bd3520",
//                 "o": "LAS",
//                 "originDetails": {
//                     "ID": 1117,
//                     "AirportCode": "LAS",
//                     "CityCode": "LAS",
//                     "CityName": "Las Vegas",
//                     "AirportName": "Las Vegas All Airports",
//                     "StateCode": "NV",
//                     "StateName": "Nevada",
//                     "CountryCode": "US",
//                     "CountryName": "United States",
//                     "AutoSuggest": null,
//                     "Text": "LAS - Las Vegas All Airports, Nevada, United States",
//                     "Type": "City",
//                     "IATACode": null,
//                     "Distance": "",
//                     "Latitude": "36.086945",
//                     "Longitude": "-115.1486",
//                     "SubType": "",
//                     "SubText": "",
//                     "MisspellMatchWord": "a",
//                     "Timezone": "-8",
//                     "Airports": "LAS,LSV,VGT",
//                     "ChiledAirportCodes": [
//                         "LAS",
//                         "LSV",
//                         "VGT"
//                     ],
//                     "ParentID": null
//                 },
//                 "d": "LAX",
//                 "destinationDetails": {
//                     "ID": 1874,
//                     "AirportCode": "LAX",
//                     "CityCode": "LAX",
//                     "CityName": "Los Angeles",
//                     "AirportName": "Los Angeles",
//                     "StateCode": "CA",
//                     "StateName": "California",
//                     "CountryCode": "US",
//                     "CountryName": "United States",
//                     "AutoSuggest": null,
//                     "Text": "LAX - Los Angeles, California, United States",
//                     "Type": "Airport",
//                     "IATACode": null,
//                     "Distance": "",
//                     "Latitude": "33.943398",
//                     "Longitude": "-118.40828",
//                     "SubType": "",
//                     "SubText": "",
//                     "MisspellMatchWord": "a",
//                     "Timezone": "-8",
//                     "Airports": "LAX",
//                     "ChiledAirportCodes": [
//                         "LAX"
//                     ],
//                     "ParentID": null
//                 },
//                 "fd": "2025-01-15T07:00:00+01:00",
//                 "td": null,
//                 "tt": 1,
//                 "cl": 1,
//                 "al": "B6",
//                 "st": 2,
//                 "px": 212.21,
//                 "i_on": "2024-11-13T14:04:47.172Z"
//             },
//             {
//                 "Id": "673492cc5c7a78e2c8bd334a",
//                 "o": "LAS",
//                 "originDetails": {
//                     "ID": 1117,
//                     "AirportCode": "LAS",
//                     "CityCode": "LAS",
//                     "CityName": "Las Vegas",
//                     "AirportName": "Las Vegas All Airports",
//                     "StateCode": "NV",
//                     "StateName": "Nevada",
//                     "CountryCode": "US",
//                     "CountryName": "United States",
//                     "AutoSuggest": null,
//                     "Text": "LAS - Las Vegas All Airports, Nevada, United States",
//                     "Type": "City",
//                     "IATACode": null,
//                     "Distance": "",
//                     "Latitude": "36.086945",
//                     "Longitude": "-115.1486",
//                     "SubType": "",
//                     "SubText": "",
//                     "MisspellMatchWord": "a",
//                     "Timezone": "-8",
//                     "Airports": "LAS,LSV,VGT",
//                     "ChiledAirportCodes": [
//                         "LAS",
//                         "LSV",
//                         "VGT"
//                     ],
//                     "ParentID": null
//                 },
//                 "d": "LAX",
//                 "destinationDetails": {
//                     "ID": 1874,
//                     "AirportCode": "LAX",
//                     "CityCode": "LAX",
//                     "CityName": "Los Angeles",
//                     "AirportName": "Los Angeles",
//                     "StateCode": "CA",
//                     "StateName": "California",
//                     "CountryCode": "US",
//                     "CountryName": "United States",
//                     "AutoSuggest": null,
//                     "Text": "LAX - Los Angeles, California, United States",
//                     "Type": "Airport",
//                     "IATACode": null,
//                     "Distance": "",
//                     "Latitude": "33.943398",
//                     "Longitude": "-118.40828",
//                     "SubType": "",
//                     "SubText": "",
//                     "MisspellMatchWord": "a",
//                     "Timezone": "-8",
//                     "Airports": "LAX",
//                     "ChiledAirportCodes": [
//                         "LAX"
//                     ],
//                     "ParentID": null
//                 },
//                 "fd": "2025-01-16T21:08:00+01:00",
//                 "td": null,
//                 "tt": 1,
//                 "cl": 1,
//                 "al": "NK",
//                 "st": 1,
//                 "px": 28.0,
//                 "i_on": "2024-11-13T11:51:40.293Z"
//             },
//             {
//                 "Id": "6720b51c1657d92cb6ad308f",
//                 "o": "LAS",
//                 "originDetails": {
//                     "ID": 1117,
//                     "AirportCode": "LAS",
//                     "CityCode": "LAS",
//                     "CityName": "Las Vegas",
//                     "AirportName": "Las Vegas All Airports",
//                     "StateCode": "NV",
//                     "StateName": "Nevada",
//                     "CountryCode": "US",
//                     "CountryName": "United States",
//                     "AutoSuggest": null,
//                     "Text": "LAS - Las Vegas All Airports, Nevada, United States",
//                     "Type": "City",
//                     "IATACode": null,
//                     "Distance": "",
//                     "Latitude": "36.086945",
//                     "Longitude": "-115.1486",
//                     "SubType": "",
//                     "SubText": "",
//                     "MisspellMatchWord": "a",
//                     "Timezone": "-8",
//                     "Airports": "LAS,LSV,VGT",
//                     "ChiledAirportCodes": [
//                         "LAS",
//                         "LSV",
//                         "VGT"
//                     ],
//                     "ParentID": null
//                 },
//                 "d": "LAX",
//                 "destinationDetails": {
//                     "ID": 1874,
//                     "AirportCode": "LAX",
//                     "CityCode": "LAX",
//                     "CityName": "Los Angeles",
//                     "AirportName": "Los Angeles",
//                     "StateCode": "CA",
//                     "StateName": "California",
//                     "CountryCode": "US",
//                     "CountryName": "United States",
//                     "AutoSuggest": null,
//                     "Text": "LAX - Los Angeles, California, United States",
//                     "Type": "Airport",
//                     "IATACode": null,
//                     "Distance": "",
//                     "Latitude": "33.943398",
//                     "Longitude": "-118.40828",
//                     "SubType": "",
//                     "SubText": "",
//                     "MisspellMatchWord": "a",
//                     "Timezone": "-8",
//                     "Airports": "LAX",
//                     "ChiledAirportCodes": [
//                         "LAX"
//                     ],
//                     "ParentID": null
//                 },
//                 "fd": "2025-01-16T07:00:00+01:00",
//                 "td": null,
//                 "tt": 1,
//                 "cl": 1,
//                 "al": "AA",
//                 "st": 1,
//                 "px": 85.48,
//                 "i_on": "2024-10-29T10:12:44.478Z"
//             }
//         ],
//          "PopularDestinationsDeals": [
//             {
//                 "Id": "673492cc5c7a78e2c8bd334a",
//                 "o": "LAS",
//                 "originDetails": {
//                     "ID": 1117,
//                     "AirportCode": "LAS",
//                     "CityCode": "LAS",
//                     "CityName": "Las Vegas",
//                     "AirportName": "Las Vegas All Airports",
//                     "StateCode": "NV",
//                     "StateName": "Nevada",
//                     "CountryCode": "US",
//                     "CountryName": "United States",
//                     "AutoSuggest": null,
//                     "Text": "LAS - Las Vegas All Airports, Nevada, United States",
//                     "Type": "City",
//                     "IATACode": null,
//                     "Distance": "",
//                     "Latitude": "36.086945",
//                     "Longitude": "-115.1486",
//                     "SubType": "",
//                     "SubText": "",
//                     "MisspellMatchWord": "a",
//                     "Timezone": "-8",
//                     "Airports": "LAS,LSV,VGT",
//                     "ChiledAirportCodes": [
//                         "LAS",
//                         "LSV",
//                         "VGT"
//                     ],
//                     "ParentID": null
//                 },
//                 "d": "LAX",
//                 "destinationDetails": {
//                     "ID": 1874,
//                     "AirportCode": "LAX",
//                     "CityCode": "LAX",
//                     "CityName": "Los Angeles",
//                     "AirportName": "Los Angeles",
//                     "StateCode": "CA",
//                     "StateName": "California",
//                     "CountryCode": "US",
//                     "CountryName": "United States",
//                     "AutoSuggest": null,
//                     "Text": "LAX - Los Angeles, California, United States",
//                     "Type": "Airport",
//                     "IATACode": null,
//                     "Distance": "",
//                     "Latitude": "33.943398",
//                     "Longitude": "-118.40828",
//                     "SubType": "",
//                     "SubText": "",
//                     "MisspellMatchWord": "a",
//                     "Timezone": "-8",
//                     "Airports": "LAX",
//                     "ChiledAirportCodes": [
//                         "LAX"
//                     ],
//                     "ParentID": null
//                 },
//                 "fd": "2025-01-16T21:08:00+01:00",
//                 "td": null,
//                 "tt": 1,
//                 "cl": 1,
//                 "al": "NK",
//                 "st": 1,
//                 "px": 28.0,
//                 "i_on": "2024-11-13T11:51:40.293Z"
//             }
//         ],

//         }

//         return data;
// }


