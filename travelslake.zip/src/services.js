import axios from "axios"

const Apiurl    = process.env.REACT_APP_APIUrl;
const swsApiurl = process.env.REACT_APP_CWSAPIURL;


/* Get search field autocomplete flight records */


export const getSeatchrecords = (query) => {
    return axios({
        url: swsApiurl+`/airports?q=${query}`,
        method: 'get',
    headers: {
        "Content-Type": "application/json",
    }
 });


}
/* Get countries list */
export const getCountries = (query) => {
    return axios({
        url: swsApiurl+`/countrylist`,
        method: 'get',
    headers: {
        "Content-Type": "application/json",
    }
 });


}

/* Get countries list */
export const getStatesdata = (countrycode) => {
    return axios({
        url: swsApiurl+`/statebycountry?cc=${countrycode}`,
        method: 'get',
    headers: {
        "Content-Type": "application/json",
    }
 });


}


/* Get Homepage data , deals etc */

export const getHomepagedata = (getDealsArr) => {
    return axios({
    url: '/commoncontent/',
    method: 'post',
    data:getDealsArr,
    headers: {
        "Content-Type": "application/json",
    },
 })

}
