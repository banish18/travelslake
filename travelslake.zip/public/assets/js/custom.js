    // $(document).ready(function() {

    //     $('.bottom-bar ul li').click(function(e) {
    //         e.preventDefault();
    //         $('li').removeClass('active');
    //         $(this).addClass('active');
    //     });


    //     $(function() {
    //         var menuVisible = false;
    //         $('#menuBtn, #mobileBtnClose').click(function() {
    //             if (menuVisible) {
    //                 $('#mobileMenu').css({ 'left': '100%' });
    //                 $('#overlay').remove(); // Remove overlay element
    //                 $('body').css('overflow', 'auto'); // Enable scrolling on body
    //                 menuVisible = false;
    //                 return;
    //             }
    //             $('#mobileMenu, #mobileBtnClose').css({ 'left': '20%' });
    //             $('<div class="overlay" id="overlay"></div>').appendTo('body'); // Create overlay dynamically
    //             $('body').css('overflow', 'hidden'); // Disable scrolling on body
    //             menuVisible = true;
    //         });

    //         // Close mobile menu when clicking outside of it
    //         $(document).on('click', '#overlay', function() {
    //             $('#mobileMenu').css({ 'left': '100%' });
    //             $(this).remove(); // Remove overlay element
    //             $('body').css('overflow', 'auto'); // Enable scrolling on body
    //             menuVisible = false;
    //         });

    //         // Close mobile menu when clicking on Close button
    //         $('#closeMenu').click(function() {
    //             if (menuVisible) {
    //                 $('#mobileMenu').css({ 'left': '100%' });
    //                 $('#overlay').remove(); // Remove overlay element
    //                 menuVisible = false;
    //                 return;
    //             }
    //         });
    //     });

    //     $('.sortBox').click(function(e) {
    //         e.preventDefault();
    //         $('.sortBox').removeClass('active');
    //         $(this).addClass('active');
    //     });


    //     document.getElementById('showMoreBtn').addEventListener('click', function() {
    //         let hiddenItems = document.querySelectorAll('#airlinesList .hidden');
    //         hiddenItems.forEach(item => item.classList.remove('hidden'));
    //         document.getElementById('showMoreBtn').classList.add('hidden');
    //         document.getElementById('showLessBtn').classList.remove('hidden');
    //     });

    //     document.getElementById('showLessBtn').addEventListener('click', function() {
    //         let listItems = document.querySelectorAll('#airlinesList li');
    //         listItems.forEach((item, index) => {
    //             if (index >= 6) {
    //                 item.classList.add('hidden');
    //             }
    //         });
    //         document.getElementById('showMoreBtn').classList.remove('hidden');
    //         document.getElementById('showLessBtn').classList.add('hidden');
    //     });

    // })


    // Prevent parent dropdown
    // document.addEventListener('DOMContentLoaded', function() {
    //     // Prevent parent dropdown from closing when clicking on child dropdown
    //     document.querySelectorAll('#parentDropdown .dropdown-item').forEach(function(item) {
    //         item.addEventListener('click', function(event) {
    //             if (this.closest('#childDropdown')) {
    //                 event.stopPropagation();
    //             }
    //         });
    //     });

    //     // Handle child dropdown items to close only the child dropdown
    //     document.querySelectorAll('#childDropdown .dropdown-item').forEach(function(item) {
    //         item.addEventListener('click', function() {
    //             var childDropdownMenu = this.closest('.dropdown-menu');
    //             childDropdownMenu.classList.remove('show');
    //             var childDropdownButton = childDropdownMenu.previousElementSibling;
    //             childDropdownButton.setAttribute('aria-expanded', 'false');
    //             bootstrap.Dropdown.getInstance(childDropdownButton).hide();
    //         });
    //     });
    // });